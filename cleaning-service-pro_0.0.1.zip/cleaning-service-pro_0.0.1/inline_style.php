<?php

	//General Button Color Pallete option

	$cleaning_service_pro_h1_font_family = get_theme_mod('cleaning_service_pro_h1_font_family');
	$cleaning_service_pro_h1_font_size = get_theme_mod('cleaning_service_pro_h1_font_size');
	$cleaning_service_pro_h1_color = get_theme_mod('cleaning_service_pro_h1_color');
	$cleaning_service_pro_h2_font_family = get_theme_mod('cleaning_service_pro_h2_font_family');
	$cleaning_service_pro_h2_font_size = get_theme_mod('cleaning_service_pro_h2_font_size');
	$cleaning_service_pro_h2_color = get_theme_mod('cleaning_service_pro_h2_color');
	$cleaning_service_pro_h3_font_family = get_theme_mod('cleaning_service_pro_h3_font_family');
	$cleaning_service_pro_h3_font_size = get_theme_mod('cleaning_service_pro_h3_font_size');
	$cleaning_service_pro_h3_color = get_theme_mod('cleaning_service_pro_h3_color');
	$cleaning_service_pro_h4_font_family = get_theme_mod('cleaning_service_pro_h4_font_family');
	$cleaning_service_pro_h4_font_size = get_theme_mod('cleaning_service_pro_h4_font_size');
	$cleaning_service_pro_h4_color = get_theme_mod('cleaning_service_pro_h4_color');
	$cleaning_service_pro_h5_font_family = get_theme_mod('cleaning_service_pro_h5_font_family');
	$cleaning_service_pro_h5_font_size = get_theme_mod('cleaning_service_pro_h5_font_size');
	$cleaning_service_pro_h5_color = get_theme_mod('cleaning_service_pro_h5_color');
	$cleaning_service_pro_h6_font_family = get_theme_mod('cleaning_service_pro_h6_font_family');
	$cleaning_service_pro_h6_font_size = get_theme_mod('cleaning_service_pro_h6_font_size');
	$cleaning_service_pro_h6_color = get_theme_mod('cleaning_service_pro_h6_color');
	$cleaning_service_pro_paragarpah_font_family = get_theme_mod('cleaning_service_pro_paragarpah_font_family');
	$cleaning_service_pro_para_font_size = get_theme_mod('cleaning_service_pro_para_font_size');
	$cleaning_service_pro_para_color = get_theme_mod('cleaning_service_pro_para_color');
	
	// -------------- Topbar ----------------

	$cleaning_service_pro_topbar_text_color = get_theme_mod('cleaning_service_pro_topbar_text_color');
	$cleaning_service_pro_topbar_text_font_family = get_theme_mod('cleaning_service_pro_topbar_text_font_family');

	$cleaning_service_pro_topbar_btn_color = get_theme_mod('cleaning_service_pro_topbar_btn_color');
	$cleaning_service_pro_topbar_btn_font_family = get_theme_mod('cleaning_service_pro_topbar_btn_font_family');

	// -------------- Topbar-1 ----------------

	$cleaning_service_pro_topbar1_icon_color = get_theme_mod('cleaning_service_pro_topbar1_icon_color');

	$cleaning_service_pro_topbar1_text_color = get_theme_mod('cleaning_service_pro_topbar1_text_color');
	$cleaning_service_pro_topbar1_text_font_family = get_theme_mod('cleaning_service_pro_topbar1_text_font_family');

	// ------------ Header-------------	

	$cleaning_service_pro_header_search_color = get_theme_mod('cleaning_service_pro_header_search_color');

	$cleaning_service_pro_header_logo_title_color = get_theme_mod('cleaning_service_pro_header_logo_title_color');
	$cleaning_service_pro_header_logo_title_font_family = get_theme_mod('cleaning_service_pro_header_logo_title_font_family');

	$cleaning_service_pro_header_subtitle_color = get_theme_mod('cleaning_service_pro_header_subtitle_color');
	$cleaning_service_pro_header_subtitle_font_family = get_theme_mod('cleaning_service_pro_header_subtitle_font_family');

	$cleaning_service_pro_headerhomebg_color = get_theme_mod('cleaning_service_pro_headerhomebg_color');
	$cleaning_service_pro_sticky_headerhomebg_color_second = get_theme_mod('cleaning_service_pro_sticky_headerhomebg_color_second');

	$cleaning_service_pro_headermenu_color = get_theme_mod('cleaning_service_pro_headermenu_color');
	$cleaning_service_pro_headermenu_font_family = get_theme_mod('cleaning_service_pro_headermenu_font_family');

	$cleaning_service_pro_header_menuhovercolor = get_theme_mod('cleaning_service_pro_header_menuhovercolor');
	$cleaning_service_pro_dropdownbg_color = get_theme_mod('cleaning_service_pro_dropdownbg_color');

	$cleaning_service_pro_dropdownbg_itemcolor = get_theme_mod('cleaning_service_pro_dropdownbg_itemcolor');
	$cleaning_service_pro_dropdownbg_item_hovercolor = get_theme_mod('cleaning_service_pro_dropdownbg_item_hovercolor');

	$cleaning_service_pro_header_menu_active_color = get_theme_mod('cleaning_service_pro_header_menu_active_color');
	$cleaning_service_pro_header_menu_active_bgcolor = get_theme_mod('cleaning_service_pro_header_menu_active_bgcolor');

	$cleaning_service_pro_dropdownbg_responsivecolor = get_theme_mod('cleaning_service_pro_dropdownbg_responsivecolor');
	$cleaning_service_pro_headermenu_responsive_item_color = get_theme_mod('cleaning_service_pro_headermenu_responsive_item_color');
	$cleaning_service_pro_headermenu_responsive_item_active_color = get_theme_mod('cleaning_service_pro_headermenu_responsive_item_active_color');

	// Slider

	$cleaning_service_pro_slider_main_Heading_color = get_theme_mod('cleaning_service_pro_slider_main_Heading_color');
	$cleaning_service_pro_slider_main_Heading_font_family = get_theme_mod('cleaning_service_pro_slider_main_Heading_font_family');

	$cleaning_service_pro_sliderHeading_color = get_theme_mod('cleaning_service_pro_sliderHeading_color');
	$cleaning_service_pro_sliderHeading_font_family = get_theme_mod('cleaning_service_pro_sliderHeading_font_family');

	$cleaning_service_pro_slidertext_color = get_theme_mod('cleaning_service_pro_slidertext_color');
	$cleaning_service_pro_slidertext_font_family = get_theme_mod('cleaning_service_pro_slidertext_font_family');

	$cleaning_service_pro_slider_btn_color = get_theme_mod('cleaning_service_pro_slider_btn_color');
	$cleaning_service_pro_slider_btn_font_family = get_theme_mod('cleaning_service_pro_slider_btn_font_family');

	$cleaning_service_pro_slider_btn1_color = get_theme_mod('cleaning_service_pro_slider_btn1_color');
	$cleaning_service_pro_slider_btn1_font_family = get_theme_mod('cleaning_service_pro_slider_btn1_font_family');

	$cleaning_service_pro_slider_btn_bgcolor = get_theme_mod('cleaning_service_pro_slider_btn_bgcolor');
	$cleaning_service_pro_slider_btn1_bgcolor = get_theme_mod('cleaning_service_pro_slider_btn1_bgcolor');

	$cleaning_service_pro_slider_clock_icon_color = get_theme_mod('cleaning_service_pro_slider_clock_icon_color');
	$cleaning_service_pro_slider_clock_color = get_theme_mod('cleaning_service_pro_slider_clock_color');
	$cleaning_service_pro_slider_clock_font_family = get_theme_mod('cleaning_service_pro_slider_clock_font_family');

	$cleaning_service_pro_slider_clock_bgcolor = get_theme_mod('cleaning_service_pro_slider_clock_bgcolor');

	$cleaning_service_pro_slider_discount_color = get_theme_mod('cleaning_service_pro_slider_discount_color');
	$cleaning_service_pro_slider_discount_font_family = get_theme_mod('cleaning_service_pro_slider_discount_font_family');

	$cleaning_service_pro_slider_discount_bgcolor = get_theme_mod('cleaning_service_pro_slider_discount_bgcolor');

	// Service

	$cleaning_service_pro_service_main_heading_color = get_theme_mod('cleaning_service_pro_service_main_heading_color');
	$cleaning_service_pro_service_main_heading_font_family = get_theme_mod('cleaning_service_pro_service_main_heading_font_family');

	$cleaning_service_pro_service_main_text_color = get_theme_mod('cleaning_service_pro_service_main_text_color');
	$cleaning_service_pro_service_main_text_font_family = get_theme_mod('cleaning_service_pro_service_main_text_font_family');

	$cleaning_service_pro_service_title_color = get_theme_mod('cleaning_service_pro_service_title_color');
	$cleaning_service_pro_service_title_font_family = get_theme_mod('cleaning_service_pro_service_title_font_family');

	$cleaning_service_pro_service_text_color = get_theme_mod('cleaning_service_pro_service_text_color');
	$cleaning_service_pro_service_text_font_family = get_theme_mod('cleaning_service_pro_service_text_font_family');

	$cleaning_service_pro_service_btn_color = get_theme_mod('cleaning_service_pro_service_btn_color');
	$cleaning_service_pro_service_btn_font_family = get_theme_mod('cleaning_service_pro_service_btn_font_family');
	$cleaning_service_pro_service_btn_bgcolor = get_theme_mod('cleaning_service_pro_service_btn_bgcolor');

	// About

	$cleaning_service_pro_about_main_heading_color = get_theme_mod('cleaning_service_pro_about_main_heading_color');
	$cleaning_service_pro_about_main_heading_font_family = get_theme_mod('cleaning_service_pro_about_main_heading_font_family');
	$cleaning_service_pro_about_main_heading_bgcolor = get_theme_mod('cleaning_service_pro_about_main_heading_bgcolor');

	$cleaning_service_pro_about_main_title_color = get_theme_mod('cleaning_service_pro_about_main_title_color');
	$cleaning_service_pro_about_main_title_font_family = get_theme_mod('cleaning_service_pro_about_main_title_font_family');

	$cleaning_service_pro_about_main_text_color = get_theme_mod('cleaning_service_pro_about_main_text_color');
	$cleaning_service_pro_about_main_text_font_family = get_theme_mod('cleaning_service_pro_about_main_text_font_family');

	$cleaning_service_pro_about_list_color = get_theme_mod('cleaning_service_pro_about_list_color');
	$cleaning_service_pro_about_list_font_family = get_theme_mod('cleaning_service_pro_about_list_font_family');

	$cleaning_service_pro_about_phone_head_color = get_theme_mod('cleaning_service_pro_about_phone_head_color');
	$cleaning_service_pro_about_phone_head_font_family = get_theme_mod('cleaning_service_pro_about_phone_head_font_family');

	$cleaning_service_pro_about_phone_number_color = get_theme_mod('cleaning_service_pro_about_phone_number_color');
	$cleaning_service_pro_about_phone_number_font_family = get_theme_mod('cleaning_service_pro_about_phone_number_font_family');

	$cleaning_service_pro_about_left_text_color = get_theme_mod('cleaning_service_pro_about_left_text_color');
	$cleaning_service_pro_about_left_text_font_family = get_theme_mod('cleaning_service_pro_about_left_text_font_family');

	$cleaning_service_pro_about_left_box_bgcolor = get_theme_mod('cleaning_service_pro_about_left_box_bgcolor');

	// What we do

	$cleaning_service_pro_what_we_do_main_heading_color = get_theme_mod('cleaning_service_pro_what_we_do_main_heading_color');
	$cleaning_service_pro_what_we_do_main_heading_font_family = get_theme_mod('cleaning_service_pro_what_we_do_main_heading_font_family');

	$cleaning_service_pro_what_we_do_main_heading_bgcolor = get_theme_mod('cleaning_service_pro_what_we_do_main_heading_bgcolor');

	$cleaning_service_pro_what_we_do_main_text_color = get_theme_mod('cleaning_service_pro_what_we_do_main_text_color');
	$cleaning_service_pro_what_we_do_main_text_font_family = get_theme_mod('cleaning_service_pro_what_we_do_main_text_font_family');

	$cleaning_service_pro_what_we_do_title_color = get_theme_mod('cleaning_service_pro_what_we_do_title_color');
	$cleaning_service_pro_what_we_do_title_font_family = get_theme_mod('cleaning_service_pro_what_we_do_title_font_family');

	$cleaning_service_pro_what_we_do_text_color = get_theme_mod('cleaning_service_pro_what_we_do_text_color');
	$cleaning_service_pro_what_we_do_text_font_family = get_theme_mod('cleaning_service_pro_what_we_do_text_font_family');

	$cleaning_service_pro_what_we_do_btn_color = get_theme_mod('cleaning_service_pro_what_we_do_btn_color');
	$cleaning_service_pro_what_we_do_btn_font_family = get_theme_mod('cleaning_service_pro_what_we_do_btn_font_family');

	$cleaning_service_pro_what_we_do_btn_bgcolor = get_theme_mod('cleaning_service_pro_what_we_do_btn_bgcolor');

	// Why Choose Us

	$cleaning_service_pro_why_choose_us_main_heading_color = get_theme_mod('cleaning_service_pro_why_choose_us_main_heading_color');
	$cleaning_service_pro_why_choose_us_main_heading_font_family = get_theme_mod('cleaning_service_pro_why_choose_us_main_heading_font_family');
	$cleaning_service_pro_why_choose_us_main_heading_bgcolor = get_theme_mod('cleaning_service_pro_why_choose_us_main_heading_bgcolor');

	$cleaning_service_pro_why_choose_us_main_text_color = get_theme_mod('cleaning_service_pro_why_choose_us_main_text_color');
	$cleaning_service_pro_why_choose_us_main_text_font_family = get_theme_mod('cleaning_service_pro_why_choose_us_main_text_font_family');

	$cleaning_service_pro_why_choose_us_heading_color = get_theme_mod('cleaning_service_pro_why_choose_us_heading_color');
	$cleaning_service_pro_why_choose_us_heading_font_family = get_theme_mod('cleaning_service_pro_why_choose_us_heading_font_family');
	$cleaning_service_pro_why_choose_us_heading_bgcolor = get_theme_mod('cleaning_service_pro_why_choose_us_heading_bgcolor');

	$cleaning_service_pro_why_choose_us_title_color = get_theme_mod('cleaning_service_pro_why_choose_us_title_color');
	$cleaning_service_pro_why_choose_us_title_font_family = get_theme_mod('cleaning_service_pro_why_choose_us_title_font_family');

	$cleaning_service_pro_why_choose_us_text_color = get_theme_mod('cleaning_service_pro_why_choose_us_text_color');
	$cleaning_service_pro_why_choose_us_text_font_family = get_theme_mod('cleaning_service_pro_why_choose_us_text_font_family');

	$cleaning_service_pro_why_choose_us_img_text_color = get_theme_mod('cleaning_service_pro_why_choose_us_img_text_color');
	$cleaning_service_pro_why_choose_us_img_text_font_family = get_theme_mod('cleaning_service_pro_why_choose_us_img_text_font_family');

	$cleaning_service_pro_why_choose_us_video_heading_color = get_theme_mod('cleaning_service_pro_why_choose_us_video_heading_color');
	$cleaning_service_pro_why_choose_us_video_heading_font_family = get_theme_mod('cleaning_service_pro_why_choose_us_video_heading_font_family');
	$cleaning_service_pro_why_choose_us_video_heading_bgcolor = get_theme_mod('cleaning_service_pro_why_choose_us_video_heading_bgcolor');

	$cleaning_service_pro_why_choose_us_video_icon_color = get_theme_mod('cleaning_service_pro_why_choose_us_video_icon_color');
	$cleaning_service_pro_why_choose_us_video_icon_bgcolor = get_theme_mod('cleaning_service_pro_why_choose_us_video_icon_bgcolor');

	$cleaning_service_pro_why_choose_us_counter_title_color = get_theme_mod('cleaning_service_pro_why_choose_us_counter_title_color');
	$cleaning_service_pro_why_choose_us_counter_title_font_family = get_theme_mod('cleaning_service_pro_why_choose_us_counter_title_font_family');

	$cleaning_service_pro_why_choose_us_counter_text_color = get_theme_mod('cleaning_service_pro_why_choose_us_counter_text_color');
	$cleaning_service_pro_why_choose_us_counter_text_font_family = get_theme_mod('cleaning_service_pro_why_choose_us_counter_text_font_family');

	// Pricing

	$cleaning_service_pro_pricing_main_heading_color = get_theme_mod('cleaning_service_pro_pricing_main_heading_color');
	$cleaning_service_pro_pricing_main_heading_font_family = get_theme_mod('cleaning_service_pro_pricing_main_heading_font_family');
	$cleaning_service_pro_pricing_main_heading_bgcolor = get_theme_mod('cleaning_service_pro_pricing_main_heading_bgcolor');

	$cleaning_service_pro_pricing_main_text_color = get_theme_mod('cleaning_service_pro_pricing_main_text_color');
	$cleaning_service_pro_pricing_main_text_font_family = get_theme_mod('cleaning_service_pro_pricing_main_text_font_family');

	$cleaning_service_pro_pricing_title_color = get_theme_mod('cleaning_service_pro_pricing_title_color');
	$cleaning_service_pro_pricing_title_font_family = get_theme_mod('cleaning_service_pro_pricing_title_font_family');

	$cleaning_service_pro_pricing_text_color = get_theme_mod('cleaning_service_pro_pricing_text_color');
	$cleaning_service_pro_pricing_text_font_family = get_theme_mod('cleaning_service_pro_pricing_text_font_family');

	$cleaning_service_pro_pricing_value_color = get_theme_mod('cleaning_service_pro_pricing_value_color');	
	$cleaning_service_pro_pricing_value_font_family = get_theme_mod('cleaning_service_pro_pricing_value_font_family');	

	$cleaning_service_pro_pricing_icon_color = get_theme_mod('cleaning_service_pro_pricing_icon_color');	
	$cleaning_service_pro_pricing_icon_bgcolor = get_theme_mod('cleaning_service_pro_pricing_icon_bgcolor');	

	$cleaning_service_pro_pricing_btn_color = get_theme_mod('cleaning_service_pro_pricing_btn_color');	
	$cleaning_service_pro_pricing_btn_font_family = get_theme_mod('cleaning_service_pro_pricing_btn_font_family');	
	$cleaning_service_pro_pricing_btn_bgcolor = get_theme_mod('cleaning_service_pro_pricing_btn_bgcolor');	

	// Project

	$cleaning_service_pro_project_main_heading_color = get_theme_mod('cleaning_service_pro_project_main_heading_color');
	$cleaning_service_pro_project_main_heading_font_family = get_theme_mod('cleaning_service_pro_project_main_heading_font_family');
	$cleaning_service_pro_project_main_heading_bgcolor = get_theme_mod('cleaning_service_pro_project_main_heading_bgcolor');

	$cleaning_service_pro_project_main_text_color = get_theme_mod('cleaning_service_pro_project_main_text_color');
	$cleaning_service_pro_project_main_text_font_family = get_theme_mod('cleaning_service_pro_project_main_text_font_family');

	$cleaning_service_pro_project_title_color = get_theme_mod('cleaning_service_pro_project_title_color');
	$cleaning_service_pro_project_title_font_family = get_theme_mod('cleaning_service_pro_project_title_font_family');

	$cleaning_service_pro_project_text_color = get_theme_mod('cleaning_service_pro_project_text_color');
	$cleaning_service_pro_project_text_font_family = get_theme_mod('cleaning_service_pro_project_text_font_family');

	$cleaning_service_pro_project_btn_color = get_theme_mod('cleaning_service_pro_project_btn_color');
	$cleaning_service_pro_project_btn_font_family = get_theme_mod('cleaning_service_pro_project_btn_font_family');
	$cleaning_service_pro_project_btn_bgcolor = get_theme_mod('cleaning_service_pro_project_btn_bgcolor');

	// Testimonial

	$cleaning_service_pro_testimonial_main_heading_color = get_theme_mod('cleaning_service_pro_testimonial_main_heading_color');
	$cleaning_service_pro_testimonial_main_heading_font_family = get_theme_mod('cleaning_service_pro_testimonial_main_heading_font_family');
	$cleaning_service_pro_testimonial_main_heading_bgcolor = get_theme_mod('cleaning_service_pro_testimonial_main_heading_bgcolor');

	$cleaning_service_pro_testimonial_main_text_color = get_theme_mod('cleaning_service_pro_testimonial_main_text_color');
	$cleaning_service_pro_testimonial_main_text_font_family = get_theme_mod('cleaning_service_pro_testimonial_main_text_font_family');

	$cleaning_service_pro_testimonial_name_color = get_theme_mod('cleaning_service_pro_testimonial_name_color');
	$cleaning_service_pro_testimonial_name_font_family = get_theme_mod('cleaning_service_pro_testimonial_name_font_family');

	$cleaning_service_pro_testimonial_text_color = get_theme_mod('cleaning_service_pro_testimonial_text_color');
	$cleaning_service_pro_testimonial_text_font_family = get_theme_mod('cleaning_service_pro_testimonial_text_font_family');

	$cleaning_service_pro_testimonial_icon_color = get_theme_mod('cleaning_service_pro_testimonial_icon_color');

	// -------------- Newsletter ---------------

	$cleaning_service_pro_newsletter_main_heading_color = get_theme_mod('cleaning_service_pro_newsletter_main_heading_color');
	$cleaning_service_pro_newsletter_main_heading_font_family = get_theme_mod('cleaning_service_pro_newsletter_main_heading_font_family');

	$cleaning_service_pro_newsletter_main_text_color = get_theme_mod('cleaning_service_pro_newsletter_main_text_color');
	$cleaning_service_pro_newsletter_main_text_font_family = get_theme_mod('cleaning_service_pro_newsletter_main_text_font_family');

	$cleaning_service_pro_newsletter_shortcode_bgcolor = get_theme_mod('cleaning_service_pro_newsletter_shortcode_bgcolor');

	$cleaning_service_pro_newsletter_button_color = get_theme_mod('cleaning_service_pro_newsletter_button_color');
	$cleaning_service_pro_newsletter_button_font_family = get_theme_mod('cleaning_service_pro_newsletter_button_font_family');
	$cleaning_service_pro_newsletter_button_bgcolor = get_theme_mod('cleaning_service_pro_newsletter_button_bgcolor');

	// -------------- How We work ---------------

	$cleaning_service_pro_how_we_work_main_heading_color = get_theme_mod('cleaning_service_pro_how_we_work_main_heading_color');
	$cleaning_service_pro_how_we_work_main_heading_font_family = get_theme_mod('cleaning_service_pro_how_we_work_main_heading_font_family');
	$cleaning_service_pro_how_we_work_main_heading_bgcolor = get_theme_mod('cleaning_service_pro_how_we_work_main_heading_bgcolor');

	$cleaning_service_pro_how_we_work_main_text_color = get_theme_mod('cleaning_service_pro_how_we_work_main_text_color');
	$cleaning_service_pro_how_we_work_main_text_font_family = get_theme_mod('cleaning_service_pro_how_we_work_main_text_font_family');

	$cleaning_service_pro_how_we_work_main_title_color = get_theme_mod('cleaning_service_pro_how_we_work_main_title_color');
	$cleaning_service_pro_how_we_work_main_title_font_family = get_theme_mod('cleaning_service_pro_how_we_work_main_title_font_family');

	$cleaning_service_pro_how_we_work_text_color = get_theme_mod('cleaning_service_pro_how_we_work_text_color');
	$cleaning_service_pro_how_we_work_text_font_family = get_theme_mod('cleaning_service_pro_how_we_work_text_font_family');

	$cleaning_service_pro_how_we_work_list_color = get_theme_mod('cleaning_service_pro_how_we_work_list_color');
	$cleaning_service_pro_how_we_work_list_font_family = get_theme_mod('cleaning_service_pro_how_we_work_list_font_family');

	$cleaning_service_pro_how_we_work_btn_color = get_theme_mod('cleaning_service_pro_how_we_work_btn_color');
	$cleaning_service_pro_how_we_work_btn_font_family = get_theme_mod('cleaning_service_pro_how_we_work_btn_font_family');
	$cleaning_service_pro_how_we_work_btn_bgcolor = get_theme_mod('cleaning_service_pro_how_we_work_btn_bgcolor');

	// -------------- Partner ---------------

	$cleaning_service_pro_partner_main_title_color = get_theme_mod('cleaning_service_pro_partner_main_title_color');
	$cleaning_service_pro_partner_main_title_font_family = get_theme_mod('cleaning_service_pro_partner_main_title_font_family');

	$cleaning_service_pro_partner_main_text_color = get_theme_mod('cleaning_service_pro_partner_main_text_color');
	$cleaning_service_pro_partner_main_text_font_family = get_theme_mod('cleaning_service_pro_partner_main_text_font_family');

	// -------------- Team ---------------

	$cleaning_service_pro_team_main_heading_color = get_theme_mod('cleaning_service_pro_team_main_heading_color');
	$cleaning_service_pro_team_main_heading_font_family = get_theme_mod('cleaning_service_pro_team_main_heading_font_family');
	$cleaning_service_pro_team_main_heading_bgcolor = get_theme_mod('cleaning_service_pro_team_main_heading_bgcolor');

	$cleaning_service_pro_team_main_text_color = get_theme_mod('cleaning_service_pro_team_main_text_color');
	$cleaning_service_pro_team_main_text_font_family = get_theme_mod('cleaning_service_pro_team_main_text_font_family');

	$cleaning_service_pro_team_title_color = get_theme_mod('cleaning_service_pro_team_title_color');
	$cleaning_service_pro_team_title_font_family = get_theme_mod('cleaning_service_pro_team_title_font_family');

	$cleaning_service_pro_team_text_color = get_theme_mod('cleaning_service_pro_team_text_color');
	$cleaning_service_pro_team_text_font_family = get_theme_mod('cleaning_service_pro_team_text_font_family');

	$cleaning_service_pro_team_star_color = get_theme_mod('cleaning_service_pro_team_star_color');
	$cleaning_service_pro_team_social_color = get_theme_mod('cleaning_service_pro_team_social_color');
	$cleaning_service_pro_team_social_bgcolor = get_theme_mod('cleaning_service_pro_team_social_bgcolor');

	$cleaning_service_pro_team_box_hover_color = get_theme_mod('cleaning_service_pro_team_box_hover_color');
	$cleaning_service_pro_team_box_hover_social_bgcolor = get_theme_mod('cleaning_service_pro_team_box_hover_social_bgcolor');

	// -------------- Latest News ---------------

	$cleaning_service_pro_latest_news_main_heading_color = get_theme_mod('cleaning_service_pro_latest_news_main_heading_color');
	$cleaning_service_pro_latest_news_main_heading_font_family = get_theme_mod('cleaning_service_pro_latest_news_main_heading_font_family');
	$cleaning_service_pro_latest_news_main_heading_bgcolor = get_theme_mod('cleaning_service_pro_latest_news_main_heading_bgcolor');

	$cleaning_service_pro_latest_news_main_text_color = get_theme_mod('cleaning_service_pro_latest_news_main_text_color');
	$cleaning_service_pro_latest_news_main_text_font_family = get_theme_mod('cleaning_service_pro_latest_news_main_text_font_family');

	$cleaning_service_pro_latest_news_title_color = get_theme_mod('cleaning_service_pro_latest_news_title_color');
	$cleaning_service_pro_latest_news_title_font_family = get_theme_mod('cleaning_service_pro_latest_news_title_font_family');

	$cleaning_service_pro_latest_news_btn_color = get_theme_mod('cleaning_service_pro_latest_news_btn_color');
	$cleaning_service_pro_latest_news_btn_font_family = get_theme_mod('cleaning_service_pro_latest_news_btn_font_family');
	$cleaning_service_pro_latest_news_btn_bgcolor = get_theme_mod('cleaning_service_pro_latest_news_btn_bgcolor');

	$cleaning_service_pro_latest_news_date_color = get_theme_mod('cleaning_service_pro_latest_news_date_color');
	$cleaning_service_pro_latest_news_date_font_family = get_theme_mod('cleaning_service_pro_latest_news_date_font_family');

	// -------------- Banner ---------------

	$cleaning_service_pro_add_title_color = get_theme_mod('cleaning_service_pro_add_title_color');
	$cleaning_service_pro_add_title_font_family = get_theme_mod('cleaning_service_pro_add_title_font_family');

	$cleaning_service_pro_add_text_color = get_theme_mod('cleaning_service_pro_add_text_color');
	$cleaning_service_pro_add_text_font_family = get_theme_mod('cleaning_service_pro_add_text_font_family');

	// -------------- Faq ---------------

	$cleaning_service_pro_faq_main_heading_color = get_theme_mod('cleaning_service_pro_faq_main_heading_color');
	$cleaning_service_pro_faq_main_heading_font_family = get_theme_mod('cleaning_service_pro_faq_main_heading_font_family');

	$cleaning_service_pro_faq_title_color = get_theme_mod('cleaning_service_pro_faq_title_color');
	$cleaning_service_pro_faq_title_font_family = get_theme_mod('cleaning_service_pro_faq_title_font_family');

	$cleaning_service_pro_faq_text_color = get_theme_mod('cleaning_service_pro_faq_text_color');
	$cleaning_service_pro_faq_text_font_family = get_theme_mod('cleaning_service_pro_faq_text_font_family');

	$cleaning_service_pro_faq_title_hover_color = get_theme_mod('cleaning_service_pro_faq_title_hover_color');
	$cleaning_service_pro_faq_icon_hover_bgcolor = get_theme_mod('cleaning_service_pro_faq_icon_hover_bgcolor');
	$cleaning_service_pro_faq_hover_line_color = get_theme_mod('cleaning_service_pro_faq_hover_line_color');

	/* Product */

	$cleaning_service_pro_product_main_heading_color = get_theme_mod('cleaning_service_pro_product_main_heading_color');
	$cleaning_service_pro_product_main_heading_font_family = get_theme_mod('cleaning_service_pro_product_main_heading_font_family');
	$cleaning_service_pro_product_main_heading_bgcolor = get_theme_mod('cleaning_service_pro_product_main_heading_bgcolor');

	$cleaning_service_pro_product_main_title_color = get_theme_mod('cleaning_service_pro_product_main_title_color');
	$cleaning_service_pro_product_main_title_font_family = get_theme_mod('cleaning_service_pro_product_main_title_font_family');

	$cleaning_service_pro_product_main_text_color = get_theme_mod('cleaning_service_pro_product_main_text_color');
	$cleaning_service_pro_product_main_text_font_family = get_theme_mod('cleaning_service_pro_product_main_text_font_family');

	$cleaning_service_pro_product_title_color = get_theme_mod('cleaning_service_pro_product_title_color');
	$cleaning_service_pro_product_title_font_family = get_theme_mod('cleaning_service_pro_product_title_font_family');

	$cleaning_service_pro_product_text_color = get_theme_mod('cleaning_service_pro_product_text_color');
	$cleaning_service_pro_product_text_font_family = get_theme_mod('cleaning_service_pro_product_text_font_family');

	/* Home Contact */

	$cleaning_service_pro_contact_title_color = get_theme_mod('cleaning_service_pro_contact_title_color');
	$cleaning_service_pro_contact_title_font_family = get_theme_mod('cleaning_service_pro_contact_title_font_family');

	$cleaning_service_pro_contact_text_color = get_theme_mod('cleaning_service_pro_contact_text_color');
	$cleaning_service_pro_contact_text_font_family = get_theme_mod('cleaning_service_pro_contact_text_font_family');

	$cleaning_service_pro_contact_icon_color = get_theme_mod('cleaning_service_pro_contact_icon_color');
	$cleaning_service_pro_contact_box_bgcolor = get_theme_mod('cleaning_service_pro_contact_box_bgcolor');

	//Footer Widgets

	$cleaning_service_pro_footer_widget_heading_color = get_theme_mod('cleaning_service_pro_footer_widget_heading_color');
	$cleaning_service_pro_footer_widget_heading_font_family = get_theme_mod('cleaning_service_pro_footer_widget_heading_font_family');
	$cleaning_service_pro_footer_widget_content_color = get_theme_mod('cleaning_service_pro_footer_widget_content_color');
	$cleaning_service_pro_footer_widget_content_font_family = get_theme_mod('cleaning_service_pro_footer_widget_content_font_family');

	//Footer Copyright

	$cleaning_service_pro_footer_copy_content_color = get_theme_mod('cleaning_service_pro_footer_copy_content_color');
	$cleaning_service_pro_footer_copy_content_font_family = get_theme_mod('cleaning_service_pro_footer_copy_content_font_family');

	//Contact

	$cleaning_service_pro_contact_page_heading_color = get_theme_mod('cleaning_service_pro_contact_page_heading_color');
	$cleaning_service_pro_contact_page_heading_font_family = get_theme_mod('cleaning_service_pro_contact_page_heading_font_family');
	$cleaning_service_pro_contact_page_content_color = get_theme_mod('cleaning_service_pro_contact_page_content_color');
	$cleaning_service_pro_contact_page_contact_font_family = get_theme_mod('cleaning_service_pro_contact_page_contact_font_family');
	$cleaning_service_pro_contact_page_contents_color = get_theme_mod('cleaning_service_pro_contact_page_contents_color');
	$cleaning_service_pro_contact_page_contacts_font_family = get_theme_mod('cleaning_service_pro_contact_page_contacts_font_family');
	$cleaning_service_pro_contact_page_icon_color = get_theme_mod('cleaning_service_pro_contact_page_icon_color');

	$custom_css ='';

	/* H1 headings */

	if($cleaning_service_pro_h1_font_family != false || $cleaning_service_pro_h1_color != false || $cleaning_service_pro_h1_font_size != false){
		$custom_css .='h1, #slider .slider-box h1 , .page-header h1 , .main_title h1 , .title-box h1 {';
			if($cleaning_service_pro_h1_font_family != false)
		    	$custom_css .='font-family: '.esc_html($cleaning_service_pro_h1_font_family).';';
			if($cleaning_service_pro_h1_color != false)
		    	$custom_css .='color: '.esc_html($cleaning_service_pro_h1_color).';';
			if($cleaning_service_pro_h1_font_size != false)
		    	$custom_css .='font-size: '.esc_html($cleaning_service_pro_h1_font_size).';';
		$custom_css .='}';
	}

	/* H2 headings */

	if($cleaning_service_pro_h2_font_family != false || $cleaning_service_pro_h2_color != false || $cleaning_service_pro_h2_font_size != false){
		$custom_css .='h2, .postbox h2 , #comments h2#reply-title , #comments h2#reply-title {';
			if($cleaning_service_pro_h2_font_family != false)
		    	$custom_css .='font-family: '.esc_html($cleaning_service_pro_h2_font_family).';';
			if($cleaning_service_pro_h2_color != false)
		    	$custom_css .='color: '.esc_html($cleaning_service_pro_h2_color).';';
			if($cleaning_service_pro_h2_font_size != false)
		    	$custom_css .='font-size: '.esc_html($cleaning_service_pro_h2_font_size).';';
		$custom_css .='}';
	}

	/* H3 headings */

	if($cleaning_service_pro_h3_font_family != false || $cleaning_service_pro_h3_color != false || $cleaning_service_pro_h3_font_size != false){
		$custom_css .='h3, h3.contact-page , .contac_form h3, .contact-color-bg h3 , .postbox h3 , #comments h3.comment-reply-title ,#sidebar h3 , #footer h3 , .footer-top-col h3 , .main_heading {';
			if($cleaning_service_pro_h3_font_family != false)
		    	$custom_css .='font-family: '.esc_html($cleaning_service_pro_h3_font_family).';';
			if($cleaning_service_pro_h3_color != false)
		    	$custom_css .='color: '.esc_html($cleaning_service_pro_h3_color).';';
			if($cleaning_service_pro_h3_font_size != false)
		    	$custom_css .='font-size: '.esc_html($cleaning_service_pro_h3_font_size).';';
		$custom_css .='}';
	}
	
	/* H4 headings */

	if($cleaning_service_pro_h4_font_family != false || $cleaning_service_pro_h4_color != false || $cleaning_service_pro_h4_font_size != false){
		$custom_css .='h4,.category-page h4 , #slider .slider-box h4 , #why_choose_us h4.left , #why_choose_us h4.right , #register h4 {';
			if($cleaning_service_pro_h4_font_family != false)
		    	$custom_css .='font-family: '.esc_html($cleaning_service_pro_h4_font_family).';';
			if($cleaning_service_pro_h4_color != false)
		    	$custom_css .='color: '.esc_html($cleaning_service_pro_h4_color).';';
			if($cleaning_service_pro_h4_font_size != false)
		    	$custom_css .='font-size: '.esc_html($cleaning_service_pro_h4_font_size).';';
		$custom_css .='}';
	}
	
	/* H5 headings */

	if($cleaning_service_pro_h5_font_family != false || $cleaning_service_pro_h5_color != false || $cleaning_service_pro_h5_font_size != false){
		$custom_css .='h5, .blog-post h5 ,.serviceBox .service-content h5 , #why_choose_us h5.title ,#how_we_work .how_we_work_content h5 ,#about h5 ,.testimonial h5 ,#partner h5 ,#product .product-content h5 {';
			if($cleaning_service_pro_h5_font_family != false)
		    	$custom_css .='font-family: '.esc_html($cleaning_service_pro_h5_font_family).';';
			if($cleaning_service_pro_h5_color != false)
		    	$custom_css .='color: '.esc_html($cleaning_service_pro_h5_color).';';
			if($cleaning_service_pro_h5_font_size != false)
		    	$custom_css .='font-size: '.esc_html($cleaning_service_pro_h5_font_size).';';
		$custom_css .='}';
	}

	/* H6 headings */

	if($cleaning_service_pro_h6_font_family != false || $cleaning_service_pro_h6_color != false || $cleaning_service_pro_h6_font_size != false){
		$custom_css .='h6, #counter h6 {';
			if($cleaning_service_pro_h6_font_family != false)
		    	$custom_css .='font-family: '.esc_html($cleaning_service_pro_h6_font_family).';';
			if($cleaning_service_pro_h6_color != false)
		    	$custom_css .='color: '.esc_html($cleaning_service_pro_h6_color).';';
			if($cleaning_service_pro_h6_font_size != false)
		    	$custom_css .='font-size: '.esc_html($cleaning_service_pro_h6_font_size).';';
		$custom_css .='}';
	}

	/* Paragraph */

	if($cleaning_service_pro_paragarpah_font_family != false || $cleaning_service_pro_para_color != false || $cleaning_service_pro_para_font_size != false) {
		$custom_css .='p ,.logo p, #footer p.post-date ,.copyright .copy-text p , #footer .copyright p ,.c_content p , #topbar p , #topbar1 p , #slider .slider-box .prop_desc p , #slider .con p ,.serviceBox .service-content p,#about p.text,#about p.phone,#what_we_do .box .description, #why_choose_us p.text, #why_choose_us .choose_box p,#counter p,#project .description,.testimonial p,#how_we_work .how_we_work_content p,#partner p,#team .post,#add p.text,#accordion .panel-body p , #product .text ,#product .product-content p, #contact .contact-content p {';
			if($cleaning_service_pro_paragarpah_font_family != false)
		    	$custom_css .='font-family: '.esc_html($cleaning_service_pro_paragarpah_font_family).';';
			if($cleaning_service_pro_para_color != false)
		    	$custom_css .='color: '.esc_html($cleaning_service_pro_para_color).';';
			if($cleaning_service_pro_para_font_size != false)
		    	$custom_css .='font-size: '.esc_html($cleaning_service_pro_para_font_size).';';
		$custom_css .='}';
	}
	
	// -------------- Topbar ---------------

	if($cleaning_service_pro_topbar_text_color != false || $cleaning_service_pro_topbar_text_font_family != false){
		$custom_css .='#topbar p {';
			if($cleaning_service_pro_topbar_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_topbar_text_color).';';
			if($cleaning_service_pro_topbar_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_topbar_text_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_topbar_btn_color != false || $cleaning_service_pro_topbar_btn_font_family != false){
		$custom_css .='#topbar a {';
			if($cleaning_service_pro_topbar_btn_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_topbar_btn_color).';';
			if($cleaning_service_pro_topbar_btn_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_topbar_btn_font_family).';';
		$custom_css .='}';
	}

	// -------------- Topbar-1 ---------------

	if($cleaning_service_pro_topbar1_icon_color != false){
		$custom_css .='#topbar1 p i {';
				$custom_css .='color: '.esc_html($cleaning_service_pro_topbar1_icon_color).';
		}';
	}

	if($cleaning_service_pro_topbar1_text_color != false || $cleaning_service_pro_topbar1_text_font_family != false){
		$custom_css .='#topbar1 p {';
			if($cleaning_service_pro_topbar1_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_topbar1_text_color).';';
			if($cleaning_service_pro_topbar1_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_topbar1_text_font_family).';';
		$custom_css .='}';
	}

	/* header */

	if($cleaning_service_pro_header_search_color != false){
		$custom_css .='.header-search button {';
				$custom_css .='color: '.esc_html($cleaning_service_pro_header_search_color).';
		}';
	}

	if($cleaning_service_pro_header_logo_title_color != false || $cleaning_service_pro_header_logo_title_font_family != false){
		$custom_css .='.logo a {';
			if($cleaning_service_pro_header_logo_title_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_header_logo_title_color).';';
			if($cleaning_service_pro_header_logo_title_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_header_logo_title_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_header_subtitle_color != false || $cleaning_service_pro_header_subtitle_font_family != false){
		$custom_css .='.logo p {';
			if($cleaning_service_pro_header_subtitle_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_header_subtitle_color).'!important;';
			if($cleaning_service_pro_header_subtitle_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_header_subtitle_font_family).'!important;';
		$custom_css .='}';
	}

	if($cleaning_service_pro_headerhomebg_color != false){
		$custom_css .='.home #header{';
			$custom_css .='background-color: '.esc_html($cleaning_service_pro_headerhomebg_color).';';
		$custom_css .='}';
	}	

	$custom_css .='@media screen and (min-width:720px) { ';
		if($cleaning_service_pro_headermenu_color != false || $cleaning_service_pro_headermenu_font_family != false){
			$custom_css .='.main-navigation a{';
				if($cleaning_service_pro_headermenu_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_headermenu_color).';';
				if($cleaning_service_pro_headermenu_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_headermenu_font_family).';';
			$custom_css .='}';
		}
		if($cleaning_service_pro_header_menuhovercolor != false){
			$custom_css .='.main-navigation a:hover{
				color: '.esc_html($cleaning_service_pro_header_menuhovercolor).';
			}';
		}
		if($cleaning_service_pro_dropdownbg_color != false){
			$custom_css .='.main-navigation ul li:hover > ul{
				background: '.esc_html($cleaning_service_pro_dropdownbg_color).';
			}';
		}
		if($cleaning_service_pro_dropdownbg_itemcolor != false){
			$custom_css .='.main-navigation ul li > ul > li a{
				color: '.esc_html($cleaning_service_pro_dropdownbg_itemcolor).';
			}';
		}
		if($cleaning_service_pro_dropdownbg_item_hovercolor != false){
			$custom_css .='.main-navigation ul.sub-menu li:hover a{
				color: '.esc_html($cleaning_service_pro_dropdownbg_item_hovercolor).';
			}';
		}
		if($cleaning_service_pro_header_menu_active_color != false){
			$custom_css .='.main-navigation .current_page_item > a, .main-navigation .current-menu-item > a{
				color: '.esc_html($cleaning_service_pro_header_menu_active_color).';
			}';
		}
		
	$custom_css .='}';

	$custom_css .='@media screen and (max-width:1024px) {';
		if($cleaning_service_pro_dropdownbg_responsivecolor != false){
			$custom_css .='.sidenav{
				background-color:'.esc_html($cleaning_service_pro_dropdownbg_responsivecolor).';
			}';
		}
		if($cleaning_service_pro_headermenu_responsive_item_color != false){
			$custom_css .='.main-navigation ul li a, .main-navigation ul li ul li a{
				color: '.esc_html($cleaning_service_pro_headermenu_responsive_item_color).';
			}';
		}
		if($cleaning_service_pro_headermenu_responsive_item_active_color != false){
			$custom_css .='.main-navigation .current_page_item > a, .main-navigation .current-menu-item > a{
				color: '.esc_html($cleaning_service_pro_headermenu_responsive_item_active_color).';
			}';
		}

	$custom_css .='}';

	/* Slider */

	if($cleaning_service_pro_slider_main_Heading_color != false || $cleaning_service_pro_slider_main_Heading_font_family != false){
		$custom_css .='#slider .slider-box h4 {';
			if($cleaning_service_pro_slider_main_Heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_slider_main_Heading_color).';';
			if($cleaning_service_pro_slider_main_Heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_slider_main_Heading_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_sliderHeading_color != false || $cleaning_service_pro_sliderHeading_font_family != false){
		$custom_css .='#slider .slider-box h1 {';
			if($cleaning_service_pro_sliderHeading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_sliderHeading_color).';';
			if($cleaning_service_pro_sliderHeading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_sliderHeading_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_slidertext_color != false || $cleaning_service_pro_slidertext_font_family != false){
		$custom_css .='#slider .slider-box .prop_desc p {';
			if($cleaning_service_pro_slidertext_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_slidertext_color).';';
			if($cleaning_service_pro_slidertext_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_slidertext_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_slider_btn_color != false || $cleaning_service_pro_slider_btn_font_family != false){
		$custom_css .='#slider .slider-box a.read-more1 {';
			if($cleaning_service_pro_slider_btn_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_slider_btn_color).';';
			if($cleaning_service_pro_slider_btn_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_slider_btn_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_slider_btn1_color != false || $cleaning_service_pro_slider_btn1_font_family != false){
		$custom_css .='#slider .slider-box a {';
			if($cleaning_service_pro_slider_btn1_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_slider_btn1_color).';';
			if($cleaning_service_pro_slider_btn1_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_slider_btn1_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_slider_btn_bgcolor != false){
		$custom_css .='#slider .slider-box a.read-more1 {
			background: '.esc_html($cleaning_service_pro_slider_btn_bgcolor).';
		}';
	}

	if($cleaning_service_pro_slider_btn1_bgcolor != false){
		$custom_css .='#slider .slider-box a {
			background: '.esc_html($cleaning_service_pro_slider_btn1_bgcolor).';
		}';
	}

	if($cleaning_service_pro_slider_clock_color != false || $cleaning_service_pro_slider_clock_font_family != false){
		$custom_css .='#slider .con p {';
			if($cleaning_service_pro_slider_clock_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_slider_clock_color).';';
			if($cleaning_service_pro_slider_clock_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_slider_clock_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_slider_clock_icon_color != false){
		$custom_css .='#slider .bg i {
			color: '.esc_html($cleaning_service_pro_slider_clock_icon_color).';
		}';
	}
	if($cleaning_service_pro_slider_discount_color != false || $cleaning_service_pro_slider_discount_font_family != false){
		$custom_css .='#slider .slide_right_box span {';
			if($cleaning_service_pro_slider_discount_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_slider_discount_color).';';
			if($cleaning_service_pro_slider_discount_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_slider_discount_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_slider_clock_bgcolor != false){
		$custom_css .='#slider .bg {
			background: '.esc_html($cleaning_service_pro_slider_clock_bgcolor).';
		}';
	}
	if($cleaning_service_pro_slider_discount_bgcolor != false){
		$custom_css .='#slider .slide_right_box {
			background: '.esc_html($cleaning_service_pro_slider_discount_bgcolor).';
		}';
	}

	/* Service */

	if($cleaning_service_pro_service_main_heading_color != false || $cleaning_service_pro_service_main_heading_font_family != false){
		$custom_css .='#service .main_heading {';
			if($cleaning_service_pro_service_main_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_service_main_heading_font_family).';';
			if($cleaning_service_pro_service_main_heading_color != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_service_main_heading_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_service_main_text_color != false || $cleaning_service_pro_service_main_text_font_family != false){
		$custom_css .='#service .main_text {';
			if($cleaning_service_pro_service_main_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_service_main_text_font_family).';';
			if($cleaning_service_pro_service_main_text_color != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_service_main_text_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_service_title_color != false || $cleaning_service_pro_service_title_font_family != false){
		$custom_css .='.serviceBox .service-content h5 {';
			if($cleaning_service_pro_service_title_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_service_title_font_family).';';
			if($cleaning_service_pro_service_title_color != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_service_title_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_service_text_color != false || $cleaning_service_pro_service_text_font_family != false){
		$custom_css .='.serviceBox .service-content p {';
			if($cleaning_service_pro_service_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_service_text_color).';';
			if($cleaning_service_pro_service_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_service_text_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_service_btn_color != false || $cleaning_service_pro_service_btn_font_family != false){
		$custom_css .='.serviceBox a.read.btn {';
			if($cleaning_service_pro_service_btn_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_service_btn_color).';';
			if($cleaning_service_pro_service_btn_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_service_btn_font_family).';';
		$custom_css .='}';
	}
	
	if($cleaning_service_pro_service_btn_bgcolor != false){
		$custom_css .='.serviceBox a.read.btn {
			background: '.esc_html($cleaning_service_pro_service_btn_bgcolor).';
		}';
	}

	// About //

	if($cleaning_service_pro_about_main_heading_color != false || $cleaning_service_pro_about_main_heading_font_family != false){
		$custom_css .='#about .main_para{';
			if($cleaning_service_pro_about_main_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_about_main_heading_color).';';
			if($cleaning_service_pro_about_main_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_about_main_heading_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_about_main_heading_bgcolor != false){
		$custom_css .='#about .main_para {
			background: '.esc_html($cleaning_service_pro_about_main_heading_bgcolor).';
		}';
	}
	if($cleaning_service_pro_about_main_title_color != false || $cleaning_service_pro_about_main_title_font_family != false){
		$custom_css .='#about .main_heading {';
			if($cleaning_service_pro_about_main_title_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_about_main_title_color).';';
			if($cleaning_service_pro_about_main_title_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_about_main_title_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_about_main_text_color != false || $cleaning_service_pro_about_main_text_font_family != false){
			$custom_css .='#about p.text {';
				if($cleaning_service_pro_about_main_text_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_about_main_text_color).';';
				if($cleaning_service_pro_about_main_text_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_about_main_text_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_about_list_color != false || $cleaning_service_pro_about_list_font_family != false){
		$custom_css .='#about li {';
			if($cleaning_service_pro_about_list_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_about_list_color).';';
			if($cleaning_service_pro_about_list_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_about_list_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_about_phone_head_color != false || $cleaning_service_pro_about_phone_head_font_family != false){
		$custom_css .='#about h5 {';
			if($cleaning_service_pro_about_phone_head_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_about_phone_head_color).';';
			if($cleaning_service_pro_about_phone_head_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_about_phone_head_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_about_phone_number_color != false || $cleaning_service_pro_about_phone_number_font_family != false){
		$custom_css .='#about p.phone{';
			if($cleaning_service_pro_about_phone_number_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_about_phone_number_color).';';
			if($cleaning_service_pro_about_phone_number_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_about_phone_number_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_about_left_text_color != false || $cleaning_service_pro_about_left_text_font_family != false){
		$custom_css .='#about .boxx span {';
			if($cleaning_service_pro_about_left_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_about_left_text_color).';';
			if($cleaning_service_pro_about_left_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_about_left_text_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_about_left_box_bgcolor != false){
		$custom_css .='#about .boxx {
			background: '.esc_html($cleaning_service_pro_about_left_box_bgcolor).';
		}';
	}

	// ------------- What we do --------------

	if($cleaning_service_pro_what_we_do_main_heading_color != false || $cleaning_service_pro_what_we_do_main_heading_font_family != false){
		$custom_css .='#what_we_do .main_para {';
			if($cleaning_service_pro_what_we_do_main_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_what_we_do_main_heading_color).';';
			if($cleaning_service_pro_what_we_do_main_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_what_we_do_main_heading_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_what_we_do_main_heading_bgcolor != false){
		$custom_css .='#what_we_do .main_para {
			background: '.esc_html($cleaning_service_pro_what_we_do_main_heading_bgcolor).';
		}';
	}

	if($cleaning_service_pro_what_we_do_main_text_color != false || $cleaning_service_pro_what_we_do_main_text_font_family != false){
			$custom_css .='#what_we_do .main_heading {';
				if($cleaning_service_pro_what_we_do_main_text_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_what_we_do_main_text_color).';';
				if($cleaning_service_pro_what_we_do_main_text_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_what_we_do_main_text_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_what_we_do_title_color != false || $cleaning_service_pro_what_we_do_title_font_family != false){
			$custom_css .='#what_we_do .box .title{';
				if($cleaning_service_pro_what_we_do_title_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_what_we_do_title_color).';';
				if($cleaning_service_pro_what_we_do_title_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_what_we_do_title_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_what_we_do_text_color != false || $cleaning_service_pro_what_we_do_text_font_family != false){
			$custom_css .='#what_we_do .box .description {';
				if($cleaning_service_pro_what_we_do_text_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_what_we_do_text_color).';';
				if($cleaning_service_pro_what_we_do_text_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_what_we_do_text_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_what_we_do_btn_color != false || $cleaning_service_pro_what_we_do_btn_font_family != false){
		$custom_css .='#what_we_do .box .read-more {';
			if($cleaning_service_pro_what_we_do_btn_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_what_we_do_btn_color).';';
			if($cleaning_service_pro_what_we_do_btn_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_what_we_do_btn_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_what_we_do_btn_bgcolor != false){
		$custom_css .='#what_we_do .box .read-more {
			background: '.esc_html($cleaning_service_pro_what_we_do_btn_bgcolor).';
		}';
	}

	// ------------- Why Choose Us --------------

	if($cleaning_service_pro_why_choose_us_main_heading_color != false || $cleaning_service_pro_why_choose_us_main_heading_font_family != false){
		$custom_css .='#why_choose_us .main_para{';
			if($cleaning_service_pro_why_choose_us_main_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_why_choose_us_main_heading_color).';';
			if($cleaning_service_pro_why_choose_us_main_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_why_choose_us_main_heading_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_why_choose_us_main_heading_bgcolor != false){
		$custom_css .='#why_choose_us .main_para {
			background: '.esc_html($cleaning_service_pro_why_choose_us_main_heading_bgcolor).';
		}';
	}

	if($cleaning_service_pro_why_choose_us_main_text_color != false || $cleaning_service_pro_why_choose_us_main_text_font_family != false){
		$custom_css .='#why_choose_us .main_heading {';
			if($cleaning_service_pro_why_choose_us_main_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_why_choose_us_main_text_color).';';
			if($cleaning_service_pro_why_choose_us_main_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_why_choose_us_main_text_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_why_choose_us_heading_color != false || $cleaning_service_pro_why_choose_us_heading_font_family != false){
			$custom_css .='#why_choose_us h4.left {';
				if($cleaning_service_pro_why_choose_us_heading_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_why_choose_us_heading_color).';';
				if($cleaning_service_pro_why_choose_us_heading_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_why_choose_us_heading_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_why_choose_us_heading_bgcolor != false){
		$custom_css .='#why_choose_us h4.left {
			background: '.esc_html($cleaning_service_pro_why_choose_us_heading_bgcolor).';
		}';
	}

	if($cleaning_service_pro_why_choose_us_title_color != false || $cleaning_service_pro_why_choose_us_title_font_family != false){
		$custom_css .='#why_choose_us h5.title {';
			if($cleaning_service_pro_why_choose_us_title_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_why_choose_us_title_color).';';
			if($cleaning_service_pro_why_choose_us_title_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_why_choose_us_title_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_why_choose_us_text_color != false || $cleaning_service_pro_why_choose_us_text_font_family != false){
		$custom_css .='#why_choose_us p.text {';
			if($cleaning_service_pro_why_choose_us_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_why_choose_us_text_color).';';
			if($cleaning_service_pro_why_choose_us_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_why_choose_us_text_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_why_choose_us_img_text_color != false || $cleaning_service_pro_why_choose_us_img_text_font_family != false){
		$custom_css .='#why_choose_us .choose_box p {';
			if($cleaning_service_pro_why_choose_us_img_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_why_choose_us_img_text_color).';';
			if($cleaning_service_pro_why_choose_us_img_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_why_choose_us_img_text_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_why_choose_us_video_heading_color != false || $cleaning_service_pro_why_choose_us_video_heading_font_family != false){
		$custom_css .='#why_choose_us h4.right {';
			if($cleaning_service_pro_why_choose_us_video_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_why_choose_us_video_heading_color).';';
			if($cleaning_service_pro_why_choose_us_video_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_why_choose_us_video_heading_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_why_choose_us_video_heading_bgcolor != false){
		$custom_css .='#why_choose_us h4.right {
			background: '.esc_html($cleaning_service_pro_why_choose_us_video_heading_bgcolor).';
		}';
	}

	if($cleaning_service_pro_why_choose_us_video_icon_color != false){
		$custom_css .='#why_choose_us .video-content i{
			color: '.esc_html($cleaning_service_pro_why_choose_us_video_icon_color).';
		}';
	}

	if($cleaning_service_pro_why_choose_us_video_icon_bgcolor != false){
		$custom_css .='#why_choose_us .video-content i {
			background: '.esc_html($cleaning_service_pro_why_choose_us_video_icon_bgcolor).';
			border-color: '.esc_html($cleaning_service_pro_why_choose_us_video_icon_bgcolor).';
		}';
	}

	if($cleaning_service_pro_why_choose_us_counter_title_color != false || $cleaning_service_pro_why_choose_us_counter_title_font_family != false){
		$custom_css .='#counter h6 {';
			if($cleaning_service_pro_why_choose_us_counter_title_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_why_choose_us_counter_title_color).';';
			if($cleaning_service_pro_why_choose_us_counter_title_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_why_choose_us_counter_title_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_why_choose_us_counter_text_color != false || $cleaning_service_pro_why_choose_us_counter_text_font_family != false){
		$custom_css .='#counter p {';
			if($cleaning_service_pro_why_choose_us_counter_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_why_choose_us_counter_text_color).';';
			if($cleaning_service_pro_why_choose_us_counter_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_why_choose_us_counter_text_font_family).';';
		$custom_css .='}';
	}

	// ------------- Pricing --------------

	if($cleaning_service_pro_pricing_main_heading_color != false || $cleaning_service_pro_pricing_main_heading_font_family != false){
		$custom_css .='#pricing .main_para {';
			if($cleaning_service_pro_pricing_main_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_pricing_main_heading_color).';';
			if($cleaning_service_pro_pricing_main_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_pricing_main_heading_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_pricing_main_heading_bgcolor != false){
		$custom_css .='#pricing .main_para {
			background: '.esc_html($cleaning_service_pro_pricing_main_heading_bgcolor).';
		}';
	}

	if($cleaning_service_pro_pricing_main_text_color != false || $cleaning_service_pro_pricing_main_text_font_family != false){
		$custom_css .='#pricing .main_heading {';
			if($cleaning_service_pro_pricing_main_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_pricing_main_text_color).';';
			if($cleaning_service_pro_pricing_main_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_pricing_main_text_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_pricing_title_color != false || $cleaning_service_pro_pricing_title_font_family != false){
			$custom_css .='.pricingTable .heading{';
				if($cleaning_service_pro_pricing_title_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_pricing_title_color).';';
				if($cleaning_service_pro_pricing_title_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_pricing_title_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_pricing_text_color != false || $cleaning_service_pro_pricing_text_font_family != false){
			$custom_css .='.pricingTable .pricing-content ul li {';
				if($cleaning_service_pro_pricing_text_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_pricing_text_color).';';
				if($cleaning_service_pro_pricing_text_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_pricing_text_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_pricing_value_color != false || $cleaning_service_pro_pricing_value_font_family != false){
			$custom_css .='#pricing .price-value {';
				if($cleaning_service_pro_pricing_value_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_pricing_value_color).';';
				if($cleaning_service_pro_pricing_value_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_pricing_value_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_pricing_btn_color != false || $cleaning_service_pro_pricing_btn_font_family != false){
			$custom_css .='#pricing .pricingTable .read-more{';
				if($cleaning_service_pro_pricing_btn_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_pricing_btn_color).';';
				if($cleaning_service_pro_pricing_btn_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_pricing_btn_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_pricing_btn_bgcolor != false){
		$custom_css .='#pricing .pricingTable .read-more {
			background: '.esc_html($cleaning_service_pro_pricing_btn_bgcolor).';
		}';
	}

	if($cleaning_service_pro_pricing_icon_color != false){
		$custom_css .='#register .bg_2 {
			background-color: '.esc_html($cleaning_service_pro_pricing_icon_color).';
		}';
	}

	if($cleaning_service_pro_pricing_icon_bgcolor != false){
		$custom_css .='#register .bg_3 {
			background-color: '.esc_html($cleaning_service_pro_pricing_icon_bgcolor).';
		}';
	}

	// ------------ Project ----------------

	if($cleaning_service_pro_project_main_heading_color != false || $cleaning_service_pro_project_main_heading_font_family != false){
		$custom_css .='#project .main_para {';
			if($cleaning_service_pro_project_main_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_project_main_heading_color).';';
			if($cleaning_service_pro_project_main_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_project_main_heading_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_project_main_heading_bgcolor != false){
		$custom_css .='#project .main_para {
			color: '.esc_html($cleaning_service_pro_project_main_heading_bgcolor).';
		}';
	}

	if($cleaning_service_pro_project_main_text_color != false || $cleaning_service_pro_project_main_text_font_family != false){
		$custom_css .='#project .main_heading {';
			if($cleaning_service_pro_project_main_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_project_main_text_color).';';
			if($cleaning_service_pro_project_main_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_project_main_text_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_project_title_color != false || $cleaning_service_pro_project_title_font_family != false){
		$custom_css .='#project .box .title {';
			if($cleaning_service_pro_project_title_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_project_title_color).';';
			if($cleaning_service_pro_project_title_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_project_title_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_project_text_color != false || $cleaning_service_pro_project_text_font_family != false){
		$custom_css .='#project .description {';
			if($cleaning_service_pro_project_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_project_text_color).';';
			if($cleaning_service_pro_project_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_project_text_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_project_btn_color != false || $cleaning_service_pro_project_btn_font_family != false){
		$custom_css .='#project .read-more {';
			if($cleaning_service_pro_project_btn_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_project_btn_color).';';
			if($cleaning_service_pro_project_btn_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_project_btn_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_project_btn_bgcolor != false){
		$custom_css .='#project .read-more {
			background: '.esc_html($cleaning_service_pro_project_btn_bgcolor).';
		}';
	}

	// Testimonial //

	if($cleaning_service_pro_testimonial_main_heading_color != false || $cleaning_service_pro_testimonial_main_heading_font_family != false){
		$custom_css .='#testimonial .main_para {';
			if($cleaning_service_pro_testimonial_main_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_testimonial_main_heading_color).';';
			if($cleaning_service_pro_testimonial_main_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_testimonial_main_heading_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_testimonial_main_heading_bgcolor != false){
		$custom_css .='#testimonial .main_para {
			color: '.esc_html($cleaning_service_pro_testimonial_main_heading_bgcolor).';
		}';
	}	
	if($cleaning_service_pro_testimonial_main_text_color != false || $cleaning_service_pro_testimonial_main_text_font_family != false){
		$custom_css .='#testimonial .main_heading{';
			if($cleaning_service_pro_testimonial_main_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_testimonial_main_text_color).';';
			if($cleaning_service_pro_testimonial_main_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_testimonial_main_text_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_testimonial_name_color != false || $cleaning_service_pro_testimonial_name_font_family != false){
			$custom_css .='.testimonial h5 {';
				if($cleaning_service_pro_testimonial_name_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_testimonial_name_color).';';
				if($cleaning_service_pro_testimonial_name_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_testimonial_name_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_testimonial_text_color != false || $cleaning_service_pro_testimonial_text_font_family != false){
		$custom_css .='.testimonial p {';
			if($cleaning_service_pro_testimonial_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_testimonial_text_color).';';
			if($cleaning_service_pro_testimonial_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_testimonial_text_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_testimonial_icon_color != false){
		$custom_css .='#testimonial .star {
			color: '.esc_html($cleaning_service_pro_testimonial_icon_color).';
		}';
	}


	// Newsletter //

	if($cleaning_service_pro_newsletter_main_heading_color != false || $cleaning_service_pro_newsletter_main_heading_font_family != false){
		$custom_css .='.newsletter-box h3 {';
			if($cleaning_service_pro_newsletter_main_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_newsletter_main_heading_color).';';
			if($cleaning_service_pro_newsletter_main_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_newsletter_main_heading_font_family).';';
		$custom_css .='}';
	}
	
	if($cleaning_service_pro_newsletter_main_text_color != false || $cleaning_service_pro_newsletter_main_text_font_family != false){
		$custom_css .='.newsletter-box p.text{';
			if($cleaning_service_pro_newsletter_main_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_newsletter_main_text_color).';';
			if($cleaning_service_pro_newsletter_main_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_newsletter_main_text_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_newsletter_button_color != false || $cleaning_service_pro_newsletter_button_font_family != false){
			$custom_css .='#newsletter input[type="submit"] {';
				if($cleaning_service_pro_newsletter_button_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_newsletter_button_color).';';
				if($cleaning_service_pro_newsletter_button_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_newsletter_button_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_newsletter_button_bgcolor != false){
		$custom_css .='#newsletter input[type="submit"] {
			background: '.esc_html($cleaning_service_pro_newsletter_button_bgcolor).';
		}';
	}
	if($cleaning_service_pro_newsletter_shortcode_bgcolor != false){
		$custom_css .='#newsletter input[type="email"] {
			background: '.esc_html($cleaning_service_pro_newsletter_shortcode_bgcolor).';
		}';
	}

	// How We work //

	if($cleaning_service_pro_how_we_work_main_heading_color != false || $cleaning_service_pro_how_we_work_main_heading_font_family != false){
		$custom_css .='#how_we_work .main_para {';
			if($cleaning_service_pro_how_we_work_main_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_how_we_work_main_heading_color).';';
			if($cleaning_service_pro_how_we_work_main_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_how_we_work_main_heading_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_how_we_work_main_heading_bgcolor != false){
		$custom_css .='#how_we_work .main_para {
			color: '.esc_html($cleaning_service_pro_how_we_work_main_heading_bgcolor).';
		}';
	}	
	if($cleaning_service_pro_how_we_work_main_text_color != false || $cleaning_service_pro_how_we_work_main_text_font_family != false){
		$custom_css .='#how_we_work .main_heading{';
			if($cleaning_service_pro_how_we_work_main_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_how_we_work_main_text_color).';';
			if($cleaning_service_pro_how_we_work_main_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_how_we_work_main_text_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_how_we_work_main_title_color != false || $cleaning_service_pro_how_we_work_main_title_font_family != false){
			$custom_css .='#how_we_work .how_we_work_content h5 {';
				if($cleaning_service_pro_how_we_work_main_title_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_how_we_work_main_title_color).';';
				if($cleaning_service_pro_how_we_work_main_title_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_how_we_work_main_title_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_how_we_work_text_color != false || $cleaning_service_pro_how_we_work_text_font_family != false){
		$custom_css .='#how_we_work .how_we_work_content p {';
			if($cleaning_service_pro_how_we_work_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_how_we_work_text_color).';';
			if($cleaning_service_pro_how_we_work_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_how_we_work_text_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_how_we_work_list_color != false || $cleaning_service_pro_how_we_work_list_font_family != false){
		$custom_css .='#how_we_work li {';
			if($cleaning_service_pro_how_we_work_list_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_how_we_work_list_color).';';
			if($cleaning_service_pro_how_we_work_list_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_how_we_work_list_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_how_we_work_btn_color != false || $cleaning_service_pro_how_we_work_btn_font_family != false){
		$custom_css .='#how_we_work .how_we_work_content .read-more {';
			if($cleaning_service_pro_how_we_work_btn_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_how_we_work_btn_color).';';
			if($cleaning_service_pro_how_we_work_btn_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_how_we_work_btn_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_how_we_work_btn_bgcolor != false){
		$custom_css .='#how_we_work .how_we_work_content .read-more {
			background: '.esc_html($cleaning_service_pro_how_we_work_btn_bgcolor).';
		}';
	}

	// Partner //

	if($cleaning_service_pro_partner_main_title_color != false || $cleaning_service_pro_partner_main_title_font_family != false){
		$custom_css .='#partner h5 {';
			if($cleaning_service_pro_partner_main_title_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_partner_main_title_color).';';
			if($cleaning_service_pro_partner_main_title_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_partner_main_title_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_partner_main_text_color != false || $cleaning_service_pro_partner_main_text_font_family != false){
		$custom_css .='#partner p {';
			if($cleaning_service_pro_partner_main_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_partner_main_text_color).';';
			if($cleaning_service_pro_partner_main_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_partner_main_text_font_family).';';
		$custom_css .='}';
	}

	// Team //

	if($cleaning_service_pro_team_main_heading_color != false || $cleaning_service_pro_team_main_heading_font_family != false){
		$custom_css .='#team .main_para {';
			if($cleaning_service_pro_team_main_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_team_main_heading_color).';';
			if($cleaning_service_pro_team_main_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_team_main_heading_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_team_main_heading_bgcolor != false){
		$custom_css .='#team .main_para {
			color: '.esc_html($cleaning_service_pro_team_main_heading_bgcolor).';
		}';
	}	
	if($cleaning_service_pro_team_main_text_color != false || $cleaning_service_pro_team_main_text_font_family != false){
		$custom_css .='#team .main_heading{';
			if($cleaning_service_pro_team_main_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_team_main_text_color).';';
			if($cleaning_service_pro_team_main_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_team_main_text_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_team_title_color != false || $cleaning_service_pro_team_title_font_family != false){
			$custom_css .='#team .post-title > a {';
				if($cleaning_service_pro_team_title_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_team_title_color).';';
				if($cleaning_service_pro_team_title_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_team_title_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_team_text_color != false || $cleaning_service_pro_team_text_font_family != false){
			$custom_css .='#team .post {';
				if($cleaning_service_pro_team_text_color != false)
					$custom_css .='color: '.esc_html($cleaning_service_pro_team_text_color).';';
				if($cleaning_service_pro_team_text_font_family != false)
					$custom_css .='font-family:'.esc_html($cleaning_service_pro_team_text_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_team_star_color != false){
		$custom_css .='#team .team-prof .star {
			color: '.esc_html($cleaning_service_pro_team_star_color).';
		}';
	}
	if($cleaning_service_pro_team_social_color != false){
		$custom_css .='#team .our-team .social li a {
			color: '.esc_html($cleaning_service_pro_team_social_color).';
		}';
	}
	if($cleaning_service_pro_team_social_bgcolor != false){
		$custom_css .='#team .our-team .social li a {
			background: '.esc_html($cleaning_service_pro_team_social_bgcolor).';
		}';
	}
	if($cleaning_service_pro_team_box_hover_color != false){
		$custom_css .='#team .social_media_team {
			color: '.esc_html($cleaning_service_pro_team_box_hover_color).';
		}';
	}
	if($cleaning_service_pro_team_box_hover_social_bgcolor != false){
		$custom_css .='#team .our-team .social li a:hover {
			background: '.esc_html($cleaning_service_pro_team_box_hover_social_bgcolor).';
		}';
	}

	// ---------------- Latest News -------------

	if($cleaning_service_pro_latest_news_main_heading_color != false || $cleaning_service_pro_latest_news_main_heading_font_family != false){
		$custom_css .='#latest_news .main_para{';
			if($cleaning_service_pro_latest_news_main_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_latest_news_main_heading_color).';';
			if($cleaning_service_pro_latest_news_main_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_latest_news_main_heading_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_latest_news_main_heading_bgcolor != false){
		$custom_css .='#latest_news .main_para{
			background: '.esc_html($cleaning_service_pro_latest_news_main_heading_bgcolor).';
		}';
	}

	if($cleaning_service_pro_latest_news_main_text_color != false || $cleaning_service_pro_latest_news_main_text_font_family != false){
		$custom_css .='#latest_news .main_heading {';
			if($cleaning_service_pro_latest_news_main_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_latest_news_main_text_color).';';
			if($cleaning_service_pro_latest_news_main_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_latest_news_main_text_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_latest_news_title_color != false || $cleaning_service_pro_latest_news_title_font_family != false){
		$custom_css .='#latest_news .post-slide .post-title {';
			if($cleaning_service_pro_latest_news_title_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_latest_news_title_color).';';
			if($cleaning_service_pro_latest_news_title_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_latest_news_title_font_family).';';
		$custom_css .='}';
	}
	
	if($cleaning_service_pro_latest_news_date_color != false || $cleaning_service_pro_latest_news_date_font_family != false){
		$custom_css .='#latest_news p.date {';
			if($cleaning_service_pro_latest_news_date_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_latest_news_date_color).';';
			if($cleaning_service_pro_latest_news_date_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_latest_news_date_font_family).';';
		$custom_css .='}';
	}
	
	if($cleaning_service_pro_latest_news_btn_color != false || $cleaning_service_pro_latest_news_btn_font_family != false){
		$custom_css .='#latest_news .post-slide .read-more {';
			if($cleaning_service_pro_latest_news_btn_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_latest_news_btn_color).';';
			if($cleaning_service_pro_latest_news_btn_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_latest_news_btn_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_latest_news_btn_bgcolor != false){
		$custom_css .='#latest_news .post-slide .read-more {
			background: '.esc_html($cleaning_service_pro_latest_news_btn_bgcolor).';
		}';
	}

	// ---------------- Banner -------------

	if($cleaning_service_pro_add_title_color != false || $cleaning_service_pro_add_title_font_family != false){
		$custom_css .='#add h3.head {';
			if($cleaning_service_pro_add_title_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_add_title_color).';';
			if($cleaning_service_pro_add_title_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_add_title_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_add_text_color != false || $cleaning_service_pro_add_text_font_family != false){
		$custom_css .='#add p.text {';
			if($cleaning_service_pro_add_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_add_text_color).';';
			if($cleaning_service_pro_add_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_add_text_font_family).';';
		$custom_css .='}';
	}

	// --------------- Faq ----------------

	if($cleaning_service_pro_faq_main_heading_color != false || $cleaning_service_pro_faq_main_heading_font_family != false){
		$custom_css .='#faq .main_heading {';
			if($cleaning_service_pro_faq_main_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_faq_main_heading_color).';';
			if($cleaning_service_pro_faq_main_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_faq_main_heading_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_faq_title_color != false || $cleaning_service_pro_faq_title_font_family != false){
		$custom_css .='#accordion .panel-title a {';
			if($cleaning_service_pro_faq_title_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_faq_title_color).';';
			if($cleaning_service_pro_faq_title_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_faq_title_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_faq_text_color != false || $cleaning_service_pro_faq_text_font_family != false){
		$custom_css .='#accordion .panel-body p {';
			if($cleaning_service_pro_faq_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_faq_text_color).';';
			if($cleaning_service_pro_faq_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_faq_text_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_faq_title_hover_color != false){
		$custom_css .='#accordion .panel-title a.collapsed:hover {
			color: '.esc_html($cleaning_service_pro_faq_title_hover_color).';
		}';
	}
	if($cleaning_service_pro_faq_icon_hover_bgcolor != false){
		$custom_css .='#accordion .panel-title a.collapsed:hover:before {
			background: '.esc_html($cleaning_service_pro_faq_icon_hover_bgcolor).';
		}';
	}
	if($cleaning_service_pro_faq_hover_line_color != false){
		$custom_css .='#accordion .panel-title a.collapsed:hover {
			border-color: '.esc_html($cleaning_service_pro_faq_hover_line_color).';
		}';
	}

	// Product //

	if($cleaning_service_pro_product_main_heading_color != false || $cleaning_service_pro_product_main_heading_font_family != false){
		$custom_css .='#product .main_para {';
			if($cleaning_service_pro_product_main_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_product_main_heading_color).';';
			if($cleaning_service_pro_product_main_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_product_main_heading_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_product_main_heading_bgcolor != false){
		$custom_css .='#product .main_para {
			background: '.esc_html($cleaning_service_pro_product_main_heading_bgcolor).';
		}';
	}

	if($cleaning_service_pro_product_main_title_color != false || $cleaning_service_pro_product_main_title_font_family != false){
		$custom_css .='#product .main_heading {';
			if($cleaning_service_pro_product_main_title_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_product_main_title_color).';';
			if($cleaning_service_pro_product_main_title_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_product_main_title_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_product_main_text_color != false || $cleaning_service_pro_product_main_text_font_family != false){
		$custom_css .='#product .text {';
			if($cleaning_service_pro_product_main_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_product_main_text_color).';';
			if($cleaning_service_pro_product_main_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_product_main_text_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_product_title_color != false || $cleaning_service_pro_product_title_font_family != false){
		$custom_css .='#product .product-content h5 {';
			if($cleaning_service_pro_product_title_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_product_title_color).';';
			if($cleaning_service_pro_product_title_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_product_title_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_product_text_color != false || $cleaning_service_pro_product_text_font_family != false){
		$custom_css .='#product .product-content p {';
			if($cleaning_service_pro_product_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_product_text_color).';';
			if($cleaning_service_pro_product_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_product_text_font_family).';';
		$custom_css .='}';
	}

	//  Home Contact //

	if($cleaning_service_pro_contact_title_color != false || $cleaning_service_pro_contact_title_font_family != false){
		$custom_css .='#contact .main_heading {';
			if($cleaning_service_pro_contact_title_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_contact_title_color).';';
			if($cleaning_service_pro_contact_title_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_contact_title_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_contact_text_color != false || $cleaning_service_pro_contact_text_font_family != false){
		$custom_css .='#contact .contact-content p {';
			if($cleaning_service_pro_contact_text_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_contact_text_color).';';
			if($cleaning_service_pro_contact_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_contact_text_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_contact_icon_color != false){
		$custom_css .='#contact .contact-content i{
			color: '.esc_html($cleaning_service_pro_contact_icon_color).';
		}';
	}

	if($cleaning_service_pro_contact_box_bgcolor != false){
		$custom_css .='#contact .bg {
			background: '.esc_html($cleaning_service_pro_contact_box_bgcolor).';
		}';
	}
	
	/* Footer Widgets */

	if($cleaning_service_pro_footer_widget_heading_color != false || $cleaning_service_pro_footer_widget_heading_font_family != false){
		$custom_css .='#footer h3,.heading3{';
			if($cleaning_service_pro_footer_widget_heading_color != false)
				$custom_css .='color:'.esc_html($cleaning_service_pro_footer_widget_heading_color).';';
			if($cleaning_service_pro_footer_widget_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_footer_widget_heading_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_footer_widget_content_color != false || $cleaning_service_pro_footer_widget_content_font_family != false){
		$custom_css .='#footer p, #footer ul li, #footer ul li a, #footer a, #footer ul span, #footer tr, #footer td, #footer th,#footer .widget.widget_calendar td, #footer .widget.widget_calendar tr, #footer .widget.widget_calendar th,#footer form.search-form input,.widget_calendar caption,#footer .about_me table p{';
			if($cleaning_service_pro_footer_widget_content_color != false)
				$custom_css .='color:'.esc_html($cleaning_service_pro_footer_widget_content_color).';';
			if($cleaning_service_pro_footer_widget_content_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_footer_widget_content_font_family).';';
		$custom_css .='}';
	}

	/* Footer Copyright */

	if($cleaning_service_pro_footer_copy_content_color != false || $cleaning_service_pro_footer_copy_content_font_family != false){
		$custom_css .='.copyright .copy-text p,#footer .copyright p{';
			if($cleaning_service_pro_footer_copy_content_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_footer_copy_content_color).';';
			if($cleaning_service_pro_footer_copy_content_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_footer_copy_content_font_family).';';
		$custom_css .='}';
	}

	/* Contact Page */
	
	if($cleaning_service_pro_contact_page_heading_color != false || $cleaning_service_pro_contact_page_heading_font_family != false){
		$custom_css .='.main_title h1,.contact-color-bg h3{';
			if($cleaning_service_pro_contact_page_heading_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_contact_page_heading_color).';';
			if($cleaning_service_pro_contact_page_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_contact_page_heading_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_contact_page_content_color != false || $cleaning_service_pro_contact_page_contact_font_family != false){
		$custom_css .='.c_content span,.contact-page-details span{';
			if($cleaning_service_pro_contact_page_content_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_contact_page_content_color).';';
			if($cleaning_service_pro_contact_page_contact_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_contact_page_contact_font_family).';';
		$custom_css .='}';
	}
	if($cleaning_service_pro_contact_page_contents_color != false || $cleaning_service_pro_contact_page_contacts_font_family != false){
		$custom_css .='.contact-page-details .inner-cont p{';
			if($cleaning_service_pro_contact_page_contents_color != false)
				$custom_css .='color: '.esc_html($cleaning_service_pro_contact_page_contents_color).';';
			if($cleaning_service_pro_contact_page_contacts_font_family != false)
				$custom_css .='font-family:'.esc_html($cleaning_service_pro_contact_page_contacts_font_family).';';
		$custom_css .='}';
	}

	if($cleaning_service_pro_contact_page_icon_color != false){
		$custom_css .='.contact-page-details .inner-cont i{
			color: '.esc_html($cleaning_service_pro_contact_page_icon_color).';
		}';
	}