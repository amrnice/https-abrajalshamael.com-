<?php
	$wp_customize->add_section('cleaning_service_pro_slider_section',array(
		'title'	=> __('Slider Settings','cleaning-service-pro'),
		'description'	=> __('Add slider images here.','cleaning-service-pro'),
		'priority'	=> null,
		'panel' => 'cleaning_service_pro_panel_id',
	));
	$wp_customize->add_setting( 'cleaning_service_pro_slider_enabledisable',
		array(
		  'default' => 1,
		  'transport' => 'refresh',
		  'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
	));
	$wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_slider_enabledisable',
	  	array(
	    'label' => esc_html__( 'Show or Hide Slider Section', 'cleaning-service-pro' ),
	    'section' => 'cleaning_service_pro_slider_section'
	)));
    $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_slider_enabledisable', array(
	    'selector' => '.slider-box',
	    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_slider_enabledisable',
	) );

	$wp_customize->add_setting('cleaning_service_pro_slide_number',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field',
	));
	$wp_customize->add_control('cleaning_service_pro_slide_number',array(
		'label'	=> __('Number of slides to show','cleaning-service-pro'),
		'section'	=> 'cleaning_service_pro_slider_section',
		'type'		=> 'number'
	));
	$count =  get_theme_mod('cleaning_service_pro_slide_number');
		
	for($i=1; $i<=$count; $i++ ) {
		

		$wp_customize->add_setting( 'cleaning_service_pro_slider_section_settings'.$i,
		    array(
		    'default' => '',
		    'transport' => 'postMessage',
		    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
		 ));
		 $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_slider_section_settings'.$i,
		    array(
		    'label' => __('Slider Settings ','cleaning-service-pro').$i,
		    'section' => 'cleaning_service_pro_slider_section'
		)));

		$wp_customize->add_setting('cleaning_service_pro_slide_image'.$i,array(
			'default'	=> '',
			'sanitize_callback'	=> 'esc_url_raw',
		));
		$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_slide_image'.$i,
	        array(
            'label' => __('Slider Image ','cleaning-service-pro').$i.__(' (1600x562)','cleaning-service-pro'),
            'section' => 'cleaning_service_pro_slider_section',
            'settings' => 'cleaning_service_pro_slide_image'.$i
		)));
		
		$wp_customize->add_setting('cleaning_service_pro_slide_main_heading'.$i,array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field',
		));
		$wp_customize->add_control('cleaning_service_pro_slide_main_heading'.$i,array(
			'label' => __('Slide Main Heading ','cleaning-service-pro').$i,
			'section' => 'cleaning_service_pro_slider_section',
			'setting'	=> 'cleaning_service_pro_slide_main_heading'.$i,
			'type'	=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_slide_heading'.$i,array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field',
		));
		$wp_customize->add_control('cleaning_service_pro_slide_heading'.$i,array(
			'label' => __('Slide Title ','cleaning-service-pro').$i,
			'section' => 'cleaning_service_pro_slider_section',
			'setting'	=> 'cleaning_service_pro_slide_heading'.$i,
			'type'	=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_slide_text'.$i,array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_textarea_field',
		));
		$wp_customize->add_control('cleaning_service_pro_slide_text'.$i,array(
			'label' => __('Slide Text ','cleaning-service-pro').$i,
			'section' => 'cleaning_service_pro_slider_section',
			'setting'	=> 'cleaning_service_pro_slide_text'.$i,
			'type'	=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_slide_btn'.$i,array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_textarea_field',
		));
		$wp_customize->add_control('cleaning_service_pro_slide_btn'.$i,array(
			'label' => __('Slide Button ','cleaning-service-pro').$i,
			'section' => 'cleaning_service_pro_slider_section',
			'setting'	=> 'cleaning_service_pro_slide_btn'.$i,
			'type'	=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_slide_btn_url'.$i,array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_textarea_field',
		));
		$wp_customize->add_control('cleaning_service_pro_slide_btn_url'.$i,array(
			'label' => __('Slide Button Url ','cleaning-service-pro').$i,
			'section' => 'cleaning_service_pro_slider_section',
			'setting'	=> 'cleaning_service_pro_slide_btn_url'.$i,
			'type'	=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_slide_btn1'.$i,array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_textarea_field',
		));
		$wp_customize->add_control('cleaning_service_pro_slide_btn1'.$i,array(
			'label' => __('Slide Button-1 ','cleaning-service-pro').$i,
			'section' => 'cleaning_service_pro_slider_section',
			'setting'	=> 'cleaning_service_pro_slide_btn1'.$i,
			'type'	=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_slide_btn1_url'.$i,array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_textarea_field',
		));
		$wp_customize->add_control('cleaning_service_pro_slide_btn1_url'.$i,array(
			'label' => __('Slide Button-1 Url ','cleaning-service-pro').$i,
			'section' => 'cleaning_service_pro_slider_section',
			'setting'	=> 'cleaning_service_pro_slide_btn1_url'.$i,
			'type'	=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_slide_icon'.$i,array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_textarea_field',
		));
		$wp_customize->add_control('cleaning_service_pro_slide_icon'.$i,array(
			'label' => __('Slide Clock Icon ','cleaning-service-pro').$i,
			'section' => 'cleaning_service_pro_slider_section',
			'setting'	=> 'cleaning_service_pro_slide_icon'.$i,
			'type'	=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_slide_days'.$i,array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_textarea_field',
		));
		$wp_customize->add_control('cleaning_service_pro_slide_days'.$i,array(
			'label' => __('Slide Days ','cleaning-service-pro').$i,
			'section' => 'cleaning_service_pro_slider_section',
			'setting'	=> 'cleaning_service_pro_slide_days'.$i,
			'type'	=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_slide_time'.$i,array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_textarea_field',
		));
		$wp_customize->add_control('cleaning_service_pro_slide_time'.$i,array(
			'label' => __('Slide Time ','cleaning-service-pro').$i,
			'section' => 'cleaning_service_pro_slider_section',
			'setting'	=> 'cleaning_service_pro_slide_time'.$i,
			'type'	=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_slide_discount_head'.$i,array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_textarea_field',
		));
		$wp_customize->add_control('cleaning_service_pro_slide_discount_head'.$i,array(
			'label' => __('Slide Discount Heading','cleaning-service-pro').$i,
			'section' => 'cleaning_service_pro_slider_section',
			'setting'	=> 'cleaning_service_pro_slide_discount_head'.$i,
			'type'	=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_slide_discount_number'.$i,array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_textarea_field',
		));
		$wp_customize->add_control('cleaning_service_pro_slide_discount_number'.$i,array(
			'label' => __('Slide Discount Number ','cleaning-service-pro').$i,
			'section' => 'cleaning_service_pro_slider_section',
			'setting'	=> 'cleaning_service_pro_slide_discount_number'.$i,
			'type'	=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_slide_discount_text'.$i,array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_textarea_field',
		));
		$wp_customize->add_control('cleaning_service_pro_slide_discount_text'.$i,array(
			'label' => __('Slide Discount Text ','cleaning-service-pro').$i,
			'section' => 'cleaning_service_pro_slider_section',
			'setting'	=> 'cleaning_service_pro_slide_discount_text'.$i,
			'type'	=> 'text'
		));
	}

    $wp_customize->add_setting( 'cleaning_service_pro_slider_section_color_setting',
		    array(
		    'default' => '',
		    'transport' => 'postMessage',
		    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
	 ));
	 $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_slider_section_color_setting',
	    array(
	    'label' => __('Slider Color Settings ','cleaning-service-pro'),
	    'section' => 'cleaning_service_pro_slider_section'
	)));
	// This is Slider Heading Color picker setting
	$wp_customize->add_setting( 'cleaning_service_pro_slider_main_Heading_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_slider_main_Heading_color', array(
		'label' => __('Slider Main Heading Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_slider_section',
		'settings' => 'cleaning_service_pro_slider_main_Heading_color',
	)));
	//This is Slider Heading FontFamily picker setting
	$wp_customize->add_setting('cleaning_service_pro_slider_main_Heading_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
	));
	$wp_customize->add_control(
	    'cleaning_service_pro_slider_main_Heading_font_family', array(
	    'section'  => 'cleaning_service_pro_slider_section',
	    'label'    => __( 'Slider Main Heading Fonts','cleaning-service-pro'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));
	// This is Slider Heading Color picker setting
	$wp_customize->add_setting( 'cleaning_service_pro_sliderHeading_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_sliderHeading_color', array(
		'label' => __('Slider Title Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_slider_section',
		'settings' => 'cleaning_service_pro_sliderHeading_color',
	)));
	//This is Slider Heading FontFamily picker setting
	$wp_customize->add_setting('cleaning_service_pro_sliderHeading_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
	));
	$wp_customize->add_control(
	    'cleaning_service_pro_sliderHeading_font_family', array(
	    'section'  => 'cleaning_service_pro_slider_section',
	    'label'    => __( 'Slider Title Fonts','cleaning-service-pro'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));
	// This is Slider Text Color picker setting
	$wp_customize->add_setting( 'cleaning_service_pro_slidertext_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_slidertext_color', array(
		'label' => __('Slider Text Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_slider_section',
		'settings' => 'cleaning_service_pro_slidertext_color',
	)));
	//This is Slider Text FontFamily picker setting
	$wp_customize->add_setting('cleaning_service_pro_slidertext_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
	));
	$wp_customize->add_control(
	    'cleaning_service_pro_slidertext_font_family', array(
	    'section'  => 'cleaning_service_pro_slider_section',
	    'label'    => __( 'Slider Text Fonts','cleaning-service-pro'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));
	$wp_customize->add_setting( 'cleaning_service_pro_slider_btn_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_slider_btn_color', array(
		'label' => __('Slider Button Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_slider_section',
		'settings' => 'cleaning_service_pro_slider_btn_color',
	)));
	$wp_customize->add_setting('cleaning_service_pro_slider_btn_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
	));
	$wp_customize->add_control(
	    'cleaning_service_pro_slider_btn_font_family', array(
	    'section'  => 'cleaning_service_pro_slider_section',
	    'label'    => __( 'Slider Button Fonts','cleaning-service-pro'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));
	$wp_customize->add_setting( 'cleaning_service_pro_slider_btn1_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_slider_btn1_color', array(
		'label' => __('Slider Button-1 Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_slider_section',
		'settings' => 'cleaning_service_pro_slider_btn1_color',
	)));
	$wp_customize->add_setting('cleaning_service_pro_slider_btn1_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
	));
	$wp_customize->add_control(
	    'cleaning_service_pro_slider_btn1_font_family', array(
	    'section'  => 'cleaning_service_pro_slider_section',
	    'label'    => __( 'Slider Button-1 Fonts','cleaning-service-pro'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));
	$wp_customize->add_setting( 'cleaning_service_pro_slider_btn_bgcolor', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_slider_btn_bgcolor', array(
		'label' => __('Slider Button Background Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_slider_section',
		'settings' => 'cleaning_service_pro_slider_btn_bgcolor',
	)));
	$wp_customize->add_setting( 'cleaning_service_pro_slider_btn1_bgcolor', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_slider_btn1_bgcolor', array(
		'label' => __('Slider Button-1 Background Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_slider_section',
		'settings' => 'cleaning_service_pro_slider_btn1_bgcolor',
	)));
	$wp_customize->add_setting( 'cleaning_service_pro_slider_clock_icon_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_slider_clock_icon_color', array(
		'label' => __('Slider CLock Icon Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_slider_section',
		'settings' => 'cleaning_service_pro_slider_clock_icon_color',
	)));
	$wp_customize->add_setting( 'cleaning_service_pro_slider_clock_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_slider_clock_color', array(
		'label' => __('Slider CLock Text Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_slider_section',
		'settings' => 'cleaning_service_pro_slider_clock_color',
	)));
	$wp_customize->add_setting('cleaning_service_pro_slider_clock_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
	));
	$wp_customize->add_control(
	    'cleaning_service_pro_slider_clock_font_family', array(
	    'section'  => 'cleaning_service_pro_slider_section',
	    'label'    => __( 'Slider CLock Text Fonts','cleaning-service-pro'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));
	$wp_customize->add_setting( 'cleaning_service_pro_slider_clock_bgcolor', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_slider_clock_bgcolor', array(
		'label' => __('Slider Weekend Background Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_slider_section',
		'settings' => 'cleaning_service_pro_slider_clock_bgcolor',
	)));
	$wp_customize->add_setting( 'cleaning_service_pro_slider_discount_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_slider_discount_color', array(
		'label' => __('Slider Discount Text Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_slider_section',
		'settings' => 'cleaning_service_pro_slider_discount_color',
	)));
	$wp_customize->add_setting('cleaning_service_pro_slider_discount_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
	));
	$wp_customize->add_control(
	    'cleaning_service_pro_slider_discount_font_family', array(
	    'section'  => 'cleaning_service_pro_slider_section',
	    'label'    => __( 'Slider Discount Text Fonts','cleaning-service-pro'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));
	$wp_customize->add_setting( 'cleaning_service_pro_slider_discount_bgcolor', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_slider_discount_bgcolor', array(
		'label' => __('Slider Discount Background Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_slider_section',
		'settings' => 'cleaning_service_pro_slider_discount_bgcolor',
	)));
?>