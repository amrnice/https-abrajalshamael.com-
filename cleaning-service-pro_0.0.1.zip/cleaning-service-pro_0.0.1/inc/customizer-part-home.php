<?php

/* Service */
  $wp_customize->add_section('cleaning_service_pro_service',array(
    'title' => __('Service','cleaning-service-pro'),
    'description' => __('Add Service Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_service_enable',
   array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
   ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_service_enable',
      array(
        'label' => esc_html__( 'Show or Hide Service Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_service'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_service_enable', array(
    'selector' => '#service .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_service_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_service_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_service_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_service'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_service_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_service_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_service',
    'settings' => 'cleaning_service_pro_service_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_service_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_service_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_service',
    'settings' => 'cleaning_service_pro_service_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_service_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_service_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_service'
  )));
  $wp_customize->add_setting('cleaning_service_pro_service_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_service_main_heading',array(
    'label' => __('Section Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_service',
    'setting' => 'cleaning_service_pro_service_main_heading',
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_service_main_para',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_service_main_para',array(
    'label' => __('Section Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_service',
    'setting' => 'cleaning_service_pro_service_main_para',
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_service_count',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_service_count',array(
    'label' => __('No Of Service To Show','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_service',
    'setting' => 'cleaning_service_pro_service_count',
    'type'    => 'number'
  ));
   
  $service_count = get_theme_mod('cleaning_service_pro_service_count');

  for($i=1; $i<=$service_count; $i++) {

    $wp_customize->add_setting('cleaning_service_pro_service_image'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_service_image'.$i,
          array(
            'label' => __('Service Image ','cleaning-service-pro').$i,
            'section' => 'cleaning_service_pro_service',
            'settings' => 'cleaning_service_pro_service_image'.$i
    )));
    $wp_customize->add_setting('cleaning_service_pro_service_title'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_service_title'.$i,array(
      'label' => __('Service Title','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_service',
      'setting' => 'cleaning_service_pro_service_title'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_service_text'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_service_text'.$i,array(
      'label' => __('Service Text','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_service',
      'setting' => 'cleaning_service_pro_service_text'.$i,
      'type'  => 'textarea'
    ));
    $wp_customize->add_setting('cleaning_service_pro_service_btn'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_service_btn'.$i,array(
      'label' => __('Service Button','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_service',
      'setting' => 'cleaning_service_pro_service_btn'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_service_btn_url'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_service_btn_url'.$i,array(
      'label' => __('Service Button Url','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_service',
      'setting' => 'cleaning_service_pro_service_btn_url'.$i,
      'type'  => 'text'
    ));
  }

  $wp_customize->add_setting( 'cleaning_service_pro_service_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_service_color_settings',
      array(
      'label' => __('Service Section Color Settings ','cleaning-service-pro'),
      'section' => 'cleaning_service_pro_service'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_service_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_service_main_heading_color', array(
    'label' => __('Section Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_service',
    'settings' => 'cleaning_service_pro_service_main_heading_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_service_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_service_main_heading_font_family', array(
      'section'  => 'cleaning_service_pro_service',
      'label'    => __( 'Section Heading Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_service_main_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_service_main_text_color', array(
    'label' => __('Section Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_service',
    'settings' => 'cleaning_service_pro_service_main_text_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_service_main_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_service_main_text_font_family', array(
      'section'  => 'cleaning_service_pro_service',
      'label'    => __( 'Section Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_service_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_service_title_color', array(
    'label' => __('Service Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_service',
    'settings' => 'cleaning_service_pro_service_title_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_service_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_service_title_font_family', array(
      'section'  => 'cleaning_service_pro_service',
      'label'    => __( 'Service Title Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_service_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_service_text_color', array(
    'label' => __('Service Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_service',
    'settings' => 'cleaning_service_pro_service_text_color',
  )));
 
  $wp_customize->add_setting('cleaning_service_pro_service_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_service_text_font_family', array(
      'section'  => 'cleaning_service_pro_service',
      'label'    => __( 'Service Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_service_btn_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_service_btn_color', array(
    'label' => __('Service Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_service',
    'settings' => 'cleaning_service_pro_service_btn_color',
  )));
 
  $wp_customize->add_setting('cleaning_service_pro_service_btn_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_service_btn_font_family', array(
      'section'  => 'cleaning_service_pro_service',
      'label'    => __( 'Service Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_service_btn_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_service_btn_bgcolor', array(
    'label' => __('Service Button Background', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_service',
    'settings' => 'cleaning_service_pro_service_btn_bgcolor',
  )));

/* About */

  $wp_customize->add_section('cleaning_service_pro_about',array(
    'title' => __('About','cleaning-service-pro'),
    'description' => __('Add About Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_about_enable',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
  ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_about_enable',
      array(
        'label' => esc_html__( 'Show or Hide About Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_about'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_about_enable', array(
    'selector' => '#about .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_about_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_about_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_about_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_about_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_about_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'settings' => 'cleaning_service_pro_about_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_about_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_about_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'settings' => 'cleaning_service_pro_about_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_about_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_about_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about'
  )));

  $wp_customize->add_setting('cleaning_service_pro_about_left_image',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_about_left_image',
        array(
          'label' => __('About Left Image ','cleaning-service-pro'),
          'section' => 'cleaning_service_pro_about',
          'settings' => 'cleaning_service_pro_about_left_image'
  )));

  $wp_customize->add_setting('cleaning_service_pro_about_left_number',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_about_left_number',array(
    'label' => __('About Left Number','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'setting' => 'cleaning_service_pro_about_left_number',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cleaning_service_pro_about_left_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_about_left_text',array(
    'label' => __('About Left Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'setting' => 'cleaning_service_pro_about_left_text',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cleaning_service_pro_about_title',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_about_title',array(
    'label' => __('Section Title','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'setting' => 'cleaning_service_pro_about_title',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cleaning_service_pro_about_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_about_main_heading',array(
    'label' => __('Section Main Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'setting' => 'cleaning_service_pro_about_main_heading',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cleaning_service_pro_about_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_about_text',array(
    'label' => __('Section Main Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'setting' => 'cleaning_service_pro_about_text',
    'type'    => 'textarea'
  )); 

  for($i=1; $i<=4; $i++) {

    $wp_customize->add_setting('cleaning_service_pro_about_list_icon'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_about_list_icon'.$i,array(
      'label' => __('About List Icon','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_about',
      'setting' => 'cleaning_service_pro_about_list_icon'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_about_list_text'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_about_list_text'.$i,array(
      'label' => __('About List Text','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_about',
      'setting' => 'cleaning_service_pro_about_list_text'.$i,
      'type'  => 'text'
    ));
  }
  $wp_customize->add_setting('cleaning_service_pro_about_phone_title',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_about_phone_title',array(
    'label' => __('About Phone Title','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'setting' => 'cleaning_service_pro_about_phone_title',
    'type'    => 'text'
  )); 
  $wp_customize->add_setting('cleaning_service_pro_about_phone_icon',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_about_phone_icon',array(
    'label' => __('About Phone Icon','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'setting' => 'cleaning_service_pro_about_phone_icon',
    'type'    => 'text'
  )); 
  $wp_customize->add_setting('cleaning_service_pro_about_phone_number',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_about_phone_number',array(
    'label' => __('About Phone Number','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'setting' => 'cleaning_service_pro_about_phone_number',
    'type'    => 'text'
  )); 
  $wp_customize->add_setting( 'cleaning_service_pro_about_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_about_color_settings',
    array(
    'label' => __('About Section Color Settings ','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_about_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_about_main_heading_color', array(
    'label' => __('About Main Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'settings' => 'cleaning_service_pro_about_main_heading_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_about_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_about_main_heading_font_family', array(
      'section'  => 'cleaning_service_pro_about',
      'label'    => __( 'About Main Heading Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_about_main_heading_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_about_main_heading_bgcolor', array(
    'label' => __('About Main Heading Background', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'settings' => 'cleaning_service_pro_about_main_heading_bgcolor',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_about_main_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_about_main_title_color', array(
    'label' => __('About Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'settings' => 'cleaning_service_pro_about_main_title_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_about_main_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_about_main_title_font_family', array(
      'section'  => 'cleaning_service_pro_about',
      'label'    => __( 'About Title Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_about_main_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_about_main_text_color', array(
    'label' => __('About Main Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'settings' => 'cleaning_service_pro_about_main_text_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_about_main_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_about_main_text_font_family', array(
      'section'  => 'cleaning_service_pro_about',
      'label'    => __( 'About Main Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
 $wp_customize->add_setting( 'cleaning_service_pro_about_list_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_about_list_color', array(
    'label' => __('About List Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'settings' => 'cleaning_service_pro_about_list_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_about_list_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_about_list_font_family', array(
      'section'  => 'cleaning_service_pro_about',
      'label'    => __( 'About List Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_about_phone_head_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_about_phone_head_color', array(
    'label' => __('About Phone Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'settings' => 'cleaning_service_pro_about_phone_head_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_about_phone_head_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_about_phone_head_font_family', array(
      'section'  => 'cleaning_service_pro_about',
      'label'    => __( 'About Phone Number Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_about_phone_number_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_about_phone_number_color', array(
    'label' => __('About Phone Number Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'settings' => 'cleaning_service_pro_about_phone_number_color',
  )));
 
  $wp_customize->add_setting('cleaning_service_pro_about_phone_number_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_about_phone_number_font_family', array(
      'section'  => 'cleaning_service_pro_about',
      'label'    => __( 'About Phone Number Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_about_left_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_about_left_text_color', array(
    'label' => __('About Left Box Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'settings' => 'cleaning_service_pro_about_left_text_color',
  )));
 
  $wp_customize->add_setting('cleaning_service_pro_about_left_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_about_left_text_font_family', array(
      'section'  => 'cleaning_service_pro_about',
      'label'    => __( 'About Left Box Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_about_left_box_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_about_left_box_bgcolor', array(
    'label' => __('About Left Box Background', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_about',
    'settings' => 'cleaning_service_pro_about_left_box_bgcolor',
  )));

/* What we do */
  $wp_customize->add_section('cleaning_service_pro_what_we_do',array(
    'title' => __('What We Do','cleaning-service-pro'),
    'description' => __('Add What We Do Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_what_we_do_enable',
   array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
   ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_what_we_do_enable',
      array(
        'label' => esc_html__( 'Show or Hide What We Do Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_what_we_do'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_what_we_do_enable', array(
    'selector' => '#what_we_do .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_what_we_do_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_what_we_do_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_what_we_do_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_what_we_do'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_what_we_do_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_what_we_do_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_what_we_do',
    'settings' => 'cleaning_service_pro_what_we_do_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_what_we_do_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_what_we_do_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_what_we_do',
    'settings' => 'cleaning_service_pro_what_we_do_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_what_we_do_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_what_we_do_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_what_we_do'
  )));
  $wp_customize->add_setting('cleaning_service_pro_what_we_do_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_what_we_do_main_heading',array(
    'label' => __('Section Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_what_we_do',
    'setting' => 'cleaning_service_pro_what_we_do_main_heading',
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_what_we_do_main_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_what_we_do_main_text',array(
    'label' => __('Section Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_what_we_do',
    'setting' => 'cleaning_service_pro_what_we_do_main_text',
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_what_we_do_count',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_what_we_do_count',array(
    'label' => __('No Of What We Do To Show','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_what_we_do',
    'setting' => 'cleaning_service_pro_what_we_do_count',
    'type'    => 'number'
  ));
   
  $what_count = get_theme_mod('cleaning_service_pro_what_we_do_count');

  for($i=1; $i<=$what_count; $i++) {

    $wp_customize->add_setting('cleaning_service_pro_what_we_do_bgimage'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_what_we_do_bgimage'.$i,
          array(
            'label' => __('What We Do Background Image ','cleaning-service-pro').$i,
            'section' => 'cleaning_service_pro_what_we_do',
            'settings' => 'cleaning_service_pro_what_we_do_bgimage'.$i
    )));
    $wp_customize->add_setting('cleaning_service_pro_what_we_do_image'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_what_we_do_image'.$i,
          array(
            'label' => __('What We Do Image ','cleaning-service-pro').$i,
            'section' => 'cleaning_service_pro_what_we_do',
            'settings' => 'cleaning_service_pro_what_we_do_image'.$i
    )));
    $wp_customize->add_setting('cleaning_service_pro_what_we_do_title'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_what_we_do_title'.$i,array(
      'label' => __('What We Do Title','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_what_we_do',
      'setting' => 'cleaning_service_pro_what_we_do_title'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_what_we_do_text'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_what_we_do_text'.$i,array(
      'label' => __('What We Do Text','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_what_we_do',
      'setting' => 'cleaning_service_pro_what_we_do_text'.$i,
      'type'  => 'textarea'
    ));
    $wp_customize->add_setting('cleaning_service_pro_what_we_do_btn'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_what_we_do_btn'.$i,array(
      'label' => __('What We Do Button','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_what_we_do',
      'setting' => 'cleaning_service_pro_what_we_do_btn'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_what_we_do_btn_url'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_what_we_do_btn_url'.$i,array(
      'label' => __('What We Do Button Url','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_what_we_do',
      'setting' => 'cleaning_service_pro_what_we_do_btn_url'.$i,
      'type'  => 'text'
    ));
  }

  $wp_customize->add_setting( 'cleaning_service_pro_what_we_do_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_what_we_do_color_settings',
      array(
      'label' => __('What We Do Section Color Settings ','cleaning-service-pro'),
      'section' => 'cleaning_service_pro_what_we_do'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_what_we_do_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_what_we_do_main_heading_color', array(
    'label' => __('Section Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_what_we_do',
    'settings' => 'cleaning_service_pro_what_we_do_main_heading_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_what_we_do_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_what_we_do_main_heading_font_family', array(
      'section'  => 'cleaning_service_pro_what_we_do',
      'label'    => __( 'Section Heading Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_what_we_do_main_heading_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_what_we_do_main_heading_bgcolor', array(
    'label' => __('Section Heading Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_what_we_do',
    'settings' => 'cleaning_service_pro_what_we_do_main_heading_bgcolor',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_what_we_do_main_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_what_we_do_main_text_color', array(
    'label' => __('Section Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_what_we_do',
    'settings' => 'cleaning_service_pro_what_we_do_main_text_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_what_we_do_main_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_what_we_do_main_text_font_family', array(
      'section'  => 'cleaning_service_pro_what_we_do',
      'label'    => __( 'Section Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_what_we_do_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_what_we_do_title_color', array(
    'label' => __('What We Do Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_what_we_do',
    'settings' => 'cleaning_service_pro_what_we_do_title_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_what_we_do_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_what_we_do_title_font_family', array(
      'section'  => 'cleaning_service_pro_what_we_do',
      'label'    => __( 'What We Do Title Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_what_we_do_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_what_we_do_text_color', array(
    'label' => __('What We Do Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_what_we_do',
    'settings' => 'cleaning_service_pro_what_we_do_text_color',
  )));
 
  $wp_customize->add_setting('cleaning_service_pro_what_we_do_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_what_we_do_text_font_family', array(
      'section'  => 'cleaning_service_pro_what_we_do',
      'label'    => __( 'What We Do Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_what_we_do_btn_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_what_we_do_btn_color', array(
    'label' => __('What We Do Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_what_we_do',
    'settings' => 'cleaning_service_pro_what_we_do_btn_color',
  )));
 
  $wp_customize->add_setting('cleaning_service_pro_what_we_do_btn_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_what_we_do_btn_font_family', array(
      'section'  => 'cleaning_service_pro_what_we_do',
      'label'    => __( 'What We Do Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_what_we_do_btn_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_what_we_do_btn_bgcolor', array(
    'label' => __('What We Do Button Background', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_what_we_do',
    'settings' => 'cleaning_service_pro_what_we_do_btn_bgcolor',
  )));

/* Why Choose Us */

  $wp_customize->add_section('cleaning_service_pro_why_choose_us',array(
    'title' => __('Why Choose Us','cleaning-service-pro'),
    'description' => __('Add Why Choose Us Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_enable',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
    ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_why_choose_us_enable',
    array(
      'label' => esc_html__( 'Show or Hide Why Choose Us Section', 'cleaning-service-pro' ),
      'section' => 'cleaning_service_pro_why_choose_us'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_why_choose_us_enable', array(
    'selector' => '#why_choose_us .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_why_choose_us_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_why_choose_us_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_why_choose_us_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimention 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us'
  )));

  $wp_customize->add_setting('cleaning_service_pro_choose_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_choose_main_heading',array(
    'label' => __('Section Main Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'setting' => 'cleaning_service_pro_choose_main_heading',
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_choose_main_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_choose_main_text',array(
    'label' => __('Section Main Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'setting' => 'cleaning_service_pro_choose_main_text',
    'type'    => 'text'
  )); 
  $wp_customize->add_setting('cleaning_service_pro_choose_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_choose_heading',array(
    'label' => __('Why Choose Us Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'setting' => 'cleaning_service_pro_choose_heading',
    'type'    => 'text'
  )); 
  $wp_customize->add_setting('cleaning_service_pro_choose_title',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_choose_title',array(
    'label' => __('Why Choose Us Title','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'setting' => 'cleaning_service_pro_choose_title',
    'type'    => 'text'
  )); 
  $wp_customize->add_setting('cleaning_service_pro_choose_text1',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_choose_text1',array(
    'label' => __('Why Choose Us Text-1','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'setting' => 'cleaning_service_pro_choose_text1',
    'type'    => 'text'
  )); 
  $wp_customize->add_setting('cleaning_service_pro_choose_text2',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_choose_text2',array(
    'label' => __('Why Choose Us Text-2','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'setting' => 'cleaning_service_pro_choose_text2',
    'type'    => 'text'
  )); 
  $wp_customize->add_setting('cleaning_service_pro_choose_increase',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_choose_increase',array(
    'label' => __('No Of Choose To Show','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'setting' => 'cleaning_service_pro_choose_increase',
    'type'    => 'number'
  )); 

  $choose = get_theme_mod('cleaning_service_pro_choose_increase');

  for($i=1; $i<=$choose; $i++) {

    $wp_customize->add_setting('cleaning_service_pro_choose_image'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_choose_image'.$i,
          array(
            'label' => __('Choose Image ','cleaning-service-pro').$i,
            'section' => 'cleaning_service_pro_why_choose_us',
            'settings' => 'cleaning_service_pro_choose_image'.$i
    )));

    $wp_customize->add_setting('cleaning_service_pro_choose_title'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_choose_title'.$i,array(
      'label' => __('Choose Title ','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_why_choose_us',
      'setting' => 'cleaning_service_pro_choose_title'.$i,
      'type'  => 'text'
    ));
  }
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_video_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_video_settings',
    array(
    'label' => __('Why Choose Us Video Section','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us'
  )));

  $wp_customize->add_setting('cleaning_service_pro_choose_video_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_choose_video_heading',array(
    'label' => __('Why Choose Us Video Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'setting' => 'cleaning_service_pro_choose_video_heading',
    'type'    => 'text'
  )); 

  for($i=1 ; $i <=3 ; $i++) { 
    if($i==1) { 
      $wp_customize->add_setting('cleaning_service_pro_video_image'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
      ));
      $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_video_image'.$i,
          array(
            'label' => __('Video Image','cleaning-service-pro').$i,
            'section' => 'cleaning_service_pro_why_choose_us',
            'settings' => 'cleaning_service_pro_video_image'.$i
      )));
      $wp_customize->add_setting('cleaning_service_pro_choose_video_icon'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
      ));
      $wp_customize->add_control('cleaning_service_pro_choose_video_icon'.$i,array(
        'label' => __('Video Icon ','cleaning-service-pro').$i,
        'section' => 'cleaning_service_pro_why_choose_us',
        'setting' => 'cleaning_service_pro_choose_video_icon'.$i,
        'type'  => 'text'
      ));
      $wp_customize->add_setting('cleaning_service_pro_choose_video_url'.$i,array(
        'default' => '',
        'sanitize_callback' => 'sanitize_textarea_field',
      ));
      $wp_customize->add_control('cleaning_service_pro_choose_video_url'.$i,array(
        'label' => __('Video Url ','cleaning-service-pro').$i,
        'section' => 'cleaning_service_pro_why_choose_us',
        'setting' => 'cleaning_service_pro_choose_video_url'.$i,
        'type'  => 'text'
      ));
    }else{
      $wp_customize->add_setting('cleaning_service_pro_video_image'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
      ));
      $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_video_image'.$i,
          array(
            'label' => __('Video Image','cleaning-service-pro').$i,
            'section' => 'cleaning_service_pro_why_choose_us',
            'settings' => 'cleaning_service_pro_video_image'.$i
      )));
    }
  }
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_counter_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_counter_settings',
    array(
    'label' => __('Counter Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us'
  )));
  $wp_customize->add_setting('cleaning_service_pro_counter_increase',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_counter_increase',array(
    'label' => __('No Of Counter To Show','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'setting' => 'cleaning_service_pro_counter_increase',
    'type'    => 'number'
  )); 

  $counter = get_theme_mod('cleaning_service_pro_counter_increase');

  for($i=1; $i<=$counter; $i++) {

    $wp_customize->add_setting('cleaning_service_pro_counter_image'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_counter_image'.$i,
          array(
            'label' => __('Choose Image ','cleaning-service-pro').$i,
            'section' => 'cleaning_service_pro_why_choose_us',
            'settings' => 'cleaning_service_pro_counter_image'.$i
    )));

    $wp_customize->add_setting('cleaning_service_pro_counter_number'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_counter_number'.$i,array(
      'label' => __('Choose Title ','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_why_choose_us',
      'setting' => 'cleaning_service_pro_counter_number'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_counter_number_text'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_counter_number_text'.$i,array(
      'label' => __('Choose Title ','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_why_choose_us',
      'setting' => 'cleaning_service_pro_counter_number_text'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_counter_text'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_counter_text'.$i,array(
      'label' => __('Choose Title ','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_why_choose_us',
      'setting' => 'cleaning_service_pro_counter_text'.$i,
      'type'  => 'text'
    ));
  }

  // Color Setting

  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_color_settings',
    array(
    'label' => __('Section Color Settings ','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_main_heading_color', array(
    'label' => __('Section Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_main_heading_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_why_choose_us_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_why_choose_us_main_heading_font_family', array(
      'section'  => 'cleaning_service_pro_why_choose_us',
      'label'    => __( 'Section Heading Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_main_heading_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_main_heading_bgcolor', array(
    'label' => __('Section Heading Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_main_heading_bgcolor',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_main_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_main_text_color', array(
    'label' => __('Section Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_main_text_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_why_choose_us_main_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_why_choose_us_main_text_font_family', array(
    'section'  => 'cleaning_service_pro_why_choose_us',
    'label'    => __( 'Section Text Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_heading_color', array(
    'label' => __('Why Choose Us Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_heading_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_why_choose_us_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_why_choose_us_heading_font_family', array(
    'section'  => 'cleaning_service_pro_why_choose_us',
    'label'    => __( 'Why Choose Us Heading Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_heading_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_heading_bgcolor', array(
    'label' => __('Why Choose Us Heading Background', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_heading_bgcolor',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_title_color', array(
    'label' => __('Why Choose Us Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_title_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_why_choose_us_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_why_choose_us_title_font_family', array(
    'section'  => 'cleaning_service_pro_why_choose_us',
    'label'    => __( 'Why Choose Us Title Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_text_color', array(
    'label' => __('Why Choose Us Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_text_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_why_choose_us_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_why_choose_us_text_font_family', array(
    'section'  => 'cleaning_service_pro_why_choose_us',
    'label'    => __( 'Why Choose Us Text Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_img_box_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_img_box_bgcolor', array(
    'label' => __('Why Choose Us Image Box Background', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_img_box_bgcolor',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_img_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_img_text_color', array(
    'label' => __('Why Choose Us Image Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_img_text_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_why_choose_us_img_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_why_choose_us_img_text_font_family', array(
    'section'  => 'cleaning_service_pro_why_choose_us',
    'label'    => __( 'Why Choose Us Image Text Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_video_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_video_heading_color', array(
    'label' => __('Video Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_video_heading_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_why_choose_us_video_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_why_choose_us_video_heading_font_family', array(
    'section'  => 'cleaning_service_pro_why_choose_us',
    'label'    => __( 'Video Heading Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_video_heading_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_video_heading_bgcolor', array(
    'label' => __('Video Heading Background', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_video_heading_bgcolor',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_video_icon_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_video_icon_color', array(
    'label' => __('Video Icon Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_video_icon_color',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_video_icon_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_video_icon_bgcolor', array(
    'label' => __('Video Icon Background', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_video_icon_bgcolor',
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_counter_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_counter_title_color', array(
    'label' => __('Counter Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_counter_title_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_why_choose_us_counter_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_why_choose_us_counter_title_font_family', array(
    'section'  => 'cleaning_service_pro_why_choose_us',
    'label'    => __( 'Counter Title Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_why_choose_us_counter_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_why_choose_us_counter_text_color', array(
    'label' => __('Counter Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_why_choose_us',
    'settings' => 'cleaning_service_pro_why_choose_us_counter_text_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_why_choose_us_counter_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_why_choose_us_counter_text_font_family', array(
    'section'  => 'cleaning_service_pro_why_choose_us',
    'label'    => __( 'Counter Text Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

/* Pricing */

  $wp_customize->add_section('cleaning_service_pro_pricing',array(
    'title' => __('Pricing Plan','cleaning-service-pro'),
    'description' => __('Add Pricing Plan Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_pricing_enable',
   array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
   ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_pricing_enable',
      array(
        'label' => esc_html__( 'Show or Hide Pricing Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_pricing'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_pricing_enable', array(
    'selector' => '#Pricing .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_pricing_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_pricing_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_pricing_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_pricing_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_pricing_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'settings' => 'cleaning_service_pro_pricing_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_pricing_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_pricing_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'settings' => 'cleaning_service_pro_pricing_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_pricing_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_pricing_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing'
  )));
  $wp_customize->add_setting('cleaning_service_pro_pricing_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_pricing_main_heading',array(
    'label' => __('Section Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'setting' => 'cleaning_service_pro_pricing_main_heading',
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_pricing_main_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_pricing_main_text',array(
    'label' => __('Section Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'setting' => 'cleaning_service_pro_pricing_main_text',
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_pricing_increase',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_pricing_increase',array(
    'label' => __('No Of Pricing Plan To Show','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'setting' => 'cleaning_service_pro_pricing_increase',
    'type'    => 'number'
  ));
   
  $Pricing_count = get_theme_mod('cleaning_service_pro_pricing_increase');

  for($i=1; $i<=$Pricing_count; $i++) {

    $wp_customize->add_setting('cleaning_service_pro_pricing_title'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_pricing_title'.$i,array(
      'label' => __('Pricing Title','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_pricing',
      'setting' => 'cleaning_service_pro_pricing_title'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_pricing_icon'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_pricing_icon'.$i,array(
      'label' => __('Pricing Icon','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_pricing',
      'setting' => 'cleaning_service_pro_pricing_icon'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_pricing_value'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_pricing_value'.$i,array(
      'label' => __('Pricing Value','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_pricing',
      'setting' => 'cleaning_service_pro_pricing_value'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_pricing_list_increase'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_pricing_list_increase'.$i,array(
      'label' => __('Pricing List Count','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_pricing',
      'setting' => 'cleaning_service_pro_pricing_list_increase'.$i,
      'type'  => 'number'
    ));
    $list_count = get_theme_mod('cleaning_service_pro_pricing_list_increase'.$i);

    for($j=1; $j<=$list_count; $j++) {
      $wp_customize->add_setting('cleaning_service_pro_pricing_list'.$i.$j,array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
      ));
      $wp_customize->add_control('cleaning_service_pro_pricing_list'.$i.$j,array(
        'label' => __('Pricing List','cleaning-service-pro').$i.$j,
        'section' => 'cleaning_service_pro_pricing',
        'setting' => 'cleaning_service_pro_pricing_list'.$i.$j,
        'type'  => 'text'
      ));
    }
    $wp_customize->add_setting('cleaning_service_pro_pricing_btn'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_pricing_btn'.$i,array(
      'label' => __('Pricing Button','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_pricing',
      'setting' => 'cleaning_service_pro_pricing_btn'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_pricing_btn_url'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_pricing_btn_url'.$i,array(
      'label' => __('Pricing Button Url','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_pricing',
      'setting' => 'cleaning_service_pro_pricing_btn_url'.$i,
      'type'  => 'text'
    ));
  }

  $wp_customize->add_setting( 'cleaning_service_pro_pricing_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_pricing_color_settings',
      array(
      'label' => __('Pricing Section Color Settings ','cleaning-service-pro'),
      'section' => 'cleaning_service_pro_pricing'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_pricing_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_pricing_main_heading_color', array(
    'label' => __('Section Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'settings' => 'cleaning_service_pro_pricing_main_heading_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_pricing_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_pricing_main_heading_font_family', array(
      'section'  => 'cleaning_service_pro_pricing',
      'label'    => __( 'Section Heading Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_pricing_main_heading_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_pricing_main_heading_bgcolor', array(
    'label' => __('Section Heading Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'settings' => 'cleaning_service_pro_pricing_main_heading_bgcolor',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_pricing_main_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_pricing_main_text_color', array(
    'label' => __('Section Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'settings' => 'cleaning_service_pro_pricing_main_text_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_pricing_main_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_pricing_main_text_font_family', array(
      'section'  => 'cleaning_service_pro_pricing',
      'label'    => __( 'Section Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_pricing_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_pricing_title_color', array(
    'label' => __('Pricing Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'settings' => 'cleaning_service_pro_pricing_title_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_pricing_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_pricing_title_font_family', array(
      'section'  => 'cleaning_service_pro_pricing',
      'label'    => __( 'Pricing Title Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_pricing_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_pricing_text_color', array(
    'label' => __('Pricing Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'settings' => 'cleaning_service_pro_pricing_text_color',
  )));
 
  $wp_customize->add_setting('cleaning_service_pro_pricing_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_pricing_text_font_family', array(
      'section'  => 'cleaning_service_pro_pricing',
      'label'    => __( 'Pricing Designation Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_pricing_value_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_pricing_value_color', array(
    'label' => __('Pricing Value Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'settings' => 'cleaning_service_pro_pricing_value_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_pricing_value_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_pricing_value_font_family', array(
      'section'  => 'cleaning_service_pro_pricing',
      'label'    => __( 'Pricing Value Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_pricing_icon_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_pricing_icon_color', array(
    'label' => __('Pricing Icon Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'settings' => 'cleaning_service_pro_pricing_icon_color',
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_pricing_icon_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_pricing_icon_bgcolor', array(
    'label' => __('Pricing Icon Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'settings' => 'cleaning_service_pro_pricing_icon_bgcolor',
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_pricing_btn_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_pricing_btn_color', array(
    'label' => __('Pricing Button Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'settings' => 'cleaning_service_pro_pricing_btn_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_pricing_btn_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_pricing_btn_font_family', array(
      'section'  => 'cleaning_service_pro_pricing',
      'label'    => __( 'Pricing Button Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_pricing_btn_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_pricing_btn_bgcolor', array(
    'label' => __('Pricing Button Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_pricing',
    'settings' => 'cleaning_service_pro_pricing_btn_bgcolor',
  )));

/* Project */

  $wp_customize->add_section('cleaning_service_pro_project',array(
    'title' => __('Project','cleaning-service-pro'),
    'description' => __('Add Project Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_project_enable',
   array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
   ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_project_enable',
      array(
        'label' => esc_html__( 'Show or Hide Project Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_project'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_project_enable', array(
    'selector' => '#project .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_project_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_project_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_project_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_project'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_project_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_project_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_project',
    'settings' => 'cleaning_service_pro_project_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_project_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_project_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_project',
    'settings' => 'cleaning_service_pro_project_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_project_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_project_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_project'
  )));
  $wp_customize->add_setting('cleaning_service_pro_project_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_project_main_heading',array(
    'label' => __('Section Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_project',
    'setting' => 'cleaning_service_pro_project_main_heading',
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_project_main_para',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_project_main_para',array(
    'label' => __('Section Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_project',
    'setting' => 'cleaning_service_pro_project_main_para',
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_project_left_img',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_project_left_img',
        array(
          'label' => __('Project Left Image ','cleaning-service-pro').$i,
          'section' => 'cleaning_service_pro_project',
          'settings' => 'cleaning_service_pro_project_left_img'
  )));
  $wp_customize->add_setting('cleaning_service_pro_project_count',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_project_count',array(
    'label' => __('No Of Project To Show','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_project',
    'setting' => 'cleaning_service_pro_project_count',
    'type'    => 'number'
  ));
   
  $what_count = get_theme_mod('cleaning_service_pro_project_count');

  for($i=1; $i<=$what_count; $i++) {

    $wp_customize->add_setting('cleaning_service_pro_project_image'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_project_image'.$i,
          array(
            'label' => __('Project Background Image ','cleaning-service-pro').$i,
            'section' => 'cleaning_service_pro_project',
            'settings' => 'cleaning_service_pro_project_image'.$i
    )));
    $wp_customize->add_setting('cleaning_service_pro_project_title'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_project_title'.$i,array(
      'label' => __('Project Title','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_project',
      'setting' => 'cleaning_service_pro_project_title'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_project_text'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_project_text'.$i,array(
      'label' => __('Project Text','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_project',
      'setting' => 'cleaning_service_pro_project_text'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_project_btn'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_project_btn'.$i,array(
      'label' => __('Project Button','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_project',
      'setting' => 'cleaning_service_pro_project_btn'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_project_btn_url'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_project_btn_url'.$i,array(
      'label' => __('Project Button Url','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_project',
      'setting' => 'cleaning_service_pro_project_btn_url'.$i,
      'type'  => 'text'
    ));
  }

  $wp_customize->add_setting( 'cleaning_service_pro_project_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_project_color_settings',
      array(
      'label' => __('Project Section Color Settings ','cleaning-service-pro'),
      'section' => 'cleaning_service_pro_project'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_project_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_project_main_heading_color', array(
    'label' => __('Section Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_project',
    'settings' => 'cleaning_service_pro_project_main_heading_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_project_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_project_main_heading_font_family', array(
      'section'  => 'cleaning_service_pro_project',
      'label'    => __( 'Section Heading Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_project_main_heading_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_project_main_heading_bgcolor', array(
    'label' => __('Section Heading Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_project',
    'settings' => 'cleaning_service_pro_project_main_heading_bgcolor',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_project_main_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_project_main_text_color', array(
    'label' => __('Section Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_project',
    'settings' => 'cleaning_service_pro_project_main_text_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_project_main_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_project_main_text_font_family', array(
      'section'  => 'cleaning_service_pro_project',
      'label'    => __( 'Section Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_project_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_project_title_color', array(
    'label' => __('Project Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_project',
    'settings' => 'cleaning_service_pro_project_title_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_project_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_project_title_font_family', array(
      'section'  => 'cleaning_service_pro_project',
      'label'    => __( 'Project Title Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_project_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_project_text_color', array(
    'label' => __('Project Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_project',
    'settings' => 'cleaning_service_pro_project_text_color',
  )));
 
  $wp_customize->add_setting('cleaning_service_pro_project_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_project_text_font_family', array(
      'section'  => 'cleaning_service_pro_project',
      'label'    => __( 'Project Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_project_btn_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_project_btn_color', array(
    'label' => __('Project Button Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_project',
    'settings' => 'cleaning_service_pro_project_btn_color',
  )));
 
  $wp_customize->add_setting('cleaning_service_pro_project_btn_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_project_btn_font_family', array(
      'section'  => 'cleaning_service_pro_project',
      'label'    => __( 'Project Button Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_project_btn_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_project_btn_bgcolor', array(
    'label' => __('Project Button Background', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_project',
    'settings' => 'cleaning_service_pro_project_btn_bgcolor',
  )));

/* Testimonial */

  $wp_customize->add_section('cleaning_service_pro_testimonial',array(
    'title' => __('Testimonial','cleaning-service-pro'),
    'description' => __('Add Testimonial Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_testimonial_enable',
   array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
   ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_testimonial_enable',
      array(
        'label' => esc_html__( 'Show or Hide Testimonial Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_testimonial'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_testimonial_enable', array(
    'selector' => '#testimonial .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_testimonial_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_testimonial_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_testimonial_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_testimonial'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_testimonial_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_testimonial_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_testimonial',
    'settings' => 'cleaning_service_pro_testimonial_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_testimonial_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_testimonial_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimention 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_testimonial',
    'settings' => 'cleaning_service_pro_testimonial_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_testimonial_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_testimonial_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_testimonial'
  )));

  $wp_customize->add_setting('cleaning_service_pro_testimonial_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_testimonial_main_heading',array(
    'label' => __('Section Main Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_testimonial',
    'setting' => 'cleaning_service_pro_testimonial_main_heading',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cleaning_service_pro_testimonial_main_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_testimonial_main_text',array(
    'label' => __('Section Main Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_testimonial',
    'setting' => 'cleaning_service_pro_testimonial_main_text',
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_testimonial_left_image',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_testimonial_left_image',
        array(
          'label' => __('Testimonial Left Image','cleaning-service-pro'),
          'section' => 'cleaning_service_pro_testimonial',
          'settings' => 'cleaning_service_pro_testimonial_left_image'
  )));
  $wp_customize->add_setting('cleaning_service_pro_testimonial_count',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_testimonial_count',array(
    'label' => __('No Of Testimonial To Show','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_testimonial',
    'setting' => 'cleaning_service_pro_testimonial_count',
    'type'    => 'number'
  )); 
  $testimonial_count = get_theme_mod('cleaning_service_pro_testimonial_count');
  for($i=1; $i<=$testimonial_count; $i++) {

    $wp_customize->add_setting('cleaning_service_pro_testimonial_image'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_testimonial_image'.$i,
          array(
            'label' => __('Testimonial Image','cleaning-service-pro').$i,
            'section' => 'cleaning_service_pro_testimonial',
            'settings' => 'cleaning_service_pro_testimonial_image'.$i
    )));
    $wp_customize->add_setting('cleaning_service_pro_testimonial_name'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_testimonial_name'.$i,array(
      'label' => __('Testimonial Name ','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_testimonial',
      'setting' => 'cleaning_service_pro_testimonial_name'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_testimonial_star_count'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_testimonial_star_count'.$i,array(
      'label' => __('Testimonial Rating ','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_testimonial',
      'setting' => 'cleaning_service_pro_testimonial_star_count'.$i,
      'type'  => 'number'
    ));
    $wp_customize->add_setting('cleaning_service_pro_testimonial_text'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_testimonial_text'.$i,array(
      'label' => __('Testimonial Text ','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_testimonial',
      'setting' => 'cleaning_service_pro_testimonial_text'.$i,
      'type'  => 'text'
    ));
  }
  $wp_customize->add_setting( 'cleaning_service_pro_testimonial_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_testimonial_color_settings',
    array(
      'label' => __('Section Color Settings ','cleaning-service-pro'),
      'section' => 'cleaning_service_pro_testimonial'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_testimonial_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_testimonial_main_heading_color', array(
    'label' => __('Section Main Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_testimonial',
    'settings' => 'cleaning_service_pro_testimonial_main_heading_color',
  )));
 $wp_customize->add_setting('cleaning_service_pro_testimonial_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_testimonial_main_heading_font_family', array(
    'section'  => 'cleaning_service_pro_testimonial',
    'label'    => __( 'Section Main Heading Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_testimonial_main_heading_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_testimonial_main_heading_bgcolor', array(
    'label' => __('Section Heading Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_testimonial',
    'settings' => 'cleaning_service_pro_testimonial_main_heading_bgcolor',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_testimonial_main_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_testimonial_main_text_color', array(
    'label' => __('Section Main Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_testimonial',
    'settings' => 'cleaning_service_pro_testimonial_main_text_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_testimonial_main_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_testimonial_main_text_font_family', array(
    'section'  => 'cleaning_service_pro_testimonial',
    'label'    => __( 'Section Main Text Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_testimonial_name_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_testimonial_name_color', array(
    'label' => __('Testimonial Name Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_testimonial',
    'settings' => 'cleaning_service_pro_testimonial_name_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_testimonial_name_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_testimonial_name_font_family', array(
    'section'  => 'cleaning_service_pro_testimonial',
    'label'    => __( 'Testimonial Name Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_testimonial_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_testimonial_text_color', array(
    'label' => __('Testimonial Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_testimonial',
    'settings' => 'cleaning_service_pro_testimonial_text_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_testimonial_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_testimonial_text_font_family', array(
    'section'  => 'cleaning_service_pro_testimonial',
    'label'    => __( 'Testimonial Text Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_testimonial_icon_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_testimonial_icon_color', array(
    'label' => __('Testimonial Icon Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_testimonial',
    'settings' => 'cleaning_service_pro_testimonial_icon_color',
  )));

/* Appointment */

  $wp_customize->add_section('cleaning_service_pro_appointment',array(
    'title' => __('Appointment','cleaning-service-pro'),
    'description' => __('Add Appointment Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_appointment_enable',
   array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
   ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_appointment_enable',
      array(
        'label' => esc_html__( 'Show or Hide This Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_appointment'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_appointment_enable', array(
    'selector' => '#Appointment .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_appointment_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_appointment_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_appointment_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_appointment'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_appointment_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_appointment_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_appointment',
    'settings' => 'cleaning_service_pro_appointment_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_appointment_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_appointment_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimention 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_appointment',
    'settings' => 'cleaning_service_pro_appointment_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_appointment_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_appointment_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_appointment'
  )));

  $wp_customize->add_setting('cleaning_service_pro_appointment_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_appointment_main_heading',array(
    'label' => __('Section Main Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_appointment',
    'setting' => 'cleaning_service_pro_appointment_main_heading',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cleaning_service_pro_appointment_main_para',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_appointment_main_para',array(
    'label' => __('Section Main Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_appointment',
    'setting' => 'cleaning_service_pro_appointment_main_para',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cleaning_service_pro_appointment_title',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_appointment_title',array(
    'label' => __('Appointment Title','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_appointment',
    'setting' => 'cleaning_service_pro_appointment_title',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cleaning_service_pro_appointment_shortcode',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_appointment_shortcode',array(
    'label' => __('Appointment Shortcode','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_appointment',
    'setting' => 'cleaning_service_pro_appointment_shortcode',
    'type'    => 'text'
  ));

/* Newsletter */

  $wp_customize->add_section('cleaning_service_pro_newsletter',array(
    'title' => __('Newsletter','cleaning-service-pro'),
    'description' => __('Add Newsletter Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_newsletter_enable',
   array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
   ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_newsletter_enable',
      array(
        'label' => esc_html__( 'Show or Hide Newsletter Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_newsletter'
  )));

  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_newsletter_enable', array(
    'selector' => '#newsletter .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_newsletter_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_newsletter_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_newsletter_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_newsletter'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_newsletter_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_newsletter_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_newsletter',
    'settings' => 'cleaning_service_pro_newsletter_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_newsletter_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_newsletter_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimention 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_newsletter',
    'settings' => 'cleaning_service_pro_newsletter_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_newsletter_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_newsletter_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_newsletter'
  )));

  $wp_customize->add_setting('cleaning_service_pro_newsletter_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_newsletter_main_heading',array(
    'label' => __('Newsletter Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_newsletter',
    'setting' => 'cleaning_service_pro_newsletter_main_heading',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cleaning_service_pro_newsletter_main_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_newsletter_main_text',array(
    'label' => __('Newsletter Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_newsletter',
    'setting' => 'cleaning_service_pro_newsletter_main_text',
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_newsletter_shortcode',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_newsletter_shortcode',array(
    'label' => __('Newsletter Shortcode','cleaning-service-pro'),
    'description' => __('Add Contact Form Shortcode Here','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_newsletter',
    'setting' => 'cleaning_service_pro_newsletter_shortcode',
    'type'    => 'text'
  )); 
  
  $wp_customize->add_setting( 'cleaning_service_pro_newsletter_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_newsletter_color_settings',
      array(
      'label' => __('Section Color Settings ','cleaning-service-pro'),
      'section' => 'cleaning_service_pro_newsletter'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_newsletter_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_newsletter_main_heading_color', array(
    'label' => __('Section Main Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_newsletter',
    'settings' => 'cleaning_service_pro_newsletter_main_heading_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_newsletter_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_newsletter_main_heading_font_family', array(
      'section'  => 'cleaning_service_pro_newsletter',
      'label'    => __( 'Section Main Heading Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_newsletter_main_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_newsletter_main_text_color', array(
    'label' => __('Section Main Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_newsletter',
    'settings' => 'cleaning_service_pro_newsletter_main_text_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_newsletter_main_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_newsletter_main_text_font_family', array(
      'section'  => 'cleaning_service_pro_newsletter',
      'label'    => __( 'Section Main Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_newsletter_shortcode_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_newsletter_shortcode_bgcolor', array(
    'label' => __('Newsletter Email Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_newsletter',
    'settings' => 'cleaning_service_pro_newsletter_shortcode_bgcolor',
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_newsletter_button_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_newsletter_button_color', array(
    'label' => __('Newsletter Button Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_newsletter',
    'settings' => 'cleaning_service_pro_newsletter_button_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_newsletter_button_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_newsletter_button_font_family', array(
    'section'  => 'cleaning_service_pro_newsletter',
    'label'    => __( 'Newsletter Button Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_newsletter_button_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_newsletter_button_bgcolor', array(
    'label' => __('Newsletter Button Background', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_newsletter',
    'settings' => 'cleaning_service_pro_newsletter_button_bgcolor',
  )));

/* How We Work */

  $wp_customize->add_section('cleaning_service_pro_how_we_work',array(
    'title' => __('How We Work','cleaning-service-pro'),
    'description' => __('Add How We Work Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_how_we_work_enable',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
  ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_how_we_work_enable',
      array(
        'label' => esc_html__( 'Show or Hide How We Work Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_how_we_work'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_how_we_work_enable', array(
    'selector' => '#how_we_work .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_how_we_work_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_how_we_work_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_how_we_work_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_how_we_work_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_how_we_work_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'settings' => 'cleaning_service_pro_how_we_work_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_how_we_work_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_how_we_work_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'settings' => 'cleaning_service_pro_how_we_work_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_how_we_work_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_how_we_work_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work'
  )));

  $wp_customize->add_setting('cleaning_service_pro_how_we_work_main_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_how_we_work_main_text',array(
    'label' => __('Section Main Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'setting' => 'cleaning_service_pro_how_we_work_main_text',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cleaning_service_pro_how_we_work_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_how_we_work_main_heading',array(
    'label' => __('Section Main Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'setting' => 'cleaning_service_pro_how_we_work_main_heading',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cleaning_service_pro_how_we_work_title',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_how_we_work_title',array(
    'label' => __('How We Work Title','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'setting' => 'cleaning_service_pro_how_we_work_title',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cleaning_service_pro_how_we_work_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_how_we_work_text',array(
    'label' => __('How We Work Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'setting' => 'cleaning_service_pro_how_we_work_text',
    'type'    => 'text'
  )); 

  for($i=1; $i<=4; $i++) {

    $wp_customize->add_setting('cleaning_service_pro_how_we_work_list_icon'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_how_we_work_list_icon'.$i,array(
      'label' => __('How We Work List Icon','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_how_we_work',
      'setting' => 'cleaning_service_pro_how_we_work_list_icon'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_how_we_work_list_text'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_how_we_work_list_text'.$i,array(
      'label' => __('How We Work List Text','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_how_we_work',
      'setting' => 'cleaning_service_pro_how_we_work_list_text'.$i,
      'type'  => 'text'
    ));
  }
  $wp_customize->add_setting('cleaning_service_pro_how_we_work_btn',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_how_we_work_btn',array(
    'label' => __('How We Work Button','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'setting' => 'cleaning_service_pro_how_we_work_btn',
    'type'    => 'text'
  )); 
  $wp_customize->add_setting('cleaning_service_pro_how_we_work_btn_url',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_how_we_work_btn_url',array(
    'label' => __('How We Work Button Url','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'setting' => 'cleaning_service_pro_how_we_work_btn_url',
    'type'    => 'text'
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_how_we_work_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_how_we_work_color_settings',
    array(
    'label' => __('How We Work Section Color Settings ','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_how_we_work_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_how_we_work_main_heading_color', array(
    'label' => __('How We Work Main Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'settings' => 'cleaning_service_pro_how_we_work_main_heading_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_how_we_work_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_how_we_work_main_heading_font_family', array(
      'section'  => 'cleaning_service_pro_how_we_work',
      'label'    => __( 'How We Work Main Heading Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_how_we_work_main_heading_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_how_we_work_main_heading_bgcolor', array(
    'label' => __('Section Heading Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'settings' => 'cleaning_service_pro_how_we_work_main_heading_bgcolor',
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_how_we_work_main_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_how_we_work_main_text_color', array(
    'label' => __('How We Work Main Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'settings' => 'cleaning_service_pro_how_we_work_main_text_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_how_we_work_main_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_how_we_work_main_text_font_family', array(
      'section'  => 'cleaning_service_pro_how_we_work',
      'label'    => __( 'How We Work Main Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_how_we_work_main_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_how_we_work_main_title_color', array(
    'label' => __('How We Work Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'settings' => 'cleaning_service_pro_how_we_work_main_title_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_how_we_work_main_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_how_we_work_main_title_font_family', array(
      'section'  => 'cleaning_service_pro_how_we_work',
      'label'    => __( 'How We Work Title Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_how_we_work_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_how_we_work_text_color', array(
    'label' => __('How We Work Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'settings' => 'cleaning_service_pro_how_we_work_text_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_how_we_work_main_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_how_we_work_main_text_font_family', array(
      'section'  => 'cleaning_service_pro_how_we_work',
      'label'    => __( 'How We Work Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_how_we_work_list_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_how_we_work_list_color', array(
    'label' => __('How We Work List Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'settings' => 'cleaning_service_pro_how_we_work_list_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_how_we_work_list_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_how_we_work_list_font_family', array(
      'section'  => 'cleaning_service_pro_how_we_work',
      'label'    => __( 'How We Work List Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_how_we_work_btn_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_how_we_work_btn_color', array(
    'label' => __('How We Work Button Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'settings' => 'cleaning_service_pro_how_we_work_btn_color',
  )));
 
  $wp_customize->add_setting('cleaning_service_pro_how_we_work_btn_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_how_we_work_btn_font_family', array(
      'section'  => 'cleaning_service_pro_how_we_work',
      'label'    => __( 'How We Work Button Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_how_we_work_btn_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_how_we_work_btn_bgcolor', array(
    'label' => __('How We Work Button Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_how_we_work',
    'settings' => 'cleaning_service_pro_how_we_work_btn_bgcolor',
  )));

/* Partner */

  $wp_customize->add_section('cleaning_service_pro_partner',array(
    'title' => __('Partner','cleaning-service-pro'),
    'description' => __('Add Partner Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_partner_enable',
   array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
   ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_partner_enable',
      array(
        'label' => esc_html__( 'Show or Hide Partner Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_partner'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_partner_enable', array(
    'selector' => '#partner .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_partner_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_partner_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_partner_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_partner'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_partner_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_partner_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_partner',
    'settings' => 'cleaning_service_pro_partner_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_partner_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_partner_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_partner',
    'settings' => 'cleaning_service_pro_partner_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_partner_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_partner_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_partner'
  )));
  $wp_customize->add_setting('cleaning_service_pro_partner_number',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_partner_number',array(
    'label' => __('No Of Partner To Show','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_partner',
    'setting' => 'cleaning_service_pro_partner_number',
    'type'    => 'number'
  )); 
  $Partner_count = get_theme_mod('cleaning_service_pro_partner_number');
  
  for($i=1; $i<=$Partner_count; $i++) {

    $wp_customize->add_setting('cleaning_service_pro_partner_image'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_partner_image'.$i,
      array(
        'label' => __('Partner Image ','cleaning-service-pro').$i,
        'section' => 'cleaning_service_pro_partner',
        'settings' => 'cleaning_service_pro_partner_image'.$i
    )));
    $wp_customize->add_setting('cleaning_service_pro_partner_title'.$i,array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cleaning_service_pro_partner_title'.$i,array(
      'label' => __('Title','cleaning-service-pro'),
      'section' => 'cleaning_service_pro_partner',
      'setting' => 'cleaning_service_pro_partner_title'.$i,
      'type'    => 'text'
    )); 
    $wp_customize->add_setting('cleaning_service_pro_partner_text'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cleaning_service_pro_partner_text'.$i,array(
      'label' => __('Text','cleaning-service-pro'),
      'section' => 'cleaning_service_pro_partner',
      'setting' => 'cleaning_service_pro_partner_text'.$i,
      'type'    => 'text'
    ));
  }
  
  //Color Setting

  $wp_customize->add_setting( 'cleaning_service_pro_partner_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_partner_color_settings',
    array(
    'label' => __('Section Color Settings ','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_partner'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_partner_main_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_partner_main_title_color', array(
    'label' => __('How We Work Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_partner',
    'settings' => 'cleaning_service_pro_partner_main_title_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_partner_main_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_partner_main_title_font_family', array(
      'section'  => 'cleaning_service_pro_partner',
      'label'    => __( 'How We Work Title Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_partner_main_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_partner_main_text_color', array(
    'label' => __('How We Work Main Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_partner',
    'settings' => 'cleaning_service_pro_partner_main_text_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_partner_main_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_partner_main_text_font_family', array(
      'section'  => 'cleaning_service_pro_partner',
      'label'    => __( 'How We Work Main Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

/* Team */

  $wp_customize->add_section('cleaning_service_pro_team',array(
    'title' => __('Team','cleaning-service-pro'),
    'description' => __('Add Team Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_team_enable',
   array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
   ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_team_enable',
      array(
        'label' => esc_html__( 'Show or Hide Team Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_team'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_team_enable', array(
    'selector' => '#Team .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_team_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_team_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_team_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_team_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_team_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'settings' => 'cleaning_service_pro_team_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_team_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_team_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'settings' => 'cleaning_service_pro_team_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_team_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_team_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team'
  )));
  $wp_customize->add_setting('cleaning_service_pro_team_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_team_main_heading',array(
    'label' => __('Section Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'setting' => 'cleaning_service_pro_team_main_heading',
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_team_main_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_team_main_text',array(
    'label' => __('Section Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'setting' => 'cleaning_service_pro_team_main_text',
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_team_count',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_team_count',array(
    'label' => __('No Of Team To Show','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'setting' => 'cleaning_service_pro_team_count',
    'type'    => 'number'
  ));
   
  $team_count = get_theme_mod('cleaning_service_pro_team_count');

  for($i=1; $i<=$team_count; $i++) {

    $wp_customize->add_setting('cleaning_service_pro_team_image'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_team_image'.$i,
          array(
            'label' => __('Team Background Image ','cleaning-service-pro').$i,
            'section' => 'cleaning_service_pro_team',
            'settings' => 'cleaning_service_pro_team_image'.$i
    )));
    $wp_customize->add_setting('cleaning_service_pro_team_title'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_team_title'.$i,array(
      'label' => __('Team Title','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_team',
      'setting' => 'cleaning_service_pro_team_title'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_team_designation'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_team_designation'.$i,array(
      'label' => __('Team Designation','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_team',
      'setting' => 'cleaning_service_pro_team_designation'.$i,
      'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_team_star_count'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_team_star_count'.$i,array(
      'label' => __('Team Star','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_team',
      'setting' => 'cleaning_service_pro_team_star_count'.$i,
      'type'  => 'number'
    ));
    $wp_customize->add_setting('cleaning_service_pro_team_social_count'.$i,array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cleaning_service_pro_team_social_count'.$i,array(
      'label' => __('No Of Social Icon To Show','cleaning-service-pro'),
      'section' => 'cleaning_service_pro_team',
      'setting' => 'cleaning_service_pro_team_social_count'.$i,
      'type'    => 'number'
    ));
    $social_count = get_theme_mod('cleaning_service_pro_team_social_count'.$i);
    for($j=1 ; $j<=$social_count; $j++) { 
      $wp_customize->add_setting('cleaning_service_pro_team_social_icon'.$i.$j,array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
      ));
      $wp_customize->add_control('cleaning_service_pro_team_social_icon'.$i.$j,array(
        'label' => __('Team Social Icon','cleaning-service-pro').$i.$j,
        'section' => 'cleaning_service_pro_team',
        'setting' => 'cleaning_service_pro_team_social_icon'.$i.$j,
        'type'  => 'text'
      ));

      $wp_customize->add_setting('cleaning_service_pro_team_social_link'.$i.$j,array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
      ));
      $wp_customize->add_control('cleaning_service_pro_team_social_link'.$i.$j,array(
        'label' => __('Team Social Icon Link','cleaning-service-pro').$i.$j,
        'section' => 'cleaning_service_pro_team',
        'setting' => 'cleaning_service_pro_team_social_link'.$i.$j,
        'type'  => 'text'
      ));
    }
  }

  $wp_customize->add_setting( 'cleaning_service_pro_team_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_team_color_settings',
      array(
      'label' => __('Team Section Color Settings ','cleaning-service-pro'),
      'section' => 'cleaning_service_pro_team'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_team_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_team_main_heading_color', array(
    'label' => __('Section Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'settings' => 'cleaning_service_pro_team_main_heading_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_team_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_team_main_heading_font_family', array(
      'section'  => 'cleaning_service_pro_team',
      'label'    => __( 'Section Heading Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_team_main_heading_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_team_main_heading_bgcolor', array(
    'label' => __('Section Heading Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'settings' => 'cleaning_service_pro_team_main_heading_bgcolor',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_team_main_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_team_main_text_color', array(
    'label' => __('Section Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'settings' => 'cleaning_service_pro_team_main_text_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_team_main_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_team_main_text_font_family', array(
      'section'  => 'cleaning_service_pro_team',
      'label'    => __( 'Section Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_team_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_team_title_color', array(
    'label' => __('Team Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'settings' => 'cleaning_service_pro_team_title_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_team_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_team_title_font_family', array(
      'section'  => 'cleaning_service_pro_team',
      'label'    => __( 'Team Title Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_team_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_team_text_color', array(
    'label' => __('Team Designation Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'settings' => 'cleaning_service_pro_team_text_color',
  )));
 
  $wp_customize->add_setting('cleaning_service_pro_team_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_team_text_font_family', array(
      'section'  => 'cleaning_service_pro_team',
      'label'    => __( 'Team Designation Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_team_star_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_team_star_color', array(
    'label' => __('Team Star Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'settings' => 'cleaning_service_pro_team_star_color',
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_team_social_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_team_social_color', array(
    'label' => __('Team Social Icon Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'settings' => 'cleaning_service_pro_team_social_color',
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_team_social_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_team_social_bgcolor', array(
    'label' => __('Team Social Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'settings' => 'cleaning_service_pro_team_social_bgcolor',
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_team_box_hover_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_team_box_hover_color', array(
    'label' => __('Team Box Hover Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'settings' => 'cleaning_service_pro_team_box_hover_color',
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_team_box_hover_social_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_team_box_hover_social_bgcolor', array(
    'label' => __('Team Box Hover Icon Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_team',
    'settings' => 'cleaning_service_pro_team_box_hover_social_bgcolor',
  )));

/* Latest News */

  $wp_customize->add_section('cleaning_service_pro_latest_news',array(
    'title' => __('Latest News','cleaning-service-pro'),
    'description' => __('Add Latest News Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_latest_news_enable',
   array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
   ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_latest_news_enable',
      array(
        'label' => esc_html__( 'Show or Hide Latest News Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_latest_news'
  )));

  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_latest_news_enable', array(
    'selector' => '#latest_news .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_latest_news_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_latest_news_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_latest_news_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_latest_news'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_latest_news_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_latest_news_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_latest_news',
    'settings' => 'cleaning_service_pro_latest_news_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_latest_news_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_latest_news_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_latest_news',
    'settings' => 'cleaning_service_pro_latest_news_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_latest_news_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_latest_news_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_latest_news'
  )));

  $wp_customize->add_setting('cleaning_service_pro_latest_news_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_latest_news_main_heading',array(
    'label' => __('Section Main Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_latest_news',
    'setting' => 'cleaning_service_pro_latest_news_main_heading',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cleaning_service_pro_latest_news_main_para',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_latest_news_main_para',array(
    'label' => __('Section Main Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_latest_news',
    'setting' => 'cleaning_service_pro_latest_news_main_para',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cleaning_service_pro_latest_news_number',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_latest_news_number',array(
    'label' => __('No Of latest News To Show','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_latest_news',
    'setting' => 'cleaning_service_pro_latest_news_number',
    'type'    => 'number'
  ));
  $latest = get_theme_mod('cleaning_service_pro_latest_news_number');

  for($i=1; $i<=$latest; $i++) {

    $wp_customize->add_setting('cleaning_service_pro_latest_news_btn'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_latest_news_btn'.$i,array(
      'label' => __('Latest Button','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_latest_news',
      'setting' => 'cleaning_service_pro_latest_news_btn'.$i,
      'type'  => 'text'
    ));
  }
  // Color Setting

  $wp_customize->add_setting( 'cleaning_service_pro_latest_news_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_latest_news_color_settings',
      array(
      'label' => __('Section Color Settings ','cleaning-service-pro'),
      'section' => 'cleaning_service_pro_latest_news'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_latest_news_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_latest_news_main_heading_color', array(
    'label' => __('Section Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_latest_news',
    'settings' => 'cleaning_service_pro_latest_news_main_heading_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_latest_news_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_latest_news_main_heading_font_family', array(
      'section'  => 'cleaning_service_pro_latest_news',
      'label'    => __( 'Section Heading Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_latest_news_main_heading_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_latest_news_main_heading_bgcolor', array(
    'label' => __('Section Heading Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_latest_news',
    'settings' => 'cleaning_service_pro_latest_news_main_heading_bgcolor',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_latest_news_main_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_latest_news_main_text_color', array(
    'label' => __('Section Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_latest_news',
    'settings' => 'cleaning_service_pro_latest_news_main_text_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_latest_news_main_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_latest_news_main_text_font_family', array(
      'section'  => 'cleaning_service_pro_latest_news',
      'label'    => __( 'Section Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_latest_news_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_latest_news_title_color', array(
    'label' => __('Latest News Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_latest_news',
    'settings' => 'cleaning_service_pro_latest_news_title_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_latest_news_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_latest_news_title_font_family', array(
      'section'  => 'cleaning_service_pro_latest_news',
      'label'    => __( 'Latest News Title Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_latest_news_btn_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_latest_news_btn_color', array(
    'label' => __('Latest News Button Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_latest_news',
    'settings' => 'cleaning_service_pro_latest_news_btn_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_latest_news_btn_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_latest_news_btn_font_family', array(
      'section'  => 'cleaning_service_pro_latest_news',
      'label'    => __( 'Latest News Button Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_latest_news_btn_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_latest_news_btn_bgcolor', array(
    'label' => __('Latest News Button Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_latest_news',
    'settings' => 'cleaning_service_pro_latest_news_btn_bgcolor',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_latest_news_date_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_latest_news_date_color', array(
    'label' => __('Latest News Date Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_latest_news',
    'settings' => 'cleaning_service_pro_latest_news_date_color',
  )));
 
  $wp_customize->add_setting('cleaning_service_pro_latest_news_date_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_latest_news_date_font_family', array(
      'section'  => 'cleaning_service_pro_latest_news',
      'label'    => __( 'Latest News Date Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

/* Banner */

  $wp_customize->add_section('cleaning_service_pro_add',array(
    'title' => __('Banner','cleaning-service-pro'),
    'description' => __('Add Banner Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_add_enable',
   array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
   ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_add_enable',
      array(
        'label' => esc_html__( 'Show or Hide Banner Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_add'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_add_enable', array(
    'selector' => '#contact .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_add_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_add_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_add_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_add'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_add_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_add_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_add',
    'settings' => 'cleaning_service_pro_add_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_add_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_add_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_add',
    'settings' => 'cleaning_service_pro_add_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_add_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_add_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_add'
  )));

  $wp_customize->add_setting('cleaning_service_pro_add_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cleaning_service_pro_add_main_heading',array(
    'label' => __('Section Main Title','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_add',
    'setting' => 'cleaning_service_pro_add_main_heading',
    'type'  => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_add_main_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cleaning_service_pro_add_main_text',array(
    'label' => __('Section Main Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_add',
    'setting' => 'cleaning_service_pro_add_main_text',
    'type'  => 'text'
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_add_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_add_color_settings',
      array(
      'label' => __('Section Color Settings ','cleaning-service-pro'),
      'section' => 'cleaning_service_pro_add'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_add_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_add_title_color', array(
    'label' => __('Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_add',
    'settings' => 'cleaning_service_pro_add_title_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_add_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_add_title_font_family', array(
      'section'  => 'cleaning_service_pro_add',
      'label'    => __( 'Title Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_add_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_add_text_color', array(
    'label' => __('Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_add',
    'settings' => 'cleaning_service_pro_add_text_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_add_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_add_text_font_family', array(
    'section'  => 'cleaning_service_pro_add',
    'label'    => __( 'Text Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

/* Faq */

  $wp_customize->add_section('cleaning_service_pro_faq',array(
    'title' => __('Faq','cleaning-service-pro'),
    'description' => __('Add Faq Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_faq_enable',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
  ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_faq_enable',
      array(
        'label' => esc_html__( 'Show or Hide Faq Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_faq'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_faq_enable', array(
    'selector' => '#Faq .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_faq_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_faq_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_faq_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_faq'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_faq_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_faq_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_faq',
    'settings' => 'cleaning_service_pro_faq_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_faq_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_faq_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_faq',
    'settings' => 'cleaning_service_pro_faq_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_faq_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_faq_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_faq'
  )));

  $wp_customize->add_setting('cleaning_service_pro_faq_left_image',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_faq_left_image',
        array(
          'label' => __('Faq Left Image ','cleaning-service-pro'),
          'section' => 'cleaning_service_pro_faq',
          'settings' => 'cleaning_service_pro_faq_left_image'
  )));

  $wp_customize->add_setting('cleaning_service_pro_faq_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_faq_main_heading',array(
    'label' => __('Section Main Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_faq',
    'setting' => 'cleaning_service_pro_faq_main_heading',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cleaning_service_pro_faq_count',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_faq_count',array(
    'label' => __('No Of Faq To Show','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_faq',
    'setting' => 'cleaning_service_pro_faq_count',
    'type'    => 'text'
  )); 

  $faq_count = get_theme_mod('cleaning_service_pro_faq_count');

  for($i=1 ; $i<=$faq_count; $i++) {
    $wp_customize->add_setting('cleaning_service_pro_faq_title'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cleaning_service_pro_faq_title'.$i,array(
      'label' => __('Faq Title','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_faq',
      'setting' => 'cleaning_service_pro_faq_title'.$i,
      'type'    => 'text'
    )); 

    $wp_customize->add_setting('cleaning_service_pro_faq_text'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cleaning_service_pro_faq_text'.$i,array(
      'label' => __('Faq Text','cleaning-service-pro').$i,
      'section' => 'cleaning_service_pro_faq',
      'setting' => 'cleaning_service_pro_faq_text'.$i,
      'type'    => 'text'
    )); 
  }

  $wp_customize->add_setting( 'cleaning_service_pro_faq_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_faq_color_settings',
    array(
    'label' => __('Faq Section Color Settings ','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_faq'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_faq_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_faq_main_heading_color', array(
    'label' => __('Section Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_faq',
    'settings' => 'cleaning_service_pro_faq_main_heading_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_faq_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_faq_main_heading_font_family', array(
      'section'  => 'cleaning_service_pro_faq',
      'label'    => __( 'Section Heading Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_faq_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_faq_title_color', array(
    'label' => __('Faq Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_faq',
    'settings' => 'cleaning_service_pro_faq_title_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_faq_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_faq_title_font_family', array(
      'section'  => 'cleaning_service_pro_faq',
      'label'    => __( 'Faq Title Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_faq_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_faq_text_color', array(
    'label' => __('Faq Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_faq',
    'settings' => 'cleaning_service_pro_faq_text_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_faq_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_faq_text_font_family', array(
      'section'  => 'cleaning_service_pro_faq',
      'label'    => __( 'Faq Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_faq_title_hover_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_faq_title_hover_color', array(
    'label' => __('Faq Title Hover Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_faq',
    'settings' => 'cleaning_service_pro_faq_title_hover_color',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_faq_icon_hover_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_faq_icon_hover_bgcolor', array(
    'label' => __('Faq Hover Icon Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_faq',
    'settings' => 'cleaning_service_pro_faq_icon_hover_bgcolor',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_faq_hover_line_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_faq_hover_line_color', array(
    'label' => __('Faq Hover Bottom Line Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_faq',
    'settings' => 'cleaning_service_pro_faq_hover_line_color',
  )));

/* Product */

  $wp_customize->add_section('cleaning_service_pro_product',array(
    'title' => __('Product','cleaning-service-pro'),
    'description' => __('Add Product Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_product_enable',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
  ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_product_enable',
      array(
        'label' => esc_html__( 'Show or Hide Product Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_product'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_product_enable', array(
    'selector' => '#Product .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_product_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_product_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_product_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_product_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_product_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'settings' => 'cleaning_service_pro_product_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_product_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_product_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'settings' => 'cleaning_service_pro_product_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_product_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_product_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product'
  )));

  $wp_customize->add_setting('cleaning_service_pro_product_left_image',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_product_left_image',
        array(
          'label' => __('Product Left Image ','cleaning-service-pro'),
          'section' => 'cleaning_service_pro_product',
          'settings' => 'cleaning_service_pro_product_left_image'
  )));

  $wp_customize->add_setting('cleaning_service_pro_product_main_title',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_product_main_title',array(
    'label' => __('Section Main Title','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'setting' => 'cleaning_service_pro_product_main_title',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cleaning_service_pro_product_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_product_main_heading',array(
    'label' => __('Section Main Heading','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'setting' => 'cleaning_service_pro_product_main_heading',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cleaning_service_pro_product_main_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_product_main_text',array(
    'label' => __('Section Main Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'setting' => 'cleaning_service_pro_product_main_text',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cleaning_service_pro_product_title1',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_product_title1',array(
    'label' => __('Product Title-1','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'setting' => 'cleaning_service_pro_product_title1',
    'type'    => 'text'
  )); 
  $wp_customize->add_setting('cleaning_service_pro_product_text1',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_product_text1',array(
    'label' => __('Product Text-1','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'setting' => 'cleaning_service_pro_product_text1',
    'type'    => 'text'
  )); 
  $wp_customize->add_setting('cleaning_service_pro_product_title2',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_product_title2',array(
    'label' => __('Product Title-2','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'setting' => 'cleaning_service_pro_product_title2',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cleaning_service_pro_product_text2',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cleaning_service_pro_product_text2',array(
    'label' => __('Product Text-2 ','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'setting' => 'cleaning_service_pro_product_text2',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting( 'cleaning_service_pro_product_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_product_color_settings',
    array(
    'label' => __('Product Section Color Settings ','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_product_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_product_main_heading_color', array(
    'label' => __('Section Heading Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'settings' => 'cleaning_service_pro_product_main_heading_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_product_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_product_main_heading_font_family', array(
      'section'  => 'cleaning_service_pro_product',
      'label'    => __( 'Section Heading Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_product_main_heading_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_product_main_heading_bgcolor', array(
    'label' => __('Section Heading Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'settings' => 'cleaning_service_pro_product_main_heading_bgcolor',
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_product_main_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_product_main_title_color', array(
    'label' => __('Section Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'settings' => 'cleaning_service_pro_product_main_title_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_product_main_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_product_main_title_font_family', array(
      'section'  => 'cleaning_service_pro_product',
      'label'    => __( 'Section Title Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_product_main_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_product_main_text_color', array(
    'label' => __('Section Main Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'settings' => 'cleaning_service_pro_product_main_text_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_product_main_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_product_main_text_font_family', array(
      'section'  => 'cleaning_service_pro_product',
      'label'    => __( 'Section Main Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_product_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_product_title_color', array(
    'label' => __('Product Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'settings' => 'cleaning_service_pro_product_title_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_product_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_product_title_font_family', array(
      'section'  => 'cleaning_service_pro_product',
      'label'    => __( 'Product Title Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_product_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_product_text_color', array(
    'label' => __('Product Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_product',
    'settings' => 'cleaning_service_pro_product_text_color',
  )));
  $wp_customize->add_setting('cleaning_service_pro_product_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_product_text_font_family', array(
      'section'  => 'cleaning_service_pro_product',
      'label'    => __( 'Product Text Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

/* Home Contact */

  $wp_customize->add_section('cleaning_service_pro_contact',array(
    'title' => __('Home Contact','cleaning-service-pro'),
    'description' => __('Add Home Contact Content Here','cleaning-service-pro'),
    'panel' => 'cleaning_service_pro_panel_id',
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_contact_enable',
   array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
   ));
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_contact_enable',
      array(
        'label' => esc_html__( 'Show or Hide Home Contact Section', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_contact'
  )));
  $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_contact_enable', array(
    'selector' => '#contact .container',
    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_contact_enable',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_contact_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_contact_settings',
    array(
    'label' => __('Section Background Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact'
  )));
  $wp_customize->add_setting( 'cleaning_service_pro_contact_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_contact_bgcolor', array(
    'label' => __('Section Background Color', 'cleaning-service-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact',
    'settings' => 'cleaning_service_pro_contact_bgcolor',
  )));
  
  $wp_customize->add_setting('cleaning_service_pro_contact_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_contact_bgimage',array(
    'label' => __('Section Background Image','cleaning-service-pro'),
    'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact',
    'settings' => 'cleaning_service_pro_contact_bgimage'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_contact_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_contact_content_settings',
    array(
    'label' => __('Section Content Settings','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact'
  )));

  $wp_customize->add_setting('cleaning_service_pro_section_contact_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cleaning_service_pro_section_contact_main_heading',array(
    'label' => __('Location Title','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact',
    'setting' => 'cleaning_service_pro_section_contact_main_heading',
    'type'  => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_section_contact_location',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cleaning_service_pro_section_contact_location',array(
    'label' => __('Location Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact',
    'setting' => 'cleaning_service_pro_section_contact_location',
    'type'  => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_section_contact_phone',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cleaning_service_pro_section_contact_phone',array(
    'label' => __('Phone Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact',
    'setting' => 'cleaning_service_pro_section_contact_phone',
    'type'  => 'text'
  ));

  $wp_customize->add_setting('cleaning_service_pro_section_contact_weak',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cleaning_service_pro_section_contact_weak',array(
    'label' => __('Weekend Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact',
    'setting' => 'cleaning_service_pro_section_contact_weak',
    'type'  => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_section_contact_time',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_textarea_field',
  ));
  $wp_customize->add_control('cleaning_service_pro_section_contact_time',array(
    'label' => __('Time Text','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact',
    'setting' => 'cleaning_service_pro_section_contact_time',
    'type'  => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_section_contact_address_latitude',array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
  $wp_customize->add_control('cleaning_service_pro_section_contact_address_latitude',array(
    'label' => __('Location Latitude','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact',
    'setting' => 'cleaning_service_pro_section_contact_address_latitude',
    'type'  => 'text'
  ));
  $wp_customize->add_setting('cleaning_service_pro_section_contact_address_longitude',array(
      'default' => '',
      'sanitize_callback' => 'sanitize_textarea_field',
    ));
  $wp_customize->add_control('cleaning_service_pro_section_contact_address_longitude',array(
    'label' => __('Location Longitute','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact',
    'setting' => 'cleaning_service_pro_section_contact_address_longitude',
    'type'  => 'text'
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_contact_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_contact_color_settings',
      array(
      'label' => __('Section Color Settings ','cleaning-service-pro'),
      'section' => 'cleaning_service_pro_contact'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_contact_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_contact_title_color', array(
    'label' => __('Title Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact',
    'settings' => 'cleaning_service_pro_contact_title_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_contact_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
      'cleaning_service_pro_contact_title_font_family', array(
      'section'  => 'cleaning_service_pro_contact',
      'label'    => __( 'Title Fonts','cleaning-service-pro'),
      'type'     => 'select',
      'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_contact_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_contact_text_color', array(
    'label' => __('Text Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact',
    'settings' => 'cleaning_service_pro_contact_text_color',
  )));

  $wp_customize->add_setting('cleaning_service_pro_contact_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
  ));
  $wp_customize->add_control(
    'cleaning_service_pro_contact_text_font_family', array(
    'section'  => 'cleaning_service_pro_contact',
    'label'    => __( 'Text Fonts','cleaning-service-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_contact_icon_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_contact_icon_color', array(
    'label' => __('Icon Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact',
    'settings' => 'cleaning_service_pro_contact_icon_color',
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_contact_box_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_contact_box_bgcolor', array(
    'label' => __('Box Background Color', 'cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact',
    'settings' => 'cleaning_service_pro_contact_box_bgcolor',
  )));

// Post General Settings //

  $wp_customize->add_section('cleaning_service_pro_post_general_settings',array(
    'title' => __('Post Settings','cleaning-service-pro'),
    'description'   => __('Change Your Setting','cleaning-service-pro'),
    'priority'  => null,
    'panel' => 'cleaning_service_pro_panel_id',
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_post_general_settings_post_date',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
   ));
 
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control( $wp_customize, 'cleaning_service_pro_post_general_settings_post_date',
     array(
        'label' => esc_html__( 'Show or Hide Post Date', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_post_general_settings'
  )));

  $wp_customize->add_setting( 'cleaning_service_pro_post_general_settings_post_comments',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
  ));
 
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control( $wp_customize, 'cleaning_service_pro_post_general_settings_post_comments',
      array(
        'label' => esc_html__( 'Show or Hide Comments', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_post_general_settings'
      )
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_post_general_settings_post_author',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
    )
  );
 
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control( $wp_customize, 'cleaning_service_pro_post_general_settings_post_author',
    array(
        'label' => esc_html__( 'Show or Hide Author', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_post_general_settings'
    )
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_post_general_settings_post_share',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
    )
  );
 
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control( $wp_customize, 'cleaning_service_pro_post_general_settings_post_share',
    array(
        'label' => esc_html__( 'Show or Hide Share Icons', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_post_general_settings'
    )
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_post_general_settings_post_share_facebook',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
    )
  );
 
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control( $wp_customize, 'cleaning_service_pro_post_general_settings_post_share_facebook',
    array(
        'label' => esc_html__( 'Post Share Facebook', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_post_general_settings'
    )
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_post_general_settings_post_share_linkedin',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
    )
  );
 
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control( $wp_customize, 'cleaning_service_pro_post_general_settings_post_share_linkedin',
    array(
      'label' => esc_html__( 'Post Share Linkedin', 'cleaning-service-pro' ),
      'section' => 'cleaning_service_pro_post_general_settings'
    )
  ));  

  $wp_customize->add_setting( 'cleaning_service_pro_post_general_settings_post_share_googleplus',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
    )
  );
 
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control( $wp_customize, 'cleaning_service_pro_post_general_settings_post_share_googleplus',
    array(
      'label' => esc_html__( 'Post Share Google Plus', 'cleaning-service-pro' ),
      'section' => 'cleaning_service_pro_post_general_settings'
    )
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_post_general_settings_post_share_twitter',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
    )
  );
 
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control( $wp_customize, 'cleaning_service_pro_post_general_settings_post_share_twitter',
    array(
      'label' => esc_html__( 'Post Share Twitter', 'cleaning-service-pro' ),
      'section' => 'cleaning_service_pro_post_general_settings'
    )
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_post_general_settings_post_category',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
    )
  );
 
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control( $wp_customize, 'cleaning_service_pro_post_general_settings_post_category',
    array(
      'label' => esc_html__( 'Show or Hide Category', 'cleaning-service-pro' ),
      'section' => 'cleaning_service_pro_post_general_settings'
    )
  ));

  $wp_customize->add_setting( 'cleaning_service_pro_post_general_settings_post_sidebar',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
    )
  );
 
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control( $wp_customize, 'cleaning_service_pro_post_general_settings_post_sidebar',
    array(
        'label' => esc_html__( 'Show or Hide Sidebar', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_post_general_settings'
    )
  ));
  $wp_customize->add_setting( 'cleaning_service_pro_theme_loader',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
  ));
 
  $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control( $wp_customize, 'cleaning_service_pro_theme_loader',
    array(
      'label' => esc_html__( 'Show or Hide Loader', 'cleaning-service-pro' ),
      'section' => 'cleaning_service_pro_post_general_settings'
  )));