<?php
//about theme info
add_action( 'admin_menu', 'cleaning_service_pro_gettingstarted' );
function cleaning_service_pro_gettingstarted() {    	
	add_theme_page( esc_html__('Get Started', 'cleaning-service-pro'), esc_html__('Get Started', 'cleaning-service-pro'), 'edit_theme_options', 'cleaning_service_pro_guide', 'cleaning_service_pro_mostrar_guide');   
}

function cleaning_service_pro_notice(){
    global $pagenow;
    if ( is_admin() && ('themes.php' == $pagenow) && isset( $_GET['activated'] ) ) {?>
    <div class="notice notice-success is-dismissible getting_started">
		<div class="notice-content">
			<h2><?php _e( 'Thanks for installing Cleaning Service Pro, you rock!', 'cleaning-service-pro' ) ?> </h2>
			<p><?php _e( 'Cleaning Service Pro now supports colors, typography custom links for custom post types. Take benefit of a variety of features, functionalities, elements, and an exclusive set of customization options to build your own professional website', 'cleaning-service-pro' ) ?></p>
			<p><?php _e( "Please Click on the link below to know the theme setup information", 'cleaning-service-pro' ) ?></p>
			<p><a href="<?php echo esc_url( admin_url( 'themes.php?page=cleaning_service_pro_guide' ) ); ?>" class="button button-primary"><?php _e( 'Getting Started With Cleaning Service Pro', 'cleaning-service-pro' ); ?></a></p>
		</div>
	</div>
	<?php }
}
add_action('admin_notices', 'cleaning_service_pro_notice');


// Add a Custom CSS file to WP Admin Area
function cleaning_service_pro_admin_theme_style() {
   wp_enqueue_style('custom-admin-style', get_template_directory_uri() . '/inc/getstarted/getstart.css');
   wp_enqueue_script('tabs', get_template_directory_uri() . '/inc/getstarted/js/tab.js');
}
add_action('admin_enqueue_scripts', 'cleaning_service_pro_admin_theme_style');

//guidline for about theme
function cleaning_service_pro_mostrar_guide() { 
	//custom function about theme customizer
	$return = add_query_arg( array()) ;
	$theme = wp_get_theme( 'cleaning-service-pro' );
?>

	<div class="wrapper-info">
		<h2><?php esc_html_e( 'Welcome to Cleaning Service Pro', 'cleaning-service-pro' ); ?> <span class="version"><?php esc_html_e( 'Version', 'cleaning-service-pro' ); ?>: <?php echo esc_html($theme['Version']);?></span></h2>
		<p><?php esc_html_e('Before demo importer first install given plugins, Contact Form 7 and Woocommerce plugin then click on demo importer button to import all the demo contents.','cleaning-service-pro'); ?></p>
		<?php require get_parent_theme_file_path( '/inc/getstarted/demo-importer.php' ); ?>
	</div>

<?php } ?>