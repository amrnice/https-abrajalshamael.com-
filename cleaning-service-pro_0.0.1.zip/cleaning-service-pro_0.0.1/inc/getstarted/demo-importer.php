<div class="theme-offer">
	<?php
		//POST and update the customizer and other related data of Cleaning Service Pro
      if(isset($_POST['submit'])){
        $home_id=''; $blog_id=''; $page_id=''; $contact_id='';

        // Create a front page and assigned the template
        
        $home_content = '';

        $home_title = 'Home';
    		$home_check = get_page_by_title($home_title);
   	   	$home = array(
      		   'post_type' => 'page',
      		   'post_title' => $home_title,
             'post_content'  => $home_content,
      		   'post_status' => 'publish',
      		   'post_author' => 1,
      		   'post_slug' => 'home'
   		   );
        $home_id = wp_insert_post($home);
         
         //Set the home page template
         add_post_meta( $home_id, '_wp_page_template', 'page-template/home-page.php' );

         //Set the static front page
         $home = get_page_by_title( 'Home' );
         update_option( 'page_on_front', $home->ID );
         update_option( 'show_on_front', 'page' );

        
          // Create a blog page and assigned the template
          $blog_title = 'Blog';
          $blog_check = get_page_by_title($blog_title);
          $blog = array(
             'post_type' => 'page',
             'post_title' => $blog_title,
             'post_status' => 'publish',
             'post_author' => 1,
             'post_slug' => 'blog'
          );
          $blog_id = wp_insert_post($blog);
         

        //Set the blog page template
         add_post_meta( $blog_id, '_wp_page_template', 'page-template/blog-fullwidth-extend.php' );

        
        // Create a Page 
          $page_title = 'Page ';
          $content = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est. laborum.ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.';

          $page_check = get_page_by_title($page_title);
          $page = array(
          'post_type' => 'page',
          'post_title' => $page_title,
          'post_content'  => $content,
          'post_status' => 'publish',
          'post_author' => 1,
          'post_slug' => 'page'
          );
          $page_id = wp_insert_post($page);
         
          // Create a contact page and assigned the template
          $contact_title = 'Contact';
          $contact_check = get_page_by_title($contact_title);
          $contact = array(
          'post_type' => 'page',
          'post_title' => $contact_title,
          'post_status' => 'publish',
          'post_author' => 1,
          'post_slug' => 'contact'
          );
 		     $contact_id = wp_insert_post($contact);
         

         //Set the blog with right sidebar template
         add_post_meta( $contact_id, '_wp_page_template', 'page-template/contact.php' );

    // Drag and Drop 

        set_theme_mod( 'cleaning_service_pro_section_ordering_settings_repeater', 'service,about,what_we_do,why_choose_us,pricing_plan,project,testimonial,appointment,newsletter,how_we_work,partner,team,latest-news,add,faq,product,contact');

    // Topbar 

        set_theme_mod( 'cleaning_service_pro_topbar_text', 'We are Industial Cleaners' );
        set_theme_mod( 'cleaning_service_pro_topbar_email_text', 'info@example.com' );
        set_theme_mod( 'cleaning_service_pro_topbar_email_icon', 'far fa-envelope-open' );
        set_theme_mod( 'cleaning_service_pro_topbar_email_title', 'Email' );
        set_theme_mod( 'cleaning_service_pro_topbar_career_btn', 'Careers' );
        set_theme_mod( 'cleaning_service_pro_topbar_career_btn_url', '#' );
        set_theme_mod( 'cleaning_service_pro_topbar_services_btn','Services' );
        set_theme_mod( 'cleaning_service_pro_topbar_services_btn_url', '#' );
        set_theme_mod( 'cleaning_service_pro_topbar_contact_btn','Contact Us' );
        set_theme_mod( 'cleaning_service_pro_topbar_contact_btn_url', '#' );

    // Topbar 1

        set_theme_mod( 'cleaning_service_pro_topbar1_location_text', 'US - LOS ANGELES' );
        set_theme_mod( 'cleaning_service_pro_topbar1_location_icon', 'fas fa-map-marker-alt' );
        set_theme_mod( 'cleaning_service_pro_topbar1_location_title', 'Location' );
        set_theme_mod( 'cleaning_service_pro_topbar1_phone_text', '00222123333019' );
        set_theme_mod( 'cleaning_service_pro_topbar1_phone_title', 'Call Us' );
        set_theme_mod( 'cleaning_service_pro_topbar1_phone_icon', 'fas fa-phone' );

    // Slider 

      //Number of slides to show section
      set_theme_mod( 'cleaning_service_pro_slide_number', '3' );

      //Slider Images section
      for($i=1; $i<=3; $i++) {
        set_theme_mod( 'cleaning_service_pro_slide_image'.$i, get_template_directory_uri().'/assets/images/slides/slide.png' );
        
        set_theme_mod( 'cleaning_service_pro_slide_main_heading'.$i, 'WELCOME TO OUR SITE' );
        set_theme_mod( 'cleaning_service_pro_slide_heading'.$i, 'WE CLEAN YOUR PLACE YOU REST');
        set_theme_mod( 'cleaning_service_pro_slide_text'.$i, 'Our long history and regular clients prove that our service is qualified.');
        set_theme_mod( 'cleaning_service_pro_slide_btn'.$i, 'Book Online' );
        set_theme_mod( 'cleaning_service_pro_slide_btn_url'.$i, '#' );
        set_theme_mod( 'cleaning_service_pro_slide_btn1'.$i, 'More Info' );
        set_theme_mod( 'cleaning_service_pro_slide_btn_url1'.$i, '#' );
        set_theme_mod( 'cleaning_service_pro_slide_days'.$i, 'Sunday - Friday' );
        set_theme_mod( 'cleaning_service_pro_slide_time'.$i, '9:00 am - 9:00 pm');
        set_theme_mod( 'cleaning_service_pro_slide_icon'.$i, 'fas fa-clock');

        set_theme_mod( 'cleaning_service_pro_slide_discount_head'.$i, 'Discount');
        set_theme_mod( 'cleaning_service_pro_slide_discount_number'.$i, '25%off');
        set_theme_mod( 'cleaning_service_pro_slide_discount_text'.$i, 'In First Cleaning Service for you');
      }
        
    // Services 
      
      set_theme_mod( 'cleaning_service_pro_service_main_heading', 'Special Offers' );
      set_theme_mod( 'cleaning_service_pro_service_main_para', 'Lorem ipsum dolor sit amet, consectetur  adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' );

      set_theme_mod( 'cleaning_service_pro_service_count', '3' );

      $service_title = array('Kitchen Cleaning','Vaccum Cleaning','Window Cleaning');

      for($i=1; $i<=3; $i++) {
        set_theme_mod( 'cleaning_service_pro_service_image'.$i, get_template_directory_uri().'/assets/images/service/icon'.$i.'.png' );
        set_theme_mod( 'cleaning_service_pro_service_title'.$i, $service_title[$i-1]);
        set_theme_mod( 'cleaning_service_pro_service_text'.$i, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua' );
        set_theme_mod( 'cleaning_service_pro_service_btn'.$i, 'Book Now' );
        set_theme_mod( 'cleaning_service_pro_service_btn_url'.$i, '#' );
      }

      // ---------------- About ----------------

        set_theme_mod( 'cleaning_service_pro_about_left_image', get_template_directory_uri().'/assets/images/about/about_left.png' );
        set_theme_mod( 'cleaning_service_pro_about_left_number', '25' );
        set_theme_mod( 'cleaning_service_pro_about_left_text', 'years of experience' );

        set_theme_mod( 'cleaning_service_pro_about_title', 'ABOUT US' );
        set_theme_mod( 'cleaning_service_pro_about_main_heading', 'More Then 25 Years Eperience' );
        set_theme_mod( 'cleaning_service_pro_about_text', 'As quas equidem noluisse et, ex pro semper fierent oporteat. Te epic urei ullamcorper usu, eos et voluptaria rationibus. Usu cu eligendi ad ipisci, sedex altera dictas incorrupte. Idque option ius ut, id molestiae philosophia his. Qui euismod fabellas refor midans ea, inermis ration ibus necessitatibus eu eum' );

        $list_title = array('Affordable Prices','100% Customer Satisfaction','Free Transport','Best Quality');
       
        for($i=1; $i<=4; $i++) {
          set_theme_mod( 'cleaning_service_pro_about_list_icon'.$i, 'fas fa-check-square');
          set_theme_mod( 'cleaning_service_pro_about_list_text'.$i, $list_title[$i-1] );
        }

        set_theme_mod( 'cleaning_service_pro_about_phone_title', 'Toll Free Number' );
        set_theme_mod( 'cleaning_service_pro_about_phone_icon', 'fas fa-phone' );
        set_theme_mod( 'cleaning_service_pro_about_phone_number', '+1884-253-451' );

      // ---------------- Add --------------

      set_theme_mod( 'cleaning_service_pro_add_bgimage', get_template_directory_uri().'/assets/images/add_banner.png' );
      set_theme_mod( 'cleaning_service_pro_add_main_heading', 'Need High Professional Commercial or Residential' );
      set_theme_mod( 'cleaning_service_pro_add_main_text', 'We’re here to bring you the cleaning services you need.' );

    // How We Work 

      set_theme_mod( 'cleaning_service_pro_how_we_work_bgimage', get_template_directory_uri().'/assets/images/how_bg.png' );
      set_theme_mod( 'cleaning_service_pro_how_we_work_main_text', 'HOW WE WORK' );
      set_theme_mod( 'cleaning_service_pro_how_we_work_main_heading', 'We Assure You will be Satisfied with Service ' );
      set_theme_mod( 'cleaning_service_pro_how_we_work_title', 'We make Your House as Good as New' );
      set_theme_mod( 'cleaning_service_pro_how_we_work_btn', 'Get Service Now' );
      set_theme_mod( 'cleaning_service_pro_how_we_work_btn_url', '#' );
      set_theme_mod( 'cleaning_service_pro_how_we_work_text', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore.Senim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea ' );

        $list = array('Experienced Team','Book, manage & pay online','Keep the same cleaner for every visit','One-off, weekly or fortnightly visits');
       
        for($i=1; $i<=4; $i++) {
          set_theme_mod( 'cleaning_service_pro_how_we_work_list_icon'.$i, 'fas fa-check-square');
          set_theme_mod( 'cleaning_service_pro_how_we_work_list_text'.$i, $list[$i-1] );
        }

    // Project 

      set_theme_mod( 'cleaning_service_pro_project_main_para', 'OUR PROJECTS' );
      set_theme_mod( 'cleaning_service_pro_project_main_heading', 'Our Recent Projects' );
      set_theme_mod( 'cleaning_service_pro_project_left_img', get_template_directory_uri().'/assets/images/project/project_left.png' );
      set_theme_mod( 'cleaning_service_pro_project_count', '6' );

      for($i=1; $i<=6; $i++) {
        set_theme_mod( 'cleaning_service_pro_project_image'.$i, get_template_directory_uri().'/assets/images/project/project'.$i.'.jpg' );
        set_theme_mod( 'cleaning_service_pro_project_title'.$i, 'Building Cleaning');
        set_theme_mod( 'cleaning_service_pro_project_text'.$i, 'Residential and Office' );
        set_theme_mod( 'cleaning_service_pro_project_btn'.$i, 'View Project' );
        set_theme_mod( 'cleaning_service_pro_project_btn_url'.$i, '#' );
      }

    // Testimonial 

      set_theme_mod( 'cleaning_service_pro_testimonial_bgimage', get_template_directory_uri().'/assets/images/testimonials/testimonial_bg.png' );
      set_theme_mod( 'cleaning_service_pro_testimonial_left_image', get_template_directory_uri().'/assets/images/testimonials/testimonial_left.png' );
      set_theme_mod( 'cleaning_service_pro_testimonial_main_heading', 'What People Say About Us' );
      set_theme_mod( 'cleaning_service_pro_testimonial_main_text', 'OUR TESTIMONIALS' );
      set_theme_mod( 'cleaning_service_pro_testimonial_count', '3' );
      
      for($i=1;$i<=3;$i++) {

        set_theme_mod( 'cleaning_service_pro_testimonial_image'.$i, get_template_directory_uri().'/assets/images/testimonials/testimonial'.$i.'.png');
        set_theme_mod( 'cleaning_service_pro_testimonial_name'.$i,'Junita Mushenko' );
        set_theme_mod( 'cleaning_service_pro_testimonial_star_count'.$i,'4' );
        set_theme_mod( 'cleaning_service_pro_testimonial_text'.$i, 'Lorem ipsum dolor sit amet, consectetur adipi sicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna ');        
      }

    // Appointment 

      set_theme_mod( 'cleaning_service_pro_appointment_bgimage', get_template_directory_uri().'/assets/images/appointment_bg.png' );
      set_theme_mod( 'cleaning_service_pro_appointment_main_heading', 'Order Even Faster' );
      set_theme_mod( 'cleaning_service_pro_appointment_title', 'Make An Appointment' );
      set_theme_mod( 'cleaning_service_pro_appointment_main_para', 'Now we are available online also. Download our App  KrystalKlean and check many more offers and pakages. Take advantage of our Premium services.we are just one tap far from you, Enjoy our  online services' );

    // Latest News 

      set_theme_mod( 'cleaning_service_pro_latest_news_main_heading', 'Our Latest Posts' );
      set_theme_mod( 'cleaning_service_pro_latest_news_main_para', 'OUR BLOG' );
      set_theme_mod( 'cleaning_service_pro_latest_news_number', '4' );

      for($i=1;$i<=4;$i++) {

        set_theme_mod( 'cleaning_service_pro_latest_news_btn'.$i, 'Read More' );

        $title = 'Benefits of Cleaning Your Home Regularly';
        $content = 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s..';

        // Create post object
        $my_post = array(
         'post_title'    => wp_strip_all_tags( $title ),
         'post_content'  => $content,
         'post_status'   => 'publish',
         'post_type'     => 'post',   
        );

         // Insert the post into the database
        $post_id = wp_insert_post( $my_post );

        $image_url = get_template_directory_uri().'/assets/images/news/Newsimg'.$i.'.png';

        $image_name= 'latest-news'.$i.'.png';
        $upload_dir       = wp_upload_dir(); 
        // Set upload folder
        $image_data       = file_get_contents($image_url); 
        // Get image data
        $unique_file_name = wp_unique_filename( $upload_dir['path'], $image_name ); 
        // Generate unique name
        $filename= basename( $unique_file_name ); 
        // Create image file name
        // Check folder permission and define file location
        if( wp_mkdir_p( $upload_dir['path'] ) ) {
           $file = $upload_dir['path'] . '/' . $filename;
        } else {
           $file = $upload_dir['basedir'] . '/' . $filename;
        }
        // Create the image  file on the server
        file_put_contents( $file, $image_data );
        // Check image file type
        $wp_filetype = wp_check_filetype( $filename, null );
        // Set attachment data
        $attachment = array(
         'post_mime_type' => $wp_filetype['type'],
         'post_title'     => sanitize_file_name( $filename ),
         'post_content'   => '',
         'post_type'     => 'post',
         'post_status'    => 'inherit'
        );

        // Create the attachment
        $attach_id = wp_insert_attachment( $attachment, $file, $post_id );
        // Include image.php
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        // Define attachment metadata
        $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
        // Assign metadata to attachment
         wp_update_attachment_metadata( $attach_id, $attach_data );
        // And finally assign featured image to post
        set_post_thumbnail( $post_id, $attach_id );
      }

    // Team 

      set_theme_mod( 'cleaning_service_pro_team_bgcolor', '#efefef' );
      set_theme_mod( 'cleaning_service_pro_team_main_text', 'OUR TEAM' );
      set_theme_mod( 'cleaning_service_pro_team_main_heading', 'Our Expert Team' );
      set_theme_mod( 'cleaning_service_pro_team_count', '3' );

      $team_title = ['Alice Harry','Jannie Edson','Ben Josaph'];
      for($i=1; $i<=3; $i++) {
          set_theme_mod( 'cleaning_service_pro_team_image'.$i, get_template_directory_uri().'/assets/images/team/team'.$i.'.png' );
          set_theme_mod( 'cleaning_service_pro_team_title'.$i, $team_title[$i-1]);
          set_theme_mod( 'cleaning_service_pro_team_designation'.$i, 'Worker' );
          set_theme_mod( 'cleaning_service_pro_team_star_count'.$i,'4' );
          set_theme_mod( 'cleaning_service_pro_team_social_count'.$i,'3' );
          $icon = ['fab fa-twitter','fab fa-instagram','fab fa-facebook-f'];
          for($k=1; $k<=3; $k++) { 
            set_theme_mod( 'cleaning_service_pro_team_social_link'.$i.$k,'#' );
            set_theme_mod( 'cleaning_service_pro_team_social_icon'.$i.$k, $icon[$k-1] );
          }
        }

    // Why choose us 

      set_theme_mod( 'cleaning_service_pro_choose_main_text', 'WHY CHOOSE US' );
      set_theme_mod( 'cleaning_service_pro_choose_main_heading', 'Trusted Cleaning Services');
      set_theme_mod( 'cleaning_service_pro_choose_heading', 'Why Choose Us');
      set_theme_mod( 'cleaning_service_pro_choose_title', 'We are Offering all the Cleaning Services our Customers');
      set_theme_mod( 'cleaning_service_pro_choose_text1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo. Donec ullamcorper nulla non metus auctor fringilla. Maecenas sed diam eget risus varius blandit sit amet non magna.'); 
      set_theme_mod( 'cleaning_service_pro_choose_text2', 'luctus nec ullamcorper mattis, pulvinar dapibus leo. Donec ullamcorper nulla non metus auctor fringilla. Maecenas sed diam eget risus varius blandit sit amet non magna.');

      set_theme_mod( 'cleaning_service_pro_choose_increase', '3');

      $choose = array('High Quality Service','Cleaner & Greener','Happiness Guarantee');
      for($i=1; $i<=3; $i++) {
        set_theme_mod( 'cleaning_service_pro_choose_image'.$i, get_template_directory_uri().'/assets/images/choose/choose'.$i.'.png' );
        set_theme_mod( 'cleaning_service_pro_choose_title'.$i, $choose[$i-1] );
      }

      //Choose video 
      set_theme_mod( 'cleaning_service_pro_choose_video_heading', 'Watch How we Clean');
      set_theme_mod( 'cleaning_service_pro_choose_video_icon1', 'fas fa-play');
      set_theme_mod( 'cleaning_service_pro_choose_video_url1', 'https://www.youtube.com/embed/XysRGYNtpgI');
      for($i=1; $i<=3; $i++) {
        set_theme_mod( 'cleaning_service_pro_video_image'.$i, get_template_directory_uri().'/assets/images/video/video'.$i.'.png' );
      }

      //Choose Counter 
      set_theme_mod( 'cleaning_service_pro_counter_increase', '4' ); 

      $count_no = array('2000','28','300','2100');
      $count_text = array('Projects Done','Awards Winner','Team Workers','Happy Clients');
      for($i=1; $i<=4; $i++) {
        set_theme_mod( 'cleaning_service_pro_counter_image'.$i, get_template_directory_uri().'/assets/images/counter/image'.$i.'.png' );
        set_theme_mod( 'cleaning_service_pro_counter_number'.$i, $count_no[$i-1] );
        set_theme_mod( 'cleaning_service_pro_counter_number_text'.$i, '+' );
        set_theme_mod( 'cleaning_service_pro_counter_text'.$i, $count_text[$i-1] );
      }
      
    // Pricing Plan 

      set_theme_mod( 'cleaning_service_pro_pricing_bgcolor', '#ededee' );
      set_theme_mod( 'cleaning_service_pro_pricing_main_text', 'OUR PRICES');
      set_theme_mod( 'cleaning_service_pro_pricing_main_heading', 'Our Affordable Price Plans');
      set_theme_mod( 'cleaning_service_pro_pricing_increase', '3');

      $pricing_title = array('Comercial Plan','Premium Plan','Residential Plan');

      for($i=1; $i<=3; $i++) {
        set_theme_mod( 'cleaning_service_pro_pricing_title'.$i, $pricing_title[$i-1]);
        set_theme_mod( 'cleaning_service_pro_pricing_list_increase'.$i, '6');
        $pricing_list = array('3 Bedrooms cleaning','Vacuuming','2 Bathroom cleaning','Mirror Cleaning','1 Livingroom cleaning','Window Sills');
        for($k=1; $k<=6; $k++) {
          set_theme_mod( 'cleaning_service_pro_pricing_list'.$k, $pricing_list[$k-1] );
        }
        set_theme_mod( 'cleaning_service_pro_pricing_value'.$i, '$15.99'); 
        set_theme_mod( 'cleaning_service_pro_pricing_btn'.$i, 'Book Online'); 
        set_theme_mod( 'cleaning_service_pro_pricing_btn_url'.$i, '#'); 
        set_theme_mod( 'cleaning_service_pro_pricing_icon'.$i, 'fas fa-home'); 
      }   

    // What we do

      set_theme_mod( 'cleaning_service_pro_what_we_do_bgcolor', '#efeff0');
      set_theme_mod( 'cleaning_service_pro_what_we_do_main_text', 'OUR SERVICES');
      set_theme_mod( 'cleaning_service_pro_what_we_do_main_heading', 'What We Do');
      set_theme_mod( 'cleaning_service_pro_what_we_do_count', '4' );

      $what_title = array('Apartment Cleaning','Sanitizing','Office Cleaning','Washroom Cleaning');

      for($i=1; $i<=4; $i++) {
        set_theme_mod( 'cleaning_service_pro_what_we_do_bgimage'.$i, get_template_directory_uri().'/assets/images/what-we-do/image'.$i.'.png' );
        set_theme_mod( 'cleaning_service_pro_what_we_do_image'.$i, get_template_directory_uri().'/assets/images/what-we-do/icon'.$i.'.png' );
        set_theme_mod( 'cleaning_service_pro_what_we_do_title'.$i, $what_title[$i-1]);
        set_theme_mod( 'cleaning_service_pro_what_we_do_text'.$i, 'When you starting a company you are thinking on how to cut expenses. One of such options to cut the startup' );
        set_theme_mod( 'cleaning_service_pro_what_we_do_btn'.$i, 'Book Now' );
        set_theme_mod( 'cleaning_service_pro_what_we_do_btn_url'.$i, '#' );
      }

    // Product 

      set_theme_mod( 'cleaning_service_pro_product_bgcolor', '#efefef' );
      set_theme_mod( 'cleaning_service_pro_product_left_image', get_template_directory_uri().'/assets/images/product_left.png' );
      set_theme_mod( 'cleaning_service_pro_product_main_title', 'OUR PRODUCTS' );
      set_theme_mod( 'cleaning_service_pro_product_main_heading', 'Cleaning Products We Use' );
      set_theme_mod( 'cleaning_service_pro_product_main_text', 'We feel good about cleaning with our self-formulated natural products that are better for the environment' );

      set_theme_mod( 'cleaning_service_pro_product_title1', '100% Safe & Organic' );
      set_theme_mod( 'cleaning_service_pro_product_title2', 'We Care about your Safety' );
      set_theme_mod( 'cleaning_service_pro_product_text1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' );
      set_theme_mod( 'cleaning_service_pro_product_text2', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' );

    // Faq 

      set_theme_mod( 'cleaning_service_pro_faq_left_image', get_template_directory_uri().'/assets/images/faq_left.png' );
      set_theme_mod( 'cleaning_service_pro_faq_main_heading', 'You Have Questions in Your Mind, Look Here Now Now ' );
      set_theme_mod( 'cleaning_service_pro_faq_count', '4' );
      $faq_title = ['What should I expect on my first appointment?','What all is included in your service?','Do you furnish the cleaning supplies?','How long should a office cleaning take?'];
      for($i=1; $i<=4; $i++) {
        set_theme_mod( 'cleaning_service_pro_faq_title'.$i, $faq_title[$i-1] );
        set_theme_mod( 'cleaning_service_pro_faq_text'.$i, 'We will arrive at your home we will be equipped with all the leaning supplies and equipment needed to thoroughly clean your home.' );
      }

    // Partner 

      set_theme_mod( 'cleaning_service_pro_partner_number', '5' );
      $partner_title = ['Easy Online Form','Get Confirmation','Enjoy Cleanliness'];
      for($i=1; $i<=3; $i++) {
        set_theme_mod( 'cleaning_service_pro_partner_image'.$i, get_template_directory_uri().'/assets/images/partner/partner'.$i.'.png' );
        set_theme_mod( 'cleaning_service_pro_partner_title'.$i, $partner_title[$i-1] );
        set_theme_mod( 'cleaning_service_pro_partner_text'.$i, 'Fill the form in just few clicks and you can book the Service' );
      }

    // Newsletter 
      
      set_theme_mod( 'cleaning_service_pro_newsletter_bgimage', get_template_directory_uri().'/assets/images/newsletter_bg.png' );
      set_theme_mod( 'cleaning_service_pro_newsletter_main_text', 'Get Daily Updates' );
      set_theme_mod( 'cleaning_service_pro_newsletter_main_heading', 'Subscribe Our Newsletter' );

    // Home Contact 

      set_theme_mod( 'cleaning_service_pro_section_contact_main_heading', 'Our Location In Map' );
      set_theme_mod( 'cleaning_service_pro_section_contact_location', '59 Street, B4 Appartment, Australia' );
      set_theme_mod( 'cleaning_service_pro_section_contact_phone', '+985-8844-000 / +97151-234-5678' );
      set_theme_mod( 'cleaning_service_pro_section_contact_weak', 'Sunday - Friday' );
      set_theme_mod( 'cleaning_service_pro_section_contact_time', '9:00 am - 9:00 pm' );
      
      //Longitude
      set_theme_mod( 'cleaning_service_pro_section_contact_address_longitude', '-80.053361' ); 
      
      //Latitude
      set_theme_mod( 'cleaning_service_pro_section_contact_address_latitude', '26.704241' ); 

       /*customizer-part-social-icons.php*/
          //twitter link
          set_theme_mod( 'cleaning_service_pro_headertwitter', 'https://twitter.com/' ); 
          //facebook link 
          set_theme_mod( 'cleaning_service_pro_headerfacebook', 'https://www.facebook.com/' ); 
          //GooglePlus link
          set_theme_mod( 'cleaning_service_pro_headeryoutube', 'https://www.youtube.com/' );
          //Pinterest link
          set_theme_mod( 'cleaning_service_pro_headerpinterest', 'https://in.pinterest.com/' );

    //Contact Page
      set_theme_mod( 'cleaning_service_pro_contactpage_form_title', 'Contact Us' ); 
      //Longitude
      set_theme_mod( 'cleaning_service_pro_address_longitude', '-80.053361' ); 
      //Latitude
      set_theme_mod( 'cleaning_service_pro_address_latitude', '26.704241' ); 
      //Email Title text
      set_theme_mod( 'cleaning_service_pro_contactpage_email_title', 'Email ' ); 
      //Email ID
      set_theme_mod( 'cleaning_service_pro_contactpage_email_one', 'support@dummy.com' ); 
      set_theme_mod( 'cleaning_service_pro_contactpage_email_two', 'support@dummy.com' ); 
      //Address Title text
      set_theme_mod( 'cleaning_service_pro_address_title', 'Address' ); 
      //Address
      set_theme_mod( 'cleaning_service_pro_address', '123 6th eight avenue FL 32904 , 455 Martinson, Los Angeles' ); 
      //Phone Title text
      set_theme_mod( 'cleaning_service_pro_contactpage_phone_title', 'Phone' ); 
      //Phone No.
      set_theme_mod( 'cleaning_service_pro_contactpage_phone_one', '+1 881 235 6284' );
      set_theme_mod( 'cleaning_service_pro_contactpage_phone_two', '+1 881 235 6284' );
         
      //Footer Copyright Text
        set_theme_mod( 'cleaning_service_pro_footer_copy', 'Wordpress Theme 2020' ); 
        set_theme_mod( 'cleaning_service_pro_footer_widget_bgimage', get_template_directory_uri().'/assets/images/footer_bg.png' );        
  }
    ?>
    <ul>
		<li>
			<hr>
			<span class="dashicons dashicons-format-aside"></span><?php _e('Click on the below content to get demo content installed.','cleaning-service-pro'); ?>
			<br><small><b><?php _e('Please take backup if your website is already live with data.This importer will fill the Cleaning Service Pro new customizer values.','cleaning-service-pro'); ?></b></small>
			<br><br>
      <form action="<?php echo esc_url(home_url()); ?>/wp-admin/themes.php?page=cleaning_service_pro_guide" method="POST" onsubmit="return validate(this);">
          <input type="submit" name="submit" value="<?php esc_html_e('Run Importer','cleaning-service-pro'); ?>" class="button button-primary button-large">
      </form>
      <div class="success">
        <?php 
          if (isset($_POST['submit'])) {
            echo esc_html('Demo Import Successful','cleaning-service-pro');
          }
        ?>
      </div>
			<script type="text/javascript">
				function validate(valid) {
    				 if(confirm("Do you really want to do this?")){
					    document.forms[0].submit();
					}
			    else {
				    return false;
			    }
				}
			</script>
			<hr>
		</li>
	</ul>
</div>