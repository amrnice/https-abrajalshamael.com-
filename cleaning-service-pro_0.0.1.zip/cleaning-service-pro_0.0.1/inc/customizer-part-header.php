<?php

	// ------------- Topbar ----------------

		$wp_customize->add_section('cleaning_service_pro_topbar_section',array(
			'title'	=> __('Topbar','cleaning-service-pro'),
			'description'	=> __('Topbar Settings','cleaning-service-pro'),
			'priority'	=> null,
			'panel' => 'cleaning_service_pro_panel_id',
		));
		$wp_customize->add_setting( 'cleaning_service_pro_topbar_enable',
			array(
			  'default' => 1,
			  'transport' => 'refresh',
			  'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
			));
		$wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_topbar_enable',
		  array(
		    'label' => esc_html__( 'Show or Hide Topbar', 'cleaning-service-pro' ),
		    'section' => 'cleaning_service_pro_topbar_section'
		)));
	    $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_topbar_enable', array(
		    'selector' => '#topbar .container',
		    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_topbar_enable',
		) );
		$wp_customize->add_setting( 'cleaning_service_pro_topbar_settings',
	    array(
		    'default' => '',
		    'transport' => 'postMessage',
		    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
	  	));
		$wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_topbar_settings',
		    array(
		    'label' => __('Section Background Settings','cleaning-service-pro'),
		    'section' => 'cleaning_service_pro_topbar_section'
		)));
		$wp_customize->add_setting( 'cleaning_service_pro_topbar_section_bgcolor', array(
		    'default' => '',
		    'sanitize_callback' => 'sanitize_hex_color'
		));
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_topbar_section_bgcolor', array(
			'label' => __('Section Background Color', 'cleaning-service-pro'),
			'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
			'section' => 'cleaning_service_pro_topbar_section',
			'settings' => 'cleaning_service_pro_topbar_section_bgcolor',
		)));

		$wp_customize->add_setting('cleaning_service_pro_topbar_section_bgimage',array(
			'default' => '',
			'sanitize_callback' => 'esc_url_raw',
		));
		$wp_customize->add_control(
		new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_topbar_section_bgimage',array(
			'label' => __('Section Background Image','cleaning-service-pro'),
			'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
			'section' => 'cleaning_service_pro_topbar_section',
			'settings' => 'cleaning_service_pro_topbar_section_bgimage'
		)));

		$wp_customize->add_setting( 'cleaning_service_pro_topbar_section_content_settings',
		array(
			'default' => '',
			'transport' => 'postMessage',
			'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
		));
		$wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_topbar_section_content_settings',
			array(
			'label' => __('Section Content Settings','cleaning-service-pro'),
			'section' => 'cleaning_service_pro_topbar_section'
		)));
		$wp_customize->add_setting('cleaning_service_pro_topbar_text',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar_text',array(
			'label'	=> __('Topbar Text','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar_section',
			'setting'	=> 'cleaning_service_pro_topbar_text',
			'type'		=> 'text'
		));

		$wp_customize->add_setting('cleaning_service_pro_topbar_email_title',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar_email_title',array(
			'label'	=> __('Email Title','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar_section',
			'setting'	=> 'cleaning_service_pro_topbar_email_title',
			'type'		=> 'text'
		));

		$wp_customize->add_setting('cleaning_service_pro_topbar_email_text',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar_email_text',array(
			'label'	=> __('Email Text','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar_section',
			'setting'	=> 'cleaning_service_pro_topbar_email_text',
			'type'		=> 'text'
		));

		$wp_customize->add_setting('cleaning_service_pro_topbar_email_icon',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar_email_icon',array(
			'label'	=> __('Email Icon','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar_section',
			'setting'	=> 'cleaning_service_pro_topbar_email_icon',
			'type'		=> 'text'
		));

		$wp_customize->add_setting('cleaning_service_pro_topbar_career_btn',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar_career_btn',array(
			'label'	=> __('Career Button','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar_section',
			'setting'	=> 'cleaning_service_pro_topbar_career_btn',
			'type'		=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_topbar_career_btn_url',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar_career_btn_url',array(
			'label'	=> __('Career Button Url','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar_section',
			'setting'	=> 'cleaning_service_pro_topbar_career_btn_url',
			'type'		=> 'text'
		));

		$wp_customize->add_setting('cleaning_service_pro_topbar_services_btn',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar_services_btn',array(
			'label'	=> __('Service Button','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar_section',
			'setting'	=> 'cleaning_service_pro_topbar_services_btn',
			'type'		=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_topbar_services_btn_url',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar_services_btn_url',array(
			'label'	=> __('Service Button Url','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar_section',
			'setting'	=> 'cleaning_service_pro_topbar_services_btn_url',
			'type'		=> 'text'
		));

		$wp_customize->add_setting('cleaning_service_pro_topbar_contact_btn',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar_contact_btn',array(
			'label'	=> __('Contact Button','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar_section',
			'setting'	=> 'cleaning_service_pro_topbar_contact_btn',
			'type'		=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_topbar_contact_btn_url',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar_contact_btn_url',array(
			'label'	=> __('Contact Button Url','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar_section',
			'setting'	=> 'cleaning_service_pro_topbar_contact_btn_url',
			'type'		=> 'text'
		));

		$wp_customize->add_setting( 'cleaning_service_pro_topbar_color_settings',array(
		    'default' => '',
			'transport' => 'postMessage',
			'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
		));
		$wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_topbar_color_settings',
			array(
			'label' => __('Topbars Color Settings ','cleaning-service-pro'),
			'section' => 'cleaning_service_pro_topbar_section'
		)));

		$wp_customize->add_setting( 'cleaning_service_pro_topbar_text_color', array(
			'default' => '',
			'sanitize_callback' => 'sanitize_hex_color'
		));
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_topbar_text_color', array(
			'label' => __('Topbar Text Color', 'cleaning-service-pro'),
			'section' => 'cleaning_service_pro_topbar_section',
			'settings' => 'cleaning_service_pro_topbar_text_color',
		)));
		$wp_customize->add_setting('cleaning_service_pro_topbar_text_font_family',array(
			'default' => '',
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
		));
		$wp_customize->add_control(
			'cleaning_service_pro_topbar_text_font_family', array(
			'section'  => 'cleaning_service_pro_topbar_section',
			'label'    => __( 'Topbar Text Fonts','cleaning-service-pro'),
			'type'     => 'select',
			'choices'  => $font_array
		));

		$wp_customize->add_setting( 'cleaning_service_pro_topbar_btn_color', array(
			'default' => '',
			'sanitize_callback' => 'sanitize_hex_color'
		));
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_topbar_btn_color', array(
			'label' => __('Topbar Button Color', 'cleaning-service-pro'),
			'section' => 'cleaning_service_pro_topbar_section',
			'settings' => 'cleaning_service_pro_topbar_btn_color',
		)));
		$wp_customize->add_setting('cleaning_service_pro_topbar_btn_font_family',array(
			'default' => '',
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
		));
		$wp_customize->add_control(
			'cleaning_service_pro_topbar_btn_font_family', array(
			'section'  => 'cleaning_service_pro_topbar_section',
			'label'    => __( 'Topbar Button Fonts','cleaning-service-pro'),
			'type'     => 'select',
			'choices'  => $font_array
		));

	// ------------- Topbar-1----------------

		$wp_customize->add_section('cleaning_service_pro_topbar1_section',array(
			'title'	=> __('Topbar 1','cleaning-service-pro'),
			'description'	=> __('Topbar 1 Settings','cleaning-service-pro'),
			'priority'	=> null,
			'panel' => 'cleaning_service_pro_panel_id',
		));
		$wp_customize->add_setting( 'cleaning_service_pro_topbar1_enable',
			array(
			  'default' => 1,
			  'transport' => 'refresh',
			  'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
			));
		$wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control($wp_customize, 'cleaning_service_pro_topbar1_enable',
		  array(
		    'label' => esc_html__( 'Show or Hide Topbar-1', 'cleaning-service-pro' ),
		    'section' => 'cleaning_service_pro_topbar1_section'
		)));
	    $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_topbar1_enable', array(
		    'selector' => '#topbar1 p',
		    'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_topbar1_enable',
		) );
		$wp_customize->add_setting( 'cleaning_service_pro_topbar1_settings',
	    array(
		    'default' => '',
		    'transport' => 'postMessage',
		    'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
	  	));
		$wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_topbar1_settings',
		    array(
		    'label' => __('Section Background Settings','cleaning-service-pro'),
		    'section' => 'cleaning_service_pro_topbar1_section'
		)));
		$wp_customize->add_setting( 'cleaning_service_pro_topbar1_bgcolor', array(
		    'default' => '',
		    'sanitize_callback' => 'sanitize_hex_color'
		));
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_topbar1_bgcolor', array(
			'label' => __('Section Background Color', 'cleaning-service-pro'),
			'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
			'section' => 'cleaning_service_pro_topbar1_section',
			'settings' => 'cleaning_service_pro_topbar1_bgcolor',
		)));

		$wp_customize->add_setting('cleaning_service_pro_topbar1_bgimage',array(
			'default' => '',
			'sanitize_callback' => 'esc_url_raw',
		));
		$wp_customize->add_control(
		new WP_Customize_Image_Control( $wp_customize,'cleaning_service_pro_topbar1_bgimage',array(
			'label' => __('Section Background Image','cleaning-service-pro'),
			'description' => __('Dimension 1600 * 800','cleaning-service-pro'),
			'section' => 'cleaning_service_pro_topbar1_section',
			'settings' => 'cleaning_service_pro_topbar1_bgimage'
		)));

		$wp_customize->add_setting( 'cleaning_service_pro_topbar1_section_content_settings',
		array(
			'default' => '',
			'transport' => 'postMessage',
			'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
		));
		$wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_topbar1_section_content_settings',
			array(
			'label' => __('Section Content Settings','cleaning-service-pro'),
			'section' => 'cleaning_service_pro_topbar1_section'
		)));
		$wp_customize->add_setting('cleaning_service_pro_topbar1_location_icon',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar1_location_icon',array(
			'label'	=> __('Location Icon','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar1_section',
			'setting'	=> 'cleaning_service_pro_topbar1_location_icon',
			'type'		=> 'text'
		));

		$wp_customize->add_setting('cleaning_service_pro_topbar1_location_title',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar1_location_title',array(
			'label'	=> __('Location Title','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar1_section',
			'setting'	=> 'cleaning_service_pro_topbar1_location_title',
			'type'		=> 'text'
		));

		$wp_customize->add_setting('cleaning_service_pro_topbar1_location_text',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar1_location_text',array(
			'label'	=> __('Location Text','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar1_section',
			'setting'	=> 'cleaning_service_pro_topbar1_location_text',
			'type'		=> 'text'
		));

		$wp_customize->add_setting('cleaning_service_pro_topbar1_phone_icon',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar1_phone_icon',array(
			'label'	=> __('Phone Icon','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar1_section',
			'setting'	=> 'cleaning_service_pro_topbar1_phone_icon',
			'type'		=> 'text'
		));

		$wp_customize->add_setting('cleaning_service_pro_topbar1_phone_title',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar1_phone_title',array(
			'label'	=> __('Phone Title','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar1_section',
			'setting'	=> 'cleaning_service_pro_topbar1_phone_title',
			'type'		=> 'text'
		));
		$wp_customize->add_setting('cleaning_service_pro_topbar1_phone_text',array(
			'default'	=> '',
			'sanitize_callback'	=> 'sanitize_text_field'
		));
		$wp_customize->add_control('cleaning_service_pro_topbar1_phone_text',array(
			'label'	=> __('Phone Text','cleaning-service-pro'),
			'section'	=> 'cleaning_service_pro_topbar1_section',
			'setting'	=> 'cleaning_service_pro_topbar1_phone_text',
			'type'		=> 'text'
		));

		$wp_customize->add_setting( 'cleaning_service_pro_topbar1_color_settings',array(
		    'default' => '',
			'transport' => 'postMessage',
			'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
		));
		$wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_topbar1_color_settings',
			array(
			'label' => __('Color Settings ','cleaning-service-pro'),
			'section' => 'cleaning_service_pro_topbar1_section'
		)));
		$wp_customize->add_setting( 'cleaning_service_pro_header_logo_title_color', array(
			'default' => '',
			'sanitize_callback'	=> 'sanitize_hex_color'
		));
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_header_logo_title_color', array(
			'label' => __('Logo Title Color', 'cleaning-service-pro'),
			'section' => 'cleaning_service_pro_topbar1_section',
			'settings' => 'cleaning_service_pro_header_logo_title_color',
		)));
		$wp_customize->add_setting('cleaning_service_pro_header_logo_title_font_family',array(
		  'default' => '',
		  'capability' => 'edit_theme_options',
		  'sanitize_callback' => 'sanitize_text_field'
		));
		$wp_customize->add_control(
		    'cleaning_service_pro_header_logo_title_font_family', array(
		    'section'  => 'cleaning_service_pro_topbar1_section',
		    'label'    => __('Logo Title Font family','cleaning-service-pro'),
		    'type'     => 'select',
		    'choices'  => $font_array,
		));
		$wp_customize->add_setting( 'cleaning_service_pro_header_subtitle_color', array(
			'default' => '',
			'sanitize_callback'	=> 'sanitize_hex_color'
		));
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_header_subtitle_color', array(
			'label' => __('Logo Title Color', 'cleaning-service-pro'),
			'section' => 'cleaning_service_pro_topbar1_section',
			'settings' => 'cleaning_service_pro_header_subtitle_color',
		)));
		$wp_customize->add_setting('cleaning_service_pro_header_subtitle_font_family',array(
		  'default' => '',
		  'capability' => 'edit_theme_options',
		  'sanitize_callback' => 'sanitize_text_field'
		));
		$wp_customize->add_control(
		    'cleaning_service_pro_header_subtitle_font_family', array(
		    'section'  => 'cleaning_service_pro_topbar1_section',
		    'label'    => __('Logo Title Font family','cleaning-service-pro'),
		    'type'     => 'select',
		    'choices'  => $font_array,
		));
		$wp_customize->add_setting( 'cleaning_service_pro_topbar1_icon_color', array(
			'default' => '',
			'sanitize_callback' => 'sanitize_hex_color'
		));
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_topbar1_icon_color', array(
			'label' => __('Icon Color', 'cleaning-service-pro'),
			'section' => 'cleaning_service_pro_topbar1_section',
			'settings' => 'cleaning_service_pro_topbar1_icon_color',
		)));

		$wp_customize->add_setting( 'cleaning_service_pro_topbar1_text_color', array(
			'default' => '',
			'sanitize_callback' => 'sanitize_hex_color'
		));
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_topbar1_text_color', array(
			'label' => __('Text Color', 'cleaning-service-pro'),
			'section' => 'cleaning_service_pro_topbar1_section',
			'settings' => 'cleaning_service_pro_topbar1_text_color',
		)));
		$wp_customize->add_setting('cleaning_service_pro_topbar1_text_font_family',array(
			'default' => '',
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
		));
		$wp_customize->add_control(
			'cleaning_service_pro_topbar1_text_font_family', array(
			'section'  => 'cleaning_service_pro_topbar1_section',
			'label'    => __( 'Text Fonts','cleaning-service-pro'),
			'type'     => 'select',
			'choices'  => $font_array
		));
		
	// Header Section
	
	$wp_customize->add_section('cleaning_service_pro_header_section',array(
		'title'	=> __('Header','cleaning-service-pro'),
		'description'	=> __('Header Settings','cleaning-service-pro'),
		'priority'	=> null,
		'panel' => 'cleaning_service_pro_panel_id',
	));
	$wp_customize->add_setting( 'cleaning_service_pro_header_search_toggle',
	array(
	  'default' => 1,
	  'transport' => 'refresh',
	  'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
	));

	$wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control( $wp_customize, 'cleaning_service_pro_header_search_toggle',
	array(
	    'label' => esc_html__( 'Show or Hide Search', 'cleaning-service-pro' ),
	    'section' => 'cleaning_service_pro_header_section'
	)));
    $wp_customize->add_setting( 'cleaning_service_pro_header_color_settings',array(
	    'default' => '',
		'transport' => 'postMessage',
		'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
	));
	$wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_header_color_settings',
		array(
		'label' => __('Header Color Settings ','cleaning-service-pro'),
		'section' => 'cleaning_service_pro_header_section'
	)));
	$wp_customize->add_setting( 'cleaning_service_pro_header_search_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_header_search_color', array(
		'label' => __('Search Icon Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_header_section',
		'settings' => 'cleaning_service_pro_header_search_color',
	)));

	$wp_customize->add_setting( 'cleaning_service_pro_headerhomebg_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_headerhomebg_color', array(
		'label' => __('Header Background Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_header_section',
		'settings' => 'cleaning_service_pro_headerhomebg_color',
	)));

	// This is Header Menu Color picker setting
	$wp_customize->add_setting( 'cleaning_service_pro_headermenu_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_headermenu_color', array(
		'label' => __('Menu Item Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_header_section',
		'settings' => 'cleaning_service_pro_headermenu_color',
	)));
	//This is Header Menu FontFamily picker setting
	$wp_customize->add_setting('cleaning_service_pro_headermenu_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
	 ));
	$wp_customize->add_control(
	    'cleaning_service_pro_headermenu_font_family', array(
	    'section'  => 'cleaning_service_pro_header_section',
	    'label'    => __( 'Menu Item Fonts','cleaning-service-pro'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));
	$wp_customize->add_setting( 'cleaning_service_pro_header_menuhovercolor', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_header_menuhovercolor', array(
		'label' => __('Menu Item Hover Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_header_section',
		'settings' => 'cleaning_service_pro_header_menuhovercolor',
	)));
	
	// This is Nav Dropdown Background Color picker setting
	$wp_customize->add_setting( 'cleaning_service_pro_dropdownbg_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_dropdownbg_color', array(
		'label' => __('Menu DropDown Background Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_header_section',
		'settings' => 'cleaning_service_pro_dropdownbg_color',
	)));

	$wp_customize->add_setting( 'cleaning_service_pro_dropdownbg_itemcolor', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_dropdownbg_itemcolor', array(
		'label' => __('Menu DropDown Item Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_header_section',
		'settings' => 'cleaning_service_pro_dropdownbg_itemcolor',
	)));

	$wp_customize->add_setting( 'cleaning_service_pro_dropdownbg_item_hovercolor', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_dropdownbg_item_hovercolor', array(
		'label' => __('Menu DropDown Item Hover Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_header_section',
		'settings' => 'cleaning_service_pro_dropdownbg_item_hovercolor',
	)));

	$wp_customize->add_setting( 'cleaning_service_pro_header_menu_active_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_header_menu_active_color', array(
		'label' => __('Active Menu Item Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_header_section',
		'settings' => 'cleaning_service_pro_header_menu_active_color',
	)));

	$wp_customize->add_setting( 'cleaning_service_pro_header_menu_active_bgcolor', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_header_menu_active_bgcolor', array(
		'label' => __('Active Menu Item Background Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_header_section',
		'settings' => 'cleaning_service_pro_header_menu_active_bgcolor',
	)));
	
	//In Responsive
	$wp_customize->add_setting( 'cleaning_service_pro_dropdownbg_responsivecolor', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_dropdownbg_responsivecolor', array(
		'label' => __('Responsive Menu Background Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_header_section',
		'settings' => 'cleaning_service_pro_dropdownbg_responsivecolor',
	)));
	$wp_customize->add_setting( 'cleaning_service_pro_headermenu_responsive_item_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_headermenu_responsive_item_color', array(
		'label' => __('Responsive Menu item Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_header_section',
		'settings' => 'cleaning_service_pro_headermenu_responsive_item_color',
	)));
	$wp_customize->add_setting( 'cleaning_service_pro_headermenu_responsive_item_active_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_headermenu_responsive_item_active_color', array(
		'label' => __('Responsive Menu item Active Color', 'cleaning-service-pro'),
		'section' => 'cleaning_service_pro_header_section',
		'settings' => 'cleaning_service_pro_headermenu_responsive_item_active_color',
	)));
	
?>