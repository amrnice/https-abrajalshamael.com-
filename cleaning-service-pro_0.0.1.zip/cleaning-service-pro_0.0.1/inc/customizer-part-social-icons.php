<?php
    /* Footer Sections */
    $wp_customize->add_section('cleaning_service_pro_social_icons',array(
        'title' => __('Social Icons','cleaning-service-pro'),
        'description'   => __('Add social Icons Here','cleaning-service-pro'),
        'panel' => 'cleaning_service_pro_panel_id',
    ));
    $wp_customize->add_setting('cleaning_service_pro_headertwitter',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cleaning_service_pro_headertwitter',array(
        'label' => __('Add twitter link','cleaning-service-pro'),
        'section'   => 'cleaning_service_pro_social_icons',
        'setting'   => 'cleaning_service_pro_headertwitter',
        'type'      => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_headerpinterest',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    
    $wp_customize->add_control('cleaning_service_pro_headerpinterest',array(
        'label' => __('Add pinterest link','cleaning-service-pro'),
        'section'   => 'cleaning_service_pro_social_icons',
        'setting'   => 'cleaning_service_pro_headerpinterest',
        'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_headerfacebook',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cleaning_service_pro_headerfacebook',array(
        'label' => __('Add facebook link','cleaning-service-pro'),
        'section'   => 'cleaning_service_pro_social_icons',
        'setting'   => 'cleaning_service_pro_headerfacebook',
        'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_headeryoutube',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cleaning_service_pro_headeryoutube',array(
        'label' => __('Add Youtube link','cleaning-service-pro'),
        'section'   => 'cleaning_service_pro_social_icons',
        'setting'   => 'cleaning_service_pro_headeryoutube',
        'type'  => 'text'
    ));   

    $wp_customize->add_setting('cleaning_service_pro_headerinstagram',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cleaning_service_pro_headerinstagram',array(
        'label' => __('Add Instagram link','cleaning-service-pro'),
        'section'   => 'cleaning_service_pro_social_icons',
        'setting'   => 'cleaning_service_pro_headerinstagram',
        'type'  => 'text'
    ));   

    $wp_customize->add_setting('cleaning_service_pro_headerlinkedin',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cleaning_service_pro_headerlinkedin',array(
        'label' => __('Add Linkedin link','cleaning-service-pro'),
        'section'   => 'cleaning_service_pro_social_icons',
        'setting'   => 'cleaning_service_pro_headerlinkedin',
        'type'  => 'text'
    ));

    $wp_customize->add_setting('cleaning_service_pro_headertumblric',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cleaning_service_pro_headertumblric',array(
        'label' => __('Add Tumblric link','cleaning-service-pro'),
        'section'   => 'cleaning_service_pro_social_icons',
        'setting'   => 'cleaning_service_pro_headertumblric',
        'type'  => 'text'
    ));

    $wp_customize->add_setting('cleaning_service_pro_headerflickr',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cleaning_service_pro_headerflickr',array(
        'label' => __('Add Flicker link','cleaning-service-pro'),
        'section'   => 'cleaning_service_pro_social_icons',
        'setting'   => 'cleaning_service_pro_headerflickr',
        'type'  => 'text'
    ));  

    $wp_customize->add_setting('cleaning_service_pro_headervk',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cleaning_service_pro_headervk',array(
        'label' => __('Add Vk link','cleaning-service-pro'),
        'section'   => 'cleaning_service_pro_social_icons',
        'setting'   => 'cleaning_service_pro_headervk',
        'type'  => 'text'
    ));   
?>