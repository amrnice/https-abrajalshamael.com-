<?php
/**
 * cleaning-service-pro Theme Customizer
 *
 * @package cleaning-service-pro
 */
/**
 * Loads custom control for layout settings
 */
function cleaning_service_pro_custom_controls() {
    require_once get_template_directory() . '/inc/custom-controls.php';

     // Inlcude the Alpha Color Picker control file.
    require_once get_template_directory() . '/inc/alpha-color-picker.php';
    get_stylesheet_directory_uri() . '/assets/js/alpha-color-picker.js';
    get_stylesheet_directory_uri() . '/assets/css/alpha-color-picker.css';

    
}
add_action( 'customize_register', 'cleaning_service_pro_custom_controls' );
/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function cleaning_service_pro_customize_register( $wp_customize ) {
    $wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
    $wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';

    $wp_customize->selective_refresh->add_partial( 'blogname', array(
        'selector' => '.logo a',
        'render_callback' => 'twentyfifteen_customize_partial_blogname',
    ) );
    $wp_customize->selective_refresh->add_partial( 'blogdescription', array(
        'selector' => '.site-description',
        'render_callback' => 'twentyfifteen_customize_partial_blogdescription',
    ) );

    $wp_customize->add_setting('cleaning_service_pro_display_title',array(
        'default' => 'false',
        'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cleaning_service_pro_display_title',array(
        'type' => 'checkbox',
        'label' => __('Show Title','cleaning-service-pro'),
        'section' => 'title_tagline',
    ));
    $wp_customize->add_setting('cleaning_service_pro_display_tagline',array(
        'default' => 'false',
        'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cleaning_service_pro_display_tagline',array(
        'type' => 'checkbox',
        'label' => __('Show Tagline','cleaning-service-pro'),
        'section' => 'title_tagline',
    ));
    
    //add home page setting pannel
    $wp_customize->add_panel( 'cleaning_service_pro_panel_id', array(
        'priority' => 10,
        'capability' => 'edit_theme_options',
        'theme_supports' => '',
        'title' => __( 'Theme Settings', 'cleaning-service-pro' ),
        'description' => __( 'Description of what this panel does.', 'cleaning-service-pro' ),
    ) );
    $font_array = array(
        '' => __( 'No Fonts', 'cleaning-service-pro' ),
        'Abril Fatface' => __( 'Abril Fatface', 'cleaning-service-pro' ),
        'Acme' => __( 'Acme', 'cleaning-service-pro' ),
        'Anton' => __( 'Anton', 'cleaning-service-pro' ),
        'Architects Daughter' => __( 'Architects Daughter', 'cleaning-service-pro' ),
        'Arimo' => __( 'Arimo', 'cleaning-service-pro' ),
        'Arsenal' => __( 'Arsenal', 'cleaning-service-pro' ),
        'Arvo' => __( 'Arvo', 'cleaning-service-pro' ),
        'Alegreya' => __( 'Alegreya', 'cleaning-service-pro' ),
        'Alfa Slab One' => __( 'Alfa Slab One', 'cleaning-service-pro' ),
        'Averia Serif Libre' => __( 'Averia Serif Libre', 'cleaning-service-pro' ),
        'Bangers' => __( 'Bangers', 'cleaning-service-pro' ),
        'Boogaloo' => __( 'Boogaloo', 'cleaning-service-pro' ),
        'Bad Script' => __( 'Bad Script', 'cleaning-service-pro' ),
        'Bitter' => __( 'Bitter', 'cleaning-service-pro' ),
        'Bree Serif' => __( 'Bree Serif', 'cleaning-service-pro' ),
        'BenchNine' => __( 'BenchNine', 'cleaning-service-pro' ),
        'Cabin' => __( 'Cabin', 'cleaning-service-pro' ),
        'Cardo' => __( 'Cardo', 'cleaning-service-pro' ),
        'Courgette' => __( 'Courgette', 'cleaning-service-pro' ),
        'Cherry Swash' => __( 'Cherry Swash', 'cleaning-service-pro' ),
        'Cormorant Garamond' => __( 'Cormorant Garamond', 'cleaning-service-pro' ),
        'Crimson Text' => __( 'Crimson Text', 'cleaning-service-pro' ),
        'Cuprum' => __( 'Cuprum', 'cleaning-service-pro' ),
        'Cookie' => __( 'Cookie', 'cleaning-service-pro' ),
        'Chewy' => __( 'Chewy', 'cleaning-service-pro' ),
        'Days One' => __( 'Days One', 'cleaning-service-pro' ),
        'Dosis' => __( 'Dosis', 'cleaning-service-pro' ),
        'Economica' => __( 'Economica', 'cleaning-service-pro' ),
        'Fredoka One' => __( 'Fredoka One', 'cleaning-service-pro' ),
        'Fjalla One' => __( 'Fjalla One', 'cleaning-service-pro' ),
        'Francois One' => __( 'Francois One', 'cleaning-service-pro' ),
        'Frank Ruhl Libre' => __( 'Frank Ruhl Libre', 'cleaning-service-pro' ),
        'Gloria Hallelujah' => __( 'Gloria Hallelujah', 'cleaning-service-pro' ),
        'Great Vibes' => __( 'Great Vibes', 'cleaning-service-pro' ),
        'Handlee' => __( 'Handlee', 'cleaning-service-pro' ),
        'Hammersmith One' => __( 'Hammersmith One', 'cleaning-service-pro' ),
        'Inconsolata' => __( 'Inconsolata', 'cleaning-service-pro' ),
        'Indie Flower' => __( 'Indie Flower', 'cleaning-service-pro' ),
        'IM Fell English SC' => __( 'IM Fell English SC', 'cleaning-service-pro' ),
        'Julius Sans One' => __( 'Julius Sans One', 'cleaning-service-pro' ),
        'Josefin Slab' => __( 'Josefin Slab', 'cleaning-service-pro' ),
        'Josefin Sans' => __( 'Josefin Sans', 'cleaning-service-pro' ),
        'Kanit' => __( 'Kanit', 'cleaning-service-pro' ),
        'Lobster' => __( 'Lobster', 'cleaning-service-pro' ),
        'Lato' => __( 'Lato', 'cleaning-service-pro' ),
        'Lora' => __( 'Lora', 'cleaning-service-pro' ),
        'Libre Baskerville' => __( 'Libre Baskerville', 'cleaning-service-pro' ),
        'Lobster Two' => __( 'Lobster Two', 'cleaning-service-pro' ),
        'Merriweather' => __( 'Merriweather', 'cleaning-service-pro' ),
        'Monda' => __( 'Monda', 'cleaning-service-pro' ),
        'Montserrat' => __( 'Montserrat', 'cleaning-service-pro' ),
        'Muli' => __( 'Muli', 'cleaning-service-pro' ),
        'Marck Script' => __( 'Marck Script', 'cleaning-service-pro' ),
        'Noto Serif' => __( 'Noto Serif', 'cleaning-service-pro' ),
        'Open Sans' => __( 'Open Sans', 'cleaning-service-pro' ),
        'Overpass' => __( 'Overpass', 'cleaning-service-pro' ),
        'Overpass Mono' => __( 'Overpass Mono', 'cleaning-service-pro' ),
        'Oxygen' => __( 'Oxygen', 'cleaning-service-pro' ),
        'Orbitron' => __( 'Orbitron', 'cleaning-service-pro' ),
        'Patua One' => __( 'Patua One', 'cleaning-service-pro' ),
        'Pacifico' => __( 'Pacifico', 'cleaning-service-pro' ),
        'Padauk' => __( 'Padauk', 'cleaning-service-pro' ),
        'Playball' => __( 'Playball', 'cleaning-service-pro' ),
        'Playfair Display' => __( 'Playfair Display', 'cleaning-service-pro' ),
        'PT Sans' => __( 'PT Sans', 'cleaning-service-pro' ),
        'Philosopher' => __( 'Philosopher', 'cleaning-service-pro' ),
        'Permanent Marker' => __( 'Permanent Marker', 'cleaning-service-pro' ),
        'Poiret One' => __( 'Poiret One', 'cleaning-service-pro' ),
        'Quicksand' => __( 'Quicksand', 'cleaning-service-pro' ),
        'Quattrocento Sans' => __( 'Quattrocento Sans', 'cleaning-service-pro' ),
        'Raleway' => __( 'Raleway', 'cleaning-service-pro' ),
        'Rubik' => __( 'Rubik', 'cleaning-service-pro' ),
        'Rokkitt' => __( 'Rokkitt', 'cleaning-service-pro' ),
        'Russo One' => __( 'Russo One', 'cleaning-service-pro' ),
        'Righteous' => __( 'Righteous', 'cleaning-service-pro' ),
        'Slabo' => __( 'Slabo', 'cleaning-service-pro' ),
        'Source Sans Pro' => __( 'Source Sans Pro', 'cleaning-service-pro' ),
        'Shadows Into Light Two' => __( 'Shadows Into Light Two', 'cleaning-service-pro'),
        'Shadows Into Light' => __( 'Shadows Into Light', 'cleaning-service-pro' ),
        'Sacramento' => __( 'Sacramento', 'cleaning-service-pro' ),
        'Shrikhand' => __( 'Shrikhand', 'cleaning-service-pro' ),
        'Tangerine' => __( 'Tangerine', 'cleaning-service-pro' ),
        'Ubuntu' => __( 'Ubuntu', 'cleaning-service-pro' ),
        'VT323' => __( 'VT323', 'cleaning-service-pro' ),
        'Varela Round' => __( 'Varela Round', 'cleaning-service-pro' ),
        'Vampiro One' => __( 'Vampiro One', 'cleaning-service-pro' ),
        'Vollkorn' => __( 'Vollkorn', 'cleaning-service-pro' ),
        'Volkhov' => __( 'Volkhov', 'cleaning-service-pro' ),
        'Yanone Kaffeesatz' => __( 'Yanone Kaffeesatz', 'cleaning-service-pro' )
    );

    require_once get_template_directory() . '/inc/customizer-seperator/class/customizer-seperator.php';
    require get_template_directory() . '/inc/customize-repeater/customize-repeater.php';

    //general Settings
    require get_template_directory() . '/inc/customizer-custom-variables.php';
    //Header
    require get_template_directory() . '/inc/customizer-part-header.php';
    //Slider
    require get_template_directory() . '/inc/customizer-part-slide.php';
    //Home page sections
    require get_template_directory() . '/inc/customizer-part-home.php';
    //Social Icon
    require get_template_directory() . '/inc/customizer-part-social-icons.php';
    //Footer
    require get_template_directory() . '/inc/customizer-part-footer.php';
}
add_action( 'customize_register', 'cleaning_service_pro_customize_register' );

//Integer
function cleaning_service_pro_sanitize_integer( $input ) {
    if( is_numeric( $input ) ) {
        return intval( $input );
    }
}
