<?php
    /* Footer Sections */
    $wp_customize->add_section('cleaning_service_pro_footer_widget_section',array(
        'title' => __('Footer Widgets','cleaning-service-pro'),
        'description'   => __('Edit footer Widgets sections','cleaning-service-pro'),
        'panel' => 'cleaning_service_pro_panel_id',
    ));
    $wp_customize->add_setting( 'cleaning_service_pro_footer_widgets_enable',
        array(
          'default' => 1,
          'transport' => 'refresh',
          'sanitize_callback' => 'cleaning_service_pro_switch_sanitization'
    ));
    $wp_customize->add_control( new Cleaning_Service_Pro_Toggle_Switch_Custom_Control( $wp_customize, 'cleaning_service_pro_footer_widgets_enable',
    array(
        'label' => esc_html__( 'Show or Hide Footer', 'cleaning-service-pro' ),
        'section' => 'cleaning_service_pro_footer_widget_section'
    )));    
    $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_footer_widgets_enable', array(
      'selector' => '#footer .footer-cols',
      'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_footer_widgets_enable',
    ) );

    $wp_customize->add_setting( 'cleaning_service_pro_footer_widget_section_setting',
    array(
      'default' => '',
      'transport' => 'postMessage',
      'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
    ));
    $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_footer_widget_section_setting',
        array(
          'label' => __('Section Background Setting','cleaning-service-pro'),
          'section' => 'cleaning_service_pro_footer_widget_section'
        )
    ) );

    // add color picker setting
    $wp_customize->add_setting( 'cleaning_service_pro_footer_widget_bgcolor', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_footer_widget_bgcolor', array(
        'label' => __('Background Color', 'cleaning-service-pro'),
        'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
        'section' => 'cleaning_service_pro_footer_widget_section',
        'settings' => 'cleaning_service_pro_footer_widget_bgcolor',
    )));
    $wp_customize->add_setting('cleaning_service_pro_footer_widget_bgimage',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control(
            $wp_customize,
      'cleaning_service_pro_footer_widget_bgimage',
      array(
          'label' => __('Background image','cleaning-service-pro'),
          'description' => __('Dimention 1600 * 600','cleaning-service-pro'),
          'section' => 'cleaning_service_pro_footer_widget_section',
          'settings' => 'cleaning_service_pro_footer_widget_bgimage'
    )));
    
    /*-----------------Footer Copyright--------------*/

    $wp_customize->add_section('cleaning_service_pro_footer_section',array(
        'title' => __('Footer Text','cleaning-service-pro'),
        'description'   => __('Add some text for footer like copyright etc.','cleaning-service-pro'),
        'priority'  => null,
        'panel' => 'cleaning_service_pro_panel_id',
    ));

    $wp_customize->add_setting('cleaning_service_pro_footer_copy',array(
        'default'   => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_footer_copy',array(
        'label' => __('Copyright Text','cleaning-service-pro'),
        'section'   => 'cleaning_service_pro_footer_section',
        'type'      => 'text'
    ));

    $wp_customize->selective_refresh->add_partial( 'cleaning_service_pro_footer_copy', array(
      'selector' => '.copy-text',
      'render_callback' => 'cleaning_service_pro_customize_partial_cleaning_service_pro_footer_copy',
    ) );
    $wp_customize->add_setting('cleaning_service_pro_footer_card_image',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cleaning_service_pro_footer_card_image',
          array(
            'label' => __('Footer Card Image ','cleaning-service-pro'),
            'section' => 'cleaning_service_pro_footer_section',
            'settings' => 'cleaning_service_pro_footer_card_image'
    )));
    // add color picker setting
    $wp_customize->add_setting( 'cleaning_service_pro_footer_copy_bgcolor', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color'
    ));
    // add color picker control
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_footer_copy_bgcolor', array(
        'label' => __('Background Color', 'cleaning-service-pro'),
        'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cleaning-service-pro'),
        'section' => 'cleaning_service_pro_footer_section',
        'settings' => 'cleaning_service_pro_footer_copy_bgcolor',
    )));
    $wp_customize->add_setting('cleaning_service_pro_footer_copy_bgimage',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(
        new WP_Customize_Image_Control(
            $wp_customize,
            'cleaning_service_pro_footer_copy_bgimage',
            array(
                'label' => __('Background image','cleaning-service-pro'),
                'description' => __('Dimention 1600 * 500','cleaning-service-pro'),
                'section' => 'cleaning_service_pro_footer_section',
                'settings' => 'cleaning_service_pro_footer_copy_bgimage'
    )));

    $wp_customize->add_setting( 'cleaning_service_pro_footer_copy_content_color', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color'
    ));
    // add color picker control
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_footer_copy_content_color', array(
        'label' => __('Content Color', 'cleaning-service-pro'),
        'section' => 'cleaning_service_pro_footer_section',
        'settings' => 'cleaning_service_pro_footer_copy_content_color',
    )));

    $wp_customize->add_setting('cleaning_service_pro_footer_copy_content_font_family',array(
      'default' => '',
      'capability' => 'edit_theme_options',
      'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
    ));
    $wp_customize->add_control(
        'cleaning_service_pro_footer_copy_content_font_family', array(
        'section'  => 'cleaning_service_pro_footer_section',
        'label'    => __( 'Content Font Family','cleaning-service-pro'),
        'type'     => 'select',
        'choices'  => $font_array,
    ));
    
    /* Contact Page section */

    $wp_customize->add_section('cleaning_service_pro_contact_page_section',array(
        'title' => __('Contact','cleaning-service-pro'),
        'description'   => __('Add contact page settings here).','cleaning-service-pro'),
        'priority'  => null,
        'panel' => 'cleaning_service_pro_panel_id',
    ));

    $wp_customize->add_setting( 'cleaning_service_pro_contact_page_section_setting',
    array(
      'default' => '',
      'transport' => 'postMessage',
      'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
    ));
    $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_contact_page_section_setting',
        array(
          'label' => __('Section Heading Setting','cleaning-service-pro'),
          'section' => 'cleaning_service_pro_contact_page_section'
        )
    ) );

    $wp_customize->add_setting('cleaning_service_pro_contactpage_form_title',array(
        'default'   => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_contactpage_form_title',array(
        'label' => __('Form Title Title','cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'setting'   => 'cleaning_service_pro_contactpage_form_title',
        'type'  => 'text'
    ));
    $wp_customize->add_setting( 'cleaning_service_pro_contact_page_section_email_setting',
    array(
      'default' => '',
      'transport' => 'postMessage',
      'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
    ));
    $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_contact_page_section_email_setting',
        array(
          'label' => __('Section Email Setting','cleaning-service-pro'),
          'section' => 'cleaning_service_pro_contact_page_section'
        )
    ) );

    $wp_customize->add_setting('cleaning_service_pro_contactpage_email_title',array(
        'default'   => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_contactpage_email_title',array(
        'label' => __('Email Title','cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'setting'   => 'cleaning_service_pro_contactpage_email_title',
        'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_contactpage_email_one',array(
        'default'   => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_contactpage_email_one',array(
        'label' => __('First Email','cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'setting'   => 'cleaning_service_pro_contactpage_email_one',
        'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_contactpage_email_two',array(
        'default'   => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_contactpage_email_two',array(
        'label' => __('Second Email','cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'setting'   => 'cleaning_service_pro_contactpage_email_two',
        'type'  => 'text'
    ));

    $wp_customize->add_setting( 'cleaning_service_pro_contact_page_section_address_setting',
    array(
      'default' => '',
      'transport' => 'postMessage',
      'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
    ));
    $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_contact_page_section_address_setting',
        array(
          'label' => __('Section Address Setting','cleaning-service-pro'),
          'section' => 'cleaning_service_pro_contact_page_section'
        )
    ) );
    
    $wp_customize->add_setting('cleaning_service_pro_address_title',array(
        'default'   => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_address_title',array(
        'label' => __('Address','cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'setting'   => 'cleaning_service_pro_address_title',
        'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_address',array(
        'default'   => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_address',array(
        'label' => __('Address ','cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'setting'   => 'cleaning_service_pro_address',
        'type'  => 'textarea'
    ));

    $wp_customize->add_setting( 'cleaning_service_pro_contact_page_section_phone_setting',
    array(
      'default' => '',
      'transport' => 'postMessage',
      'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
    ));
    $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_contact_page_section_phone_setting',
        array(
          'label' => __('Section Phone Setting','cleaning-service-pro'),
          'section' => 'cleaning_service_pro_contact_page_section'
        )
    ) );
    $wp_customize->add_setting('cleaning_service_pro_contactpage_phone_title',array(
        'default'   => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_contactpage_phone_title',array(
        'label' => __('Phone Title','cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'setting'   => 'cleaning_service_pro_contactpage_phone_title',
        'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_contactpage_phone_one',array(
        'default'   => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_contactpage_phone_one',array(
        'label' => __('First Phone','cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'setting'   => 'cleaning_service_pro_contactpage_phone_one',
        'type'  => 'text'
    ));

    $wp_customize->add_setting('cleaning_service_pro_contactpage_phone_two',array(
        'default'   => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cleaning_service_pro_contactpage_phone_two',array(
        'label' => __('Second Phone','cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'setting'   => 'cleaning_service_pro_contactpage_phone_two',
        'type'  => 'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_contact_page_shortcode',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cleaning_service_pro_contact_page_shortcode',array(
    'label' => __('Contact Shortcode','cleaning-service-pro'),
    'description' => __('Add Contact Form Shortcode Here','cleaning-service-pro'),
    'section' => 'cleaning_service_pro_contact_page_section',
    'setting' => 'cleaning_service_pro_contact_page_shortcode',
    'type'    => 'text'
    )); 
    $wp_customize->add_setting( 'cleaning_service_pro_contact_page_section_map_setting',
    array(
      'default' => '',
      'transport' => 'postMessage',
      'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
    ));
    $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_contact_page_section_map_setting',
        array(
          'label' => __('Section Map Setting','cleaning-service-pro'),
          'section' => 'cleaning_service_pro_contact_page_section'
        )
    ) );

    $wp_customize->add_setting('cleaning_service_pro_address_longitude',array(
        'default'   => '',
        'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cleaning_service_pro_address_longitude',array(
        'label' => __('Longitude','cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'setting'   => 'cleaning_service_pro_address_longitude',
        'type'=>'text'
    ));
    $wp_customize->add_setting('cleaning_service_pro_address_latitude',array(
        'default'   => '',
        'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cleaning_service_pro_address_latitude',array(
        'label' => __('Latitude','cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'setting'   => 'cleaning_service_pro_address_latitude',
        'type'=>'text'
    ));
    $wp_customize->add_setting( 'cleaning_service_pro_contact_page_section_details_setting',
    array(
      'default' => '',
      'transport' => 'postMessage',
      'sanitize_callback' => 'cleaning_service_pro_text_sanitization'
    ));
    $wp_customize->add_control( new cleaning_service_pro_Themes_Seperator_custom_Control( $wp_customize, 'cleaning_service_pro_contact_page_section_details_setting',
        array(
          'label' => __('Section Text Color and Font Setting','cleaning-service-pro'),
          'section' => 'cleaning_service_pro_contact_page_section'
        )
    ) );
    $wp_customize->add_setting( 'cleaning_service_pro_contact_page_heading_color', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color'
    ));
    // add color picker control
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_contact_page_heading_color', array(
        'label' => __('Section Title Color', 'cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'settings' => 'cleaning_service_pro_contact_page_heading_color',
    )));

    $wp_customize->add_setting('cleaning_service_pro_contact_page_heading_font_family',array(
      'default' => '',
      'capability' => 'edit_theme_options',
      'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
    ));
    $wp_customize->add_control(
        'cleaning_service_pro_contact_page_heading_font_family', array(
        'section'  => 'cleaning_service_pro_contact_page_section',
        'label'    => __( 'Section Title Font Family','cleaning-service-pro'),
        'type'     => 'select',
        'choices'  => $font_array,
    ));

    $wp_customize->add_setting( 'cleaning_service_pro_contact_page_content_color', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color'
    ));
    // add color picker control
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_contact_page_content_color', array(
        'label' => __('Contact Heading Color', 'cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'settings' => 'cleaning_service_pro_contact_page_content_color',
    )));

    $wp_customize->add_setting('cleaning_service_pro_contact_page_contact_font_family',array(
      'default' => '',
      'capability' => 'edit_theme_options',
      'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
    ));
    $wp_customize->add_control(
        'cleaning_service_pro_contact_page_contact_font_family', array(
        'section'  => 'cleaning_service_pro_contact_page_section',
        'label'    => __( 'Contact Heading Font Family','cleaning-service-pro'),
        'type'     => 'select',
        'choices'  => $font_array,
    ));

    // add color picker control
    $wp_customize->add_setting( 'cleaning_service_pro_contact_page_contents_color', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color'
    ));   
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_contact_page_contents_color', array(
        'label' => __('Contact Content Color', 'cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'settings' => 'cleaning_service_pro_contact_page_contents_color',
    )));

    $wp_customize->add_setting('cleaning_service_pro_contact_page_contacts_font_family',array(
      'default' => '',
      'capability' => 'edit_theme_options',
      'sanitize_callback' => 'cleaning_service_pro_sanitize_choices'
    ));
    $wp_customize->add_control(
        'cleaning_service_pro_contact_page_contacts_font_family', array(
        'section'  => 'cleaning_service_pro_contact_page_section',
        'label'    => __( 'Contact Content Font Family','cleaning-service-pro'),
        'type'     => 'select',
        'choices'  => $font_array,
    ));

    // add color picker control
    $wp_customize->add_setting( 'cleaning_service_pro_contact_page_icon_color', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color'
    ));   
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleaning_service_pro_contact_page_icon_color', array(
        'label' => __('Contact Content Icon Color', 'cleaning-service-pro'),
        'section' => 'cleaning_service_pro_contact_page_section',
        'settings' => 'cleaning_service_pro_contact_page_icon_color',
    )));

?>