<?php
/**
 * Template part for displaying header content
 *
 * @package cleaning_service_pro
 */
?>
<div id="header_navigation">
  <div class="container nav_wrap">
    <div class="main-header-box">
      <div class="row bg-media">
        <div class="col-lg-8 col-md-2 col-sm-4 col-4 header-nav">
          <?php get_template_part( 'template-parts/header/navigation' ); ?>
        </div>
        <?php if( get_theme_mod('cleaning_service_pro_header_search_toggle') == 1 ) { ?>
        <div class="col-lg-4 col-md-10 col-sm-8 col-8 my-3">
          <div class="header-search text-right">
            <form class="search" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get" autocomplete="off">
              <input type="search" placeholder="<?php echo esc_attr_x( 'Search', 'placeholder', 'cleaning-service-pro' ); ?>" value="<?php echo esc_attr(the_search_query()); ?>" name="term" id="term">
              <button type="submit"><i class="fa fa-search"></i></button>
            </form>
          </div>
        </div>
        <?php } ?>
      </div>
    </div>
  </div>
</div>