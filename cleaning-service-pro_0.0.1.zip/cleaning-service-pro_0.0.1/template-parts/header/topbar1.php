<?php
/**
 * Template part for displaying Top Bar Content
 *
 * @package cleaning-service-pro
 */ 
$topbar_section = get_theme_mod( 'cleaning_service_pro_topbar1_enable' );
if ( 'Disable' == $topbar_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_topbar1_bgcolor') ) { 
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_topbar1_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_topbar1_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_topbar1_bgimage')).'\')';
}else{
  $about_backg = '';       
}
?>

<div id="topbar1">
  <div class="topbar_section">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-5 col-12">
          <div class="logo">
            <?php if( has_custom_logo() ){  cleaning_service_pro_the_custom_logo();  } ?>
            <div class="logo-text">
              <?php if( get_theme_mod('cleaning_service_pro_display_title', true) != ''){ ?>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php esc_attr(bloginfo( 'name' )); ?></a>
              <?php }
              if( get_theme_mod('cleaning_service_pro_display_tagline', true) != ''){ 
                $description = get_bloginfo( 'description', 'display' );
                if ( $description || is_customize_preview() ) : ?>
                  <p class="site-description"><?php echo esc_html($description); ?></p>
              <?php endif; } ?>
            </div>
          </div>
        </div>
        <?php  if(get_theme_mod('cleaning_service_pro_topbar1_location_text')!=''){ ?>
          <div class="col-lg-3 col-md-3 col-sm-7 col-12 d-flex justify-content-center align-items-center">
            <p class="mb-0"><i class="<?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar1_location_icon')); ?>"></i>
            <span><?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar1_location_title'));?>:</span><?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar1_location_text'));?></p>
          </div>  
        <?php } ?>
        <?php  if(get_theme_mod('cleaning_service_pro_topbar1_phone_text')!=''){ ?>
          <div class="col-lg-3 col-md-3 col-sm-6 col-12 d-flex justify-content-center align-items-center">
            <p class="mb-0"><i class="<?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar1_phone_icon')); ?>"></i>
            <span><?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar1_phone_title'));?>:</span><?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar1_phone_text'));?></p>
          </div>  
        <?php } ?>
        <div class="col-lg-2 col-md-2 col-sm-6 col-12 d-flex justify-content-center justify-content-lg-end align-items-center">
          <?php get_template_part('template-parts/home/social-icons');  ?>
        </div>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
</div>

