<?php
/**
 * Template part for displaying Top Bar Content
 *
 * @package cleaning-service-pro
 */ 

$topbar_section = get_theme_mod( 'cleaning_service_pro_topbar_enable' );
if ( 'Disable' == $topbar_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_topbar_color') ) { 
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_topbar_color')).';';
}elseif( get_theme_mod('cleaning_service_pro_topbar_image') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_topbar_image')).'\')';
}else{
  $about_backg = '';       
}

?>
<div id="topbar">
  <div class="topbar_section">
    <div class="container">
      <div class="row">
      <?php if(get_theme_mod('cleaning_service_pro_topbar_text')!='') { ?>
        <div class="col-lg-4 col-md-4 col-sm-6 col-12 py-2 text-lg-left">
          <p><?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar_text')); ?></p>
        </div>
      <?php } ?>  
      <?php  if(get_theme_mod('cleaning_service_pro_topbar_email_text')!=''){ ?>
        <div class="col-lg-4 col-md-4 col-sm-6 col-12 py-2 text-lg-center">
          <p><i class="<?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar_email_icon')); ?>"></i>
          <span><?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar_email_title'));?>:</span><?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar_email_text'));?></p>
        </div>  
      <?php } ?>
        <div class="col-lg-4 col-md-4 col-sm-12 col-12 py-2 text-lg-right text-center">
          <?php  if(get_theme_mod('cleaning_service_pro_topbar_career_btn')!=''){ ?>
            <a class="career_btn" href="<?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar_career_btn_url')); ?>"><?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar_career_btn')); ?>
            </a>
          <?php } ?>
          <?php  if(get_theme_mod('cleaning_service_pro_topbar_services_btn')!=''){ ?>
            <a class="services_btn" href="<?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar_services_btn_url')); ?>"><?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar_services_btn')); ?>
            </a>
          <?php } ?>
          <?php  if(get_theme_mod('cleaning_service_pro_topbar_contact_btn')!=''){ ?>
            <a class="contact_btn" href="<?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar_contact_btn_url')); ?>"><?php echo esc_html(get_theme_mod('cleaning_service_pro_topbar_contact_btn')); ?>
            </a>
          <?php } ?>
        </div>  
      </div>
      <div class="clearfix"></div>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
</div>

