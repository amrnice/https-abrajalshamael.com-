<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_why_choose_us_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_why_choose_us_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_why_choose_us_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_why_choose_us_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_why_choose_us_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="why_choose_us" style="<?php echo esc_attr($about_backg); ?>">
  	<div class="container">
	    <div class="heading text-center">
	    	<?php if(get_theme_mod('cleaning_service_pro_choose_main_text')!=''){ ?>
	        <p class="main_para mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_choose_main_text')); ?>
	        </p>
	      	<?php } ?>
		    <?php if(get_theme_mod('cleaning_service_pro_choose_main_heading')!=''){ ?>
		        <h3 class="main_heading"><?php echo esc_html(get_theme_mod('cleaning_service_pro_choose_main_heading')); ?>
		        </h3>
		    <?php } ?>
	    </div>
	    <div class="row mt-4">
	    	<div class="col-md-6 left_content">
	    		<?php if(get_theme_mod('cleaning_service_pro_choose_heading')!=''){ ?>
		        <h4 class="left"><?php echo esc_html(get_theme_mod('cleaning_service_pro_choose_heading')); ?>
		        </h4>
		    	<?php } ?>
		    	<?php if(get_theme_mod('cleaning_service_pro_choose_title')!=''){ ?>
		        <h5 class="title mt-lg-5 mb-2"><?php echo esc_html(get_theme_mod('cleaning_service_pro_choose_title')); ?>
		        </h5>
		    	<?php } ?>
		    	<?php if(get_theme_mod('cleaning_service_pro_choose_text1')!=''){ ?>
		        <p class="text"><?php echo esc_html(get_theme_mod('cleaning_service_pro_choose_text1')); ?>
		        </p>
		    	<?php } ?>
		    	<?php if(get_theme_mod('cleaning_service_pro_choose_text2')!=''){ ?>
		        <p class="text"><?php echo esc_html(get_theme_mod('cleaning_service_pro_choose_text2')); ?>
		        </p>
		    	<?php } ?>
		    	<div class="owl-carousel">
		    	<?php $choose = get_theme_mod('cleaning_service_pro_choose_increase');
			    	for($i=1 ; $i<=$choose; $i++) { ?>
			    		<div class="choose_box text-center">
			    			<div class="choose-image mb-3">
				              <img src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_choose_image'.$i)); ?>">
				            </div>
				            <?php if(get_theme_mod('cleaning_service_pro_choose_title'.$i)!=''){ ?>
				              <p class="title mb-0"><?php esc_html_e(get_theme_mod('cleaning_service_pro_choose_title'.$i)); ?></p>
				            <?php }?>
			        	</div>
		        	<?php }?>
		        </div>
	    	</div>
	    	<div class="col-md-6">
	    		<?php if(get_theme_mod('cleaning_service_pro_choose_video_heading')!=''){ ?>
		        <h4 class="right mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_choose_video_heading')); ?>
		        </h4>
		    	<?php } ?>
		    	<div class="row">
		    		<?php for($i=1 ; $i <=3 ; $i++) { ?>
			    		<?php if($i==1) { ?>
			    		<div class="col-md-12">
			    			<div class="video-image">
								<img src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_video_image'.$i)); ?>">
								<div class="video-content">
						        	<?php if(get_theme_mod('cleaning_service_pro_choose_video_icon'.$i)!=''){ ?>
							           <a data-toggle="modal" href="#myModal1"><i class="<?php echo esc_html(get_theme_mod('cleaning_service_pro_choose_video_icon'.$i)); ?>"></i></a>
						            <?php } ?>
						            <!-- Modal -->
									<div id="myModal1" class="modal fade" role="dialog">
										<div class="modal-dialog modal-lg">
											<!-- Modal content-->
											<div class="modal-content">
												<div class="video-wrapper">
							   						<iframe width="100%" height="345" src="<?php echo esc_html(get_theme_mod('cleaning_service_pro_choose_video_url'.$i)); ?>">
													</iframe>
												</div>
					    						<div class="modal-footer">
					        						<button type="button" class="btn btn-default" data-dismiss="modal"><?php echo esc_html('Close','blog-pro') ?></button>
					      						</div>
											</div>
										</div>
									</div>
								</div>
							</div>
			    		</div>
			    		<?php }else { ?>
			    			<div class="col-md-6 col-6 <?php if($i==2) { echo 'pr-1 pt-1';} elseif($i==3) { echo 'pl-1 pt-1';}?>">
			    				<img src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_video_image'.$i)); ?>">
			    			</div>
			    		<?php } ?>
		    		<?php } ?>
		    	</div>
	    	</div>
	    </div>
    <?php get_template_part( 'template-parts/home/counter' ); ?>
  	</div>
</section>



