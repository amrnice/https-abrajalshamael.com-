<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_add_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_add_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_add_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_add_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_add_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="add" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container">
		<div class="row my-5">
			<div class="col-lg-6 col-md-6 col-12">
				<?php if(get_theme_mod('cleaning_service_pro_add_main_heading')!=''){ ?>
		            <h3 class="head">
		              <?php echo esc_html(get_theme_mod('cleaning_service_pro_add_main_heading')); ?>
		            </h3>
		    	<?php } if(get_theme_mod('cleaning_service_pro_add_main_text')!=''){ ?>
		            <p class="text mb-0">
		              <?php echo esc_html(get_theme_mod('cleaning_service_pro_add_main_text')); ?>
		            </p>
		        <?php } ?>
			</div>
		</div>
	</div>
</section>