<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_contact_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_contact_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_contact_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_contact_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_contact_bgimage')).'\')';
}else{
  $about_backg = '';
}
?>
<section id="contact" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-12">
				<div class="contact-content my-5">
		            <?php if(get_theme_mod('cleaning_service_pro_section_contact_main_heading')!=''){ ?>
		            	<h3 class="main_heading"><?php echo esc_html(get_theme_mod('cleaning_service_pro_section_contact_main_heading')); ?></h3>
		            <?php } ?>
		            <p class=""><i class="fas fa-map-marker-alt pr-2"></i><?php echo esc_html(get_theme_mod('cleaning_service_pro_section_contact_location')); ?></p>
		            <p class=""><i class="fas fa-phone pr-2"></i><?php echo esc_html(get_theme_mod('cleaning_service_pro_section_contact_phone')); ?></p>
		            <div class="bg">
			            <i class="fas fa-clock pr-3 pt-2"></i>
			            <div class="con">
			              <p class="mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_section_contact_weak')); ?></p>
			              <p class="mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_section_contact_time')); ?></p>
			            </div>
                  	</div>
				</div>
			</div>
			<div class="col-lg-8 col-md-8 col-sm-12">
				<div class="google-map p-0" id="map">
					<?php if ( get_theme_mod('cleaning_service_pro_section_contact_address_latitude',true) != "" && get_theme_mod('cleaning_service_pro_section_contact_address_longitude',true) != "" ) {?>
					  	<embed width="100%" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?q=<?php echo esc_attr(get_theme_mod('cleaning_service_pro_section_contact_address_latitude')); ?>,<?php echo esc_attr(get_theme_mod('cleaning_service_pro_section_contact_address_longitude')); ?>&hl=es;z=14&amp;output=embed"></embed>
					<?php }?>
				</div>
			</div>
		</div>
	</div>
</section>