<section id="counter" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container">
		<div class="owl-carousel">
	    	<?php $counter = get_theme_mod('cleaning_service_pro_counter_increase');
	    	for($i=1 ; $i<=$counter; $i++) { ?>
	    		<div class="counter_box text-center">
	    			<div class="counter-image">
		              <img src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_counter_image'.$i)); ?>">
		            </div>
					<?php if(get_theme_mod('cleaning_service_pro_counter_number'.$i)!=''){ ?>
		              <h6 class="number mb-0"><span class="count"><?php esc_html_e(get_theme_mod('cleaning_service_pro_counter_number'.$i)); ?></span><?php esc_html_e(get_theme_mod('cleaning_service_pro_counter_number_text'.$i)); ?></h6>
		            <?php }?>
		            <?php if(get_theme_mod('cleaning_service_pro_counter_text'.$i)!=''){ ?>
		              <p class="title mb-0"><?php esc_html_e(get_theme_mod('cleaning_service_pro_counter_text'.$i)); ?></p>
		            <?php }?>
	        	</div>
        	<?php }?>
    	</div>
	</div>
</section>