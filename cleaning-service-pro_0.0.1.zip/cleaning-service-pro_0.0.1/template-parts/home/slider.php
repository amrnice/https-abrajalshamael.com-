<?php 
$section_hide = get_theme_mod( 'cleaning_service_pro_slider_enabledisable' );
if ( 'Disable' == $section_hide ) {
  return;
}

$number = get_theme_mod('cleaning_service_pro_slide_number'); 
$slide_delay = get_theme_mod('cleaning_service_pro_slide_delay'); 
  if($number != ''){
?>
  <section id="slider">
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner" role="listbox">
          <?php for ($i=1,$j=1; $i<=$number; $i++,$j++) { ?>
            <?php if(get_theme_mod('cleaning_service_pro_slide_image'.$i) != ''){ ?>
              <div <?php if($i == 1){echo 'class="carousel-item active"';} else{ echo 'class="carousel-item"';}?>>
                <?php if ( get_theme_mod('cleaning_service_pro_slide_image',true) != "" ) {?>
                  <img  src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_slide_image'.$i)); ?>" alt="<?php echo esc_attr_e(get_theme_mod('cleaning_service_pro_slide_title'.$i, true)); ?>" title="#slidecaption<?php echo esc_html($i); ?>">
                <?php } ?>
                <?php if ( get_theme_mod('cleaning_service_pro_slide_main_heading'.$i) != "" || get_theme_mod('cleaning_service_pro_slide_heading'.$i) != "" || get_theme_mod('cleaning_service_pro_slide_text'.$i) != "") {?>
                <div class="carousel-caption d-md-block mt-5">
                  <div class="container h-100">
                    <div class="row h-100">
                      <div class="inner_carousel">
                        <div class="slider-box text-left">
                          <h4 class="pb-0 mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_slide_main_heading'.$i)); ?></h4> 
                          <h1 class="mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_slide_heading'.$i)); ?></h1>
                          <div class="prop_desc">
                            <p class="mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_slide_text'.$i)); ?></p>
                          </div>
                          <div class="slide_btn">
                            <a class="read-more1 btn" href="<?php echo esc_url(get_theme_mod('cleaning_service_pro_slide_btn_url'.$i)); ?>"><?php echo esc_html(get_theme_mod('cleaning_service_pro_slide_btn'.$i)); ?></a>
                            <a class="btn" href="<?php echo esc_url(get_theme_mod('cleaning_service_pro_slide_btn_url1'.$i)); ?>"><?php echo esc_html(get_theme_mod('cleaning_service_pro_slide_btn1'.$i)); ?></a>
                          </div>
                          <div class="bg my-3">
                            <i class="<?php echo esc_html(get_theme_mod('cleaning_service_pro_slide_icon'.$i)); ?> pr-3 pt-2"></i>
                            <div class="con">
                              <p class="mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_slide_days'.$i)); ?></p>
                              <p class="mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_slide_time'.$i)); ?></p>
                            </div>
                          </div>
                        </div>
                        <div class="slide_right_box">
                          <span class="pt-4"><?php echo esc_html(get_theme_mod('cleaning_service_pro_slide_discount_head'.$i)); ?></span>
                          <span class="number"><?php echo esc_html(get_theme_mod('cleaning_service_pro_slide_discount_number'.$i)); ?></span><span><?php echo esc_html(get_theme_mod('cleaning_service_pro_slide_discount_text'.$i));?></span>
                        </div>
                      </div>
                    </div> 
                  </div>
                </div>  
                <?php } ?>
              </div>
            <?php } ?>
          <?php } ?>
        </div>
      </div> 
      <div class="clearfix"></div>
  </section>
<?php } ?>