<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_service_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_service_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_service_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_service_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_service_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="service" style="<?php echo esc_attr($about_backg); ?>">
  <div class="container">
    <div class="heading">
      <?php if(get_theme_mod('cleaning_service_pro_service_main_heading')!=''){ ?>
        <h3 class="main_heading text-center"><?php echo esc_html(get_theme_mod('cleaning_service_pro_service_main_heading')); ?>
        </h3>
        <?php } ?>
      <?php if(get_theme_mod('cleaning_service_pro_service_main_para')!=''){ ?>
        <p class="w-50 mx-auto text-center main_text mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_service_main_para')); ?>
        </p>
      <?php } ?>
    </div>
    <div class="owl-carousel my-4">
      <?php 
      $count = get_theme_mod('cleaning_service_pro_service_count');
      for($i=1 ; $i<=$count; $i++) { ?>
        <div class="serviceBox text-center py-4">
            <div class="service-image">
              <img src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_service_image'.$i)); ?>">
            </div>
            <div class="service-content">
              <h5 class="mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_service_title'.$i)); ?></h5>
              <p class=""><?php echo esc_html(get_theme_mod('cleaning_service_pro_service_text'.$i)); ?></p>
              <a class="read btn" href="<?php echo esc_html(get_theme_mod('cleaning_service_pro_service_btn_url'.$i)); ?>"><?php echo esc_html(get_theme_mod('cleaning_service_pro_service_btn'.$i)); ?></a>
            </div>
        </div>
      <?php } ?>
    </div>  
  </div>
</section>