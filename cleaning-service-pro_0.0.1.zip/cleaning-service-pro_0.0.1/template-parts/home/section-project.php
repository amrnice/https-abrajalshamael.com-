<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_project_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_project_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_project_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_project_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_project_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="project" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container">
		<div class="heading text-center">
			<?php if(get_theme_mod('cleaning_service_pro_project_main_para')!=''){ ?>
	        	<p class="main_para mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_project_main_para')); ?></p>
	      	<?php } ?>
		    <?php if(get_theme_mod('cleaning_service_pro_project_main_heading')!=''){ ?>
		        <h3 class="main_heading "><?php echo esc_html(get_theme_mod('cleaning_service_pro_project_main_heading')); ?>
		        </h3>
		    <?php } ?>
	    </div>
	</div>
	<div class="container-fluid">
	    <div class="row mt-5">
	    	<div class="col-md-6 col-sm-6">
	    		<img src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_project_left_img')); ?>">
	    	</div>
	    	<div class="col-md-6 col-sm-6">
	    		<div class="project_slider">
	    			<?php 
	    			$count=get_theme_mod('cleaning_service_pro_project_count');
	    			for($i=1 ; $i<=$count; $i++) { ?>
	    				<div> 
	    					<div class="box">
	    						<img src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_project_image'.$i)); ?>">
				                <div class="box-layer layer-1"></div>
				                <div class="box-layer layer-2"></div>
				                <div class="box-layer layer-3"></div>
				                <div class="box-content">
				                    <h5 class="title"><?php echo esc_html(get_theme_mod('cleaning_service_pro_project_title'.$i)); ?></h5>
									<p class="description"><?php echo esc_html(get_theme_mod('cleaning_service_pro_project_text'.$i)); ?></p>
				                    <a class="read-more btn" href="<?php echo esc_html(get_theme_mod('cleaning_service_pro_project_btn_url'.$i)); ?>"><?php echo esc_html(get_theme_mod('cleaning_service_pro_project_btn'.$i)); ?></a>
				                </div>
				            </div>
						</div>
	    			<?php } ?>
	    		</div>
	    	</div>
	    </div>
	</div>
	</div>
</section>