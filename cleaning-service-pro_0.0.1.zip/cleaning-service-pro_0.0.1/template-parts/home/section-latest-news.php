<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_latest_news_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_latest_news_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_latest_news_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_latest_news_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_latest_news_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="latest_news" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container">
		<div class="latest-news-head text-center">
			<?php if(get_theme_mod('cleaning_service_pro_latest_news_main_para')!=''){ ?>
	            <p class="main_para text-center mb-0">
	              <?php echo esc_html(get_theme_mod('cleaning_service_pro_latest_news_main_para')); ?>
	            </p>
            <?php } ?>
			<?php if(get_theme_mod('cleaning_service_pro_latest_news_main_heading')!=''){ ?>
	            <h3 class="main_heading text-center mb-0">
	              <?php echo esc_html(get_theme_mod('cleaning_service_pro_latest_news_main_heading')); ?>
	            </h3>
            <?php } ?>
		</div>
		<div class="owl-carousel mt-4">
			<?php
			$args = array(
				'post_type' => 'post',
				'post_status' => 'publish',
				'posts_per_page' => get_theme_mod('cleaning_service_pro_latest_news_number')
			);
			$new = new WP_Query($args); 
			$loop_index = 0; $i=1;
			while ( $new->have_posts() ){
				$new->the_post(); ?>
				<div class="post-slide">
					<div class="post-img">
						<?php the_post_thumbnail(); ?>
					</div>
					<div class="post-content">
						<h5 class="post-title p-0 mb-0"><?php the_title(); ?></h5>
						<a class="read-more btn" href="<?php the_permalink(); ?>"><?php echo esc_html(get_theme_mod('cleaning_service_pro_latest_news_btn'.$i)); ?></a>
						<p class="date mb-0"><i class="fas fa-calendar pr-2"></i><?php echo get_the_date('j M Y') ?></p>
					</div>
		        </div>
			<?php }
               wp_reset_query(); ?>
		</div>
	</div>
</section>