<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_appointment_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_appointment_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_appointment_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_appointment_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_appointment_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="appointment" style="<?php echo esc_attr($about_backg); ?>">
  <div class="container">
    <div class="heading">
      <?php if(get_theme_mod('cleaning_service_pro_appointment_main_heading')!=''){ ?>
        <h3 class="main_heading text-center"><?php echo esc_html(get_theme_mod('cleaning_service_pro_appointment_main_heading')); ?>
        </h3>
        <?php } ?>
      <?php if(get_theme_mod('cleaning_service_pro_appointment_main_para')!=''){ ?>
        <p class="main_text mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_appointment_main_para')); ?>
        </p>
      <?php } ?>
    </div>
    <div class="col-md-12 my-3">
      <div class="shortcode">
        <h4 class="text-center"><?php echo esc_html(get_theme_mod('cleaning_service_pro_appointment_title')); ?>
        </h4>
        <?php if(get_theme_mod('cleaning_service_pro_appointment_shortcode')!=""){ ?>
          <?php echo do_shortcode(get_theme_mod('cleaning_service_pro_appointment_shortcode')); ?>
        <?php } ?>
      </div>
    </div>
  </div>
</section>