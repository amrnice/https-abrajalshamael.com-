<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_product_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_product_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_product_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_product_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_product_bgimage')).'\')';
}else{
  $about_backg = '';
}
?>
<section id="product" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<?php if(get_theme_mod('cleaning_service_pro_product_left_image')!='') { ?>
					<img class="test_img" src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_product_left_image')); ?>">
				<?php } ?>
			</div>
			<div class="col-md-6">
				<div class="product-head">
					<?php if(get_theme_mod('cleaning_service_pro_product_main_title')!=''){ ?>
			            <p class="main_para mb-0">
			              <?php echo esc_html(get_theme_mod('cleaning_service_pro_product_main_title')); ?>
			            </p>
		            <?php } ?>
					<?php if(get_theme_mod('cleaning_service_pro_product_main_heading')!=''){ ?>
			            <h3 class="main_heading mb-0">
			              <?php echo esc_html(get_theme_mod('cleaning_service_pro_product_main_heading')); ?>
			            </h3>
		            <?php } ?>
		            <?php if(get_theme_mod('cleaning_service_pro_product_main_text')!=''){ ?>
		            	<p class="text mt-4"><?php echo esc_html(get_theme_mod('cleaning_service_pro_product_main_text')); ?>
		            	</p>
		            <?php } ?>
		        </div>
		        <div class="product-content">
		            <?php if(get_theme_mod('cleaning_service_pro_product_title1')!=''){ ?>
		            	<h5 class="mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_product_title1')); ?>
	            		</h5>
		            <?php } ?>
		            <?php if(get_theme_mod('cleaning_service_pro_product_text1')!=''){ ?>
		            	<p><?php echo esc_html(get_theme_mod('cleaning_service_pro_product_text1')); ?></p>
		            <?php } ?>
		            <?php if(get_theme_mod('cleaning_service_pro_product_title2')!=''){ ?>
		            	<h5 class="mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_product_title2')); ?></h5>
		            <?php } ?>
		            <?php if(get_theme_mod('cleaning_service_pro_product_text2')!=''){ ?>
		            	<p><?php echo esc_html(get_theme_mod('cleaning_service_pro_product_text2')); ?></p>
		            <?php } ?>
				</div>
			</div>
		</div>
	</div>
</section>