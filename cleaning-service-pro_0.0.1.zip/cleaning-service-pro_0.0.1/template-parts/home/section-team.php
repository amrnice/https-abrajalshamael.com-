<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_team_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_team_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_team_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_team_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_team_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="team" style="<?php echo esc_attr($about_backg); ?>">
  <div class="container">
    <div class="heading text-center">
      <?php if(get_theme_mod('cleaning_service_pro_team_main_text')!=''){ ?>
          <p class="main_para mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_team_main_text')); ?>
          </p>
        <?php } ?>
        <?php if(get_theme_mod('cleaning_service_pro_team_main_heading')!=''){ ?>
          <h3 class="main_heading text-center"><?php echo esc_html(get_theme_mod('cleaning_service_pro_team_main_heading')); ?>
          </h3>
        <?php } ?>
    </div>
    <div class="owl-carousel mt-4">
      <?php 
      $count = get_theme_mod('cleaning_service_pro_team_count');
      for($i=1 ; $i<=$count; $i++) { ?>
          <div class="our-team">
              <div class="pic">
                  <img src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_team_image'.$i)); ?>">
                  <div class="social_media_team">
                      <ul class="social">
                        <?php 
                        $social = get_theme_mod('cleaning_service_pro_team_social_count'.$i);
                        for($k=1 ; $k<=$social ; $k++) { ?>
                          <li><a href="<?php echo esc_html(get_theme_mod('cleaning_service_pro_team_social_link'.$k)); ?>"><i class="<?php echo esc_html(get_theme_mod('cleaning_service_pro_team_social_icon'.$k)); ?>"></i></a></li>
                        <?php } ?>
                      </ul>
                  </div>
              </div>
              <div class="team-prof text-center">
                  <h5 class="post-title mb-0"><a href="#"><?php echo esc_html(get_theme_mod('cleaning_service_pro_team_title'.$i)); ?></a></h5>
                  <p class="post mb-0 pb-1"><?php echo esc_html(get_theme_mod('cleaning_service_pro_team_designation'.$i)); ?></p>
                  <ul class="star">
                    <?php 
                    $star_count = get_theme_mod("cleaning_service_pro_team_star_count".$i);
                    for($j=1 ; $j<= $star_count ; $j++ ) { ?>
                      <li><i class="fas fa-star"></i></li>
                    <?php } ?>
                  </ul>
              </div>
          </div>
      <?php } ?>
    </div>  
   
  </div>
</section>
