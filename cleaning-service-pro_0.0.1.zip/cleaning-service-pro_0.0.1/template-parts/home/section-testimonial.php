<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_testimonial_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_testimonial_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_testimonial_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_testimonial_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_testimonial_bgimage')).'\')';
}else{
  $about_backg = '';
}
?>
<section id="testimonial" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container">
		<div class="testimonial-head text-center">
			<?php if(get_theme_mod('cleaning_service_pro_testimonial_main_text')!=''){ ?>
	            <p class="main_para mb-0">
	              <?php echo esc_html(get_theme_mod('cleaning_service_pro_testimonial_main_text')); ?>
	            </p>
            <?php } ?>
			<?php if(get_theme_mod('cleaning_service_pro_testimonial_main_heading')!=''){ ?>
	            <h3 class="main_heading mb-0">
	              <?php echo esc_html(get_theme_mod('cleaning_service_pro_testimonial_main_heading')); ?>
	            </h3>
            <?php } ?>
		</div>
		<div class="row mt-4">
			<div class="col-md-6">
				<?php if(get_theme_mod('cleaning_service_pro_testimonial_left_image')!='') { ?>
					<img src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_testimonial_left_image')); ?>">
				<?php } ?>
			</div>
			<div class="col-md-6">
				<div class="owl-carousel">
					<?php 
					$testimonial_count = get_theme_mod('cleaning_service_pro_testimonial_count');
					for($i=1 ; $i<=$testimonial_count ; $i++) { ?>
		                <div class="testimonial text-center">
		                <?php if(get_theme_mod('cleaning_service_pro_testimonial_image'.$i)!='') { ?>
							<img class="test_img" src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_testimonial_image'.$i)); ?>">
						<?php } ?>
		                <h5 class="pb-0 mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_testimonial_name'.$i)); ?></h5>
            			<ul class="star">
            				<?php 
            				$star_count = get_theme_mod("cleaning_service_pro_testimonial_star_count".$i);
            				for($j=1 ; $j<= $star_count ; $j++ ) { ?>
            					<li><i class="fas fa-star"></i></li>
            				<?php } ?>
            			</ul>
		                <p class="pb-0 mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_testimonial_text'.$i)); ?></p>	
		                </div>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
</section>