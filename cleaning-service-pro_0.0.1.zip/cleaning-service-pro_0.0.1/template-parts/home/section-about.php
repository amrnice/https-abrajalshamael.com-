<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_about_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_about_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_about_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_about_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_about_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="about" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="left">
					<img src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_about_left_image')); ?>">
					<div class="boxx">
						<span class="number"><?php echo esc_html(get_theme_mod('cleaning_service_pro_about_left_number')); ?></span><span><?php echo esc_html(get_theme_mod('cleaning_service_pro_about_left_text'));?></span>
					</div>
				</div>
			</div>
			<div class="col-md-6 my-4">
				<p class="main_para mb-1"><?php echo esc_html(get_theme_mod('cleaning_service_pro_about_title')); ?></p>
				<h3 class="main_heading"><?php echo esc_html(get_theme_mod('cleaning_service_pro_about_main_heading')); ?></h3>
				<p class="text"><?php echo esc_html(get_theme_mod('cleaning_service_pro_about_text')); ?></p>
				<ul>
					<?php for($i=1; $i<=4; $i++) { ?>
						<li><i class="<?php echo esc_html(get_theme_mod('cleaning_service_pro_about_list_icon'.$i)); ?>"></i><?php echo esc_html(get_theme_mod('cleaning_service_pro_about_list_text'.$i)); ?></li>
					<?php } ?>
				</ul>
				<h5 class="mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_about_phone_title')); ?></h5>
				<p class="phone"><span><i class="<?php echo esc_html(get_theme_mod('cleaning_service_pro_about_phone_icon')); ?> pr-2"></i></span><?php echo esc_html(get_theme_mod('cleaning_service_pro_about_phone_number')); ?></p>
			</div>
		</div>
	</div>
</section>	