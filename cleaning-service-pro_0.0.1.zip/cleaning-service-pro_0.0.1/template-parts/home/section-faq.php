<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_faq_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_faq_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_faq_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_faq_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_faq_bgimage')).'\')';
}else{
  $about_backg = '';
}
?>
<section id="faq" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<?php if(get_theme_mod('cleaning_service_pro_faq_left_image')!='') { ?>
					<img class="test_img" src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_faq_left_image')); ?>">
				<?php } ?>
			</div>
			<div class="col-md-6">
				<div class="faq-head">
					<?php if(get_theme_mod('cleaning_service_pro_faq_main_heading')!=''){ ?>
			            <h3 class="main_heading">
			              <?php echo esc_html(get_theme_mod('cleaning_service_pro_faq_main_heading')); ?>
			            </h3>
		            <?php } ?>
		            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
		            	<?php 
		            	$count =  get_theme_mod('cleaning_service_pro_faq_count');
		            	for($i=1 ; $i<=$count; $i++ ) { ?>
			                <div class="panel panel-default">
			                    <div class="panel-heading" role="tab">
			                        <h5 class="panel-title">
			                            <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse-<?php echo $i ?>"><?php echo esc_html(get_theme_mod('cleaning_service_pro_faq_title'.$i)); ?>
			                            </a>
			                        </h5>
			                    </div>
			                    <div id="collapse-<?php echo $i ?>" class="panel-collapse collapse in" role="tabpanel">
			                        <div class="panel-body">
			                            <p class="mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_faq_text'.$i)); ?></p>
			                        </div>
			                    </div>
			                </div>
		            	<?php }?>
		            </div>
				</div>
			</div>
		</div>
	</div>
</section>