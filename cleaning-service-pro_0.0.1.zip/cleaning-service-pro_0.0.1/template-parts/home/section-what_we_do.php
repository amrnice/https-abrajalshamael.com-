<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_what_we_do_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_what_we_do_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_what_we_do_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_what_we_do_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_what_we_do_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="what_we_do" style="<?php echo esc_attr($about_backg); ?>">
  <div class="container">
  	<div class="heading text-center">
  		<?php if(get_theme_mod('cleaning_service_pro_what_we_do_main_text')!=''){ ?>
       		<p class="main_para text-center mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_what_we_do_main_text')); ?>
        	</p>
      	<?php } ?>
      	<?php if(get_theme_mod('cleaning_service_pro_what_we_do_main_heading')!=''){ ?>
        	<h3 class="main_heading text-center"><?php echo esc_html(get_theme_mod('cleaning_service_pro_what_we_do_main_heading')); ?>
        	</h3>
      	<?php } ?>
	</div>
    <div class="owl-carousel my-5">
        <?php 
        $count = get_theme_mod('cleaning_service_pro_what_we_do_count');
        for($i=1 ; $i<=$count; $i++) { ?>
          	<div class="what-we-do">
                <div class="box">
                    <img class="bg_image" src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_what_we_do_bgimage'.$i)); ?>">
                    <div class="box-content text-center">
                    	<div class="icon">
		                	<img src="<?php echo esc_url(get_theme_mod('cleaning_service_pro_what_we_do_image'.$i)); ?>">
		              	</div>
                        <h5 class="title mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_what_we_do_title'.$i)); ?></h5>
                        <p class="description"><?php echo esc_html(get_theme_mod('cleaning_service_pro_what_we_do_text'.$i)); ?>
                        </p>
                        <a class="read-more" href="<?php echo esc_html(get_theme_mod('cleaning_service_pro_what_we_do_btn_url'.$i)); ?>"><?php echo esc_html(get_theme_mod('cleaning_service_pro_what_we_do_btn'.$i)); ?></a>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>  
  </div>
</section>
