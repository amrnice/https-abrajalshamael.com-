<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_newsletter_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_newsletter_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_newsletter_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_newsletter_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_newsletter_bgimage')).'\')';
}else{
  $about_backg = '';
}
?>
<section id="newsletter" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container">
		<div class="newsletter-box mx-auto">
			<div class="row">
				<div class="col-lg-3 col-md-12 col-12">
					<div class="newsletter-content">
					<?php if(get_theme_mod('cleaning_service_pro_newsletter_main_text')!=''){ ?>
			            <p class="text mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_newsletter_main_text')); ?>
			            </p>
		            <?php } ?>
		            <?php if(get_theme_mod('cleaning_service_pro_newsletter_main_heading')!=''){ ?>
		            	<h3 class="head mb-0 pt-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_newsletter_main_heading')); ?></h3>
		            <?php } ?>
				</div>
				</div>
				<div class="col-lg-9 col-md-12 col-12">
					<div class="newsletter_form my-3">
			            <?php if(get_theme_mod('cleaning_service_pro_newsletter_shortcode')!=""){ ?>
							<?php echo do_shortcode(get_theme_mod('cleaning_service_pro_newsletter_shortcode')); ?>
						<?php } ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>