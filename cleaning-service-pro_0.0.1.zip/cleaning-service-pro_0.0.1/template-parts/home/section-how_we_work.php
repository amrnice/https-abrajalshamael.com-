<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_how_we_work_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_how_we_work_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_how_we_work_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_how_we_work_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_how_we_work_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="how_we_work" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container">
		<div class="row">
			<div class="col-lg-7 col-md-12 col-sm-12 col-12 my-4 text-center">
				<p class="main_para mb-1"><?php echo esc_html(get_theme_mod('cleaning_service_pro_how_we_work_main_text')); ?></p>
				<h3 class="main_heading"><?php echo esc_html(get_theme_mod('cleaning_service_pro_how_we_work_main_heading')); ?></h3>
				<div class="how_we_work_content">
					<h5 class="text mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_how_we_work_title')); ?></h5>
					<p class="text"><?php echo esc_html(get_theme_mod('cleaning_service_pro_how_we_work_text')); ?></p>
					<ul>
						<?php for($i=1; $i<=4; $i++) { ?>
							<li><i class="<?php echo esc_html(get_theme_mod('cleaning_service_pro_how_we_work_list_icon'.$i)); ?>"></i><?php echo esc_html(get_theme_mod('cleaning_service_pro_how_we_work_list_text'.$i)); ?></li>
						<?php } ?>
					</ul>
					<a class="read-more btn my-3" href="<?php echo esc_html(get_theme_mod('cleaning_service_pro_how_we_work_btn_url')); ?>"><?php echo esc_html(get_theme_mod('cleaning_service_pro_how_we_work_btn')); ?></a>
				</div>
			</div>
		</div>
	</div>
</section>	