<?php 
$about_section = get_theme_mod( 'cleaning_service_pro_pricing_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cleaning_service_pro_pricing_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cleaning_service_pro_pricing_bgcolor')).';';
}elseif( get_theme_mod('cleaning_service_pro_pricing_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cleaning_service_pro_pricing_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="pricing" style="<?php echo esc_attr($about_backg); ?>">
  	<div class="container">
	    <div class="heading text-center">
	    	<?php if(get_theme_mod('cleaning_service_pro_pricing_main_text')!=''){ ?>
	        <p class="main_para mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_pricing_main_text')); ?>
	        </p>
	      	<?php } ?>
		    <?php if(get_theme_mod('cleaning_service_pro_pricing_main_heading')!=''){ ?>
		        <h3 class="main_heading"><?php echo esc_html(get_theme_mod('cleaning_service_pro_pricing_main_heading')); ?>
		        </h3>
		    <?php } ?>
	    </div>
    	<div class="owl-carousel mt-5">
	    	<?php $pricing = get_theme_mod('cleaning_service_pro_pricing_increase');
		    	for($i=1 ; $i<=3; $i++) { ?>
	        	<div class="pricingTable">
                    <div class="pricingTable-header">
                    	<h5 class="heading"><?php echo esc_html(get_theme_mod('cleaning_service_pro_pricing_title'.$i)); ?></h5>
                    	<div class="icon">
                        	<i class="<?php echo esc_html(get_theme_mod('cleaning_service_pro_pricing_icon'.$i)); ?>"></i>
                    	</div>
                    </div>
                    <div class="pricing-content">
                        <ul><?php 
                        	$list = get_theme_mod('cleaning_service_pro_pricing_list_increase'.$i);
                        	for($k=1 ; $k<=$list; $k++) { ?>
                            	<li><?php echo esc_html(get_theme_mod('cleaning_service_pro_pricing_list'.$k)); ?></li>
                            <?php } ?>
                        </ul>
                        <h5 class="price-value mb-0"><?php echo esc_html(get_theme_mod('cleaning_service_pro_pricing_value'.$i)); ?></h5>
                    </div>
                    <div class="">
                        <a class="read-more btn" href="<?php echo esc_html(get_theme_mod('cleaning_service_pro_pricing_btn_url'.$i)); ?>"><?php echo esc_html(get_theme_mod('cleaning_service_pro_pricing_btn'.$i)); ?></a>
                    </div>
                </div>
	        <?php }?>
	    </div>
  	</div>
</section>



